import sys
None
import bench_support

def main():
    args = {}
    for a in sys.argv[1:]:
        if '=' in a:
            k, v = a.split('=', 1)
            args[k] = int(v)
    n = args.get('n_joins', 40)
    import sqlglot
    from sqlglot.optimizer import optimize
    joins = ' '.join((f'JOIN t{i} ON t{i}.id = t0.id' for i in range(1, n)))
    sql = f'SELECT * FROM t0 {joins}'
    schema = {f't{i}': {'id': 'INT', 'v': 'INT'} for i in range(n)}
    expression = sqlglot.parse_one(sql)
    result = optimize(expression, schema=schema)
    print(f'n_joins={n} output_columns={len(result.expressions)}')
if __name__ == '__main__':
    main()
