"""Read only saved supervisor profiles; never executes a workload."""
import json
from pathlib import Path

for folder in sorted(Path("measurements").glob("round-*")):
    profile = folder / "profile.drperf.json"
    if not profile.exists():
        continue
    data = json.loads(profile.read_text())
    print(folder.name)
    for region in data["regions"]:
        print(region["name"], "calls", region["calls"], "states", len(region["points"]),
              "own_residual", region["regimes"][0]["unexplainedShare"])
    plan = json.loads((folder / "plan.json").read_text())
    reachable = links = requests = 0
    for point in plan:
        n, shape = point["n"], point["shape"]
        requests += n
        reachable += 2*n-1 if shape == 1 else n*(n+1)//2
        links += n-1 if shape == 1 else (n-1)**2 if shape == 2 else n*(n-1)//2
    print("expected ancestry/immediate calls", reachable,
          "expected recursive conversion calls", requests + 6*(reachable+links))
