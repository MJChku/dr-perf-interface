import sys

def states(**defaults):
    for arg in sys.argv[1:]:
        key, sep, value = arg.partition('=')
        if not sep or key not in defaults:
            raise ValueError('unknown workload argument: ' + arg)
        defaults[key] = type(defaults[key])(value)
    return defaults
