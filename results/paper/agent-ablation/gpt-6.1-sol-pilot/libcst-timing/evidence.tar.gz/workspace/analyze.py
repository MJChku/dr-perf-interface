import json,pstats,pathlib
for rd in sorted(pathlib.Path('measurements').glob('round-*')):
    result=json.loads((rd/'result.json').read_text())
    for i,pt in enumerate(result['points']):
        st=pstats.Stats(str(rd/f'point-{i:02d}'/'profile.pstats'))
        rows={}
        for (f,l,n),(cc,nc,tt,ct,callers) in st.stats.items():
            if ('entrypoints.py' in f and n in ('_parse','parse_module')) or ('_nodes/base.py' in f and n=='__post_init__') or ('_nodes/expression.py' in f and n=='_validate') or ('dataclasses.py' in f and n=='_process_class'):
                rows[f'{pathlib.Path(f).name}:{l}:{n}']=[nc,round(tt,6),round(ct,6)]
        print(rd.name,pt['input'],pt['wall_seconds'],json.dumps(rows,sort_keys=True))
