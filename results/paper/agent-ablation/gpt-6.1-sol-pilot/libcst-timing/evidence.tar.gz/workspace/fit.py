import json,pstats,pathlib,math
rows={0:[],1:[],2:[]}
for rd in sorted(pathlib.Path('measurements').glob('round-*')):
 for i,pt in enumerate(json.loads((rd/'result.json').read_text())['points']):
  st=pstats.Stats(str(rd/f'point-{i:02d}'/'profile.pstats'))
  t=next(v[2] for k,v in st.stats.items() if k[0].endswith('/entrypoints.py') and k[2]=='_parse')
  rows[pt['input']['shape']].append((pt['input']['n_terms'],t))
def fit(data,degree):
 x=[[float(n)**d for d in range(degree+1)] for n,t in data]; y=[t for n,t in data]
 a=[[sum(row[i]*row[j] for row in x) for j in range(degree+1)]+[sum(row[i]*t for row,t in zip(x,y))] for i in range(degree+1)]
 for i in range(degree+1):
  piv=a[i][i];a[i]=[v/piv for v in a[i]]
  for j in range(degree+1):
   if j!=i:
    fac=a[j][i];a[j]=[v-fac*w for v,w in zip(a[j],a[i])]
 c=[row[-1] for row in a]
 res=[t-sum(v*w for v,w in zip(c,row)) for row,t in zip(x,y)]
 return c,math.sqrt(sum(v*v for v in res)/len(res))
for shape,data in rows.items():
 print(shape,sorted(data),'linear',fit(data,1),'quadratic',fit(data,2))
