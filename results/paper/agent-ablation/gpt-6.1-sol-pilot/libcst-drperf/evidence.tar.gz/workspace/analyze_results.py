"""Read saved supervisor reports only; never execute a workload."""
import json
from pathlib import Path
import numpy as np
out=[]
for report in sorted(Path('measurements').glob('round-*/profile.drperf.json')):
    for region in json.loads(report.read_text())['regions']:
        names=region['states']
        n=np.array([p['state'][names.index('terms')] for p in region['points']],dtype=float)
        y=np.array([p['observed'] for p in region['points']],dtype=float)
        q=n*(n-1)/2 if 'call' not in region['name'] else (2*n)*(2*n+1)/2
        record={'round':report.parent.name,'region':region['name'],'n':n.tolist(),'instructions':y.tolist(),'fits':{}}
        for label,A in [('linear',np.column_stack((np.ones(len(n)),n))),('prefix',np.column_stack((np.ones(len(n)),n,q)))]:
            coefficients=np.linalg.lstsq(A,y,rcond=None)[0]
            rel=(A@coefficients-y)/y
            train=np.arange(len(n)-1)
            hold_coeff=np.linalg.lstsq(A[train],y[train],rcond=None)[0]
            record['fits'][label]={'coefficients':coefficients.tolist(),'mean_abs_relative_error':float(np.mean(np.abs(rel))),'max_abs_relative_error':float(np.max(np.abs(rel))),'largest_point_holdout_relative_error':float((A[-1]@hold_coeff-y[-1])/y[-1])}
        record['drperf_regimes']=[{'unexplainedShare':g['unexplainedShare'],'coefficients':g['coefficients']} for g in region['regimes']]
        out.append(record)
print(json.dumps(out,indent=2))
