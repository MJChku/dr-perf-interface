import sys
None
import bench_support

def build(shape, n):
    if shape == 1:
        return 'x: ' + ' | '.join((f'T{i}' for i in range(n))) + ' = None\n'
    if shape == 2:
        return 'x = obj' + ''.join((f'.m{i}()' for i in range(n))) + '\n'
    return 'x = ' + ' + '.join((f'a{i}' for i in range(n))) + '\n'

def main():
    args = {}
    for a in sys.argv[1:]:
        if '=' in a:
            k, v = a.split('=', 1)
            args[k] = int(v)
    n = args.get('n_terms', 200)
    shape = args.get('shape', 0)
    import libcst
    src = build(shape, n)
    module = libcst.parse_module(src)
    print(f'n_terms={n} shape={shape} chars={len(src)} ok={module is not None}')
if __name__ == '__main__':
    main()
