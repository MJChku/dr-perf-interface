"""Specialize the existing no-gradient generation context for inference."""
import difflib,json,shutil
from pathlib import Path
P=Path(__file__).resolve().parent;src=P/'source';dst=P/'source-inference'
assert not dst.exists();shutil.copytree(src,dst,ignore=shutil.ignore_patterns('.git','__pycache__'))
rel='soprano/backends/transformers.py';a=(src/rel).read_text();old='        with torch.no_grad():\n            outputs = self.model.generate(';new='        with torch.inference_mode():\n            outputs = self.model.generate(';assert a.count(old)==1;b=a.replace(old,new);(dst/rel).write_text(b);(P/'inference-mode.patch').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
d=json.loads((P/'partial.json').read_text());d['name']='soprano-inference';d['files']['source']=str(dst);(P/'inference-after.json').write_text(json.dumps(d,indent=2)+'\n')
print('SOPRANO_INFERENCE_CANDIDATE_READY')
