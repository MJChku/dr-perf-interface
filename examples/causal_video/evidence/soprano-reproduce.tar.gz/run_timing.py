"""Run one managed timing capture, then report and audit before using numbers."""
import argparse,json,os,re,subprocess,time
from pathlib import Path
P=Path(__file__).resolve().parent;GX=Path('/home/ubuntu/GX/NEX')
p=argparse.ArgumentParser();p.add_argument('name');a=p.parse_args()
start=time.monotonic()
with (P/(a.name+'.log')).open('w')as f:
 r=subprocess.run(['python3',str(P.parent/'inferix-kv-14b-timing/run_on_worker.py'),str(P/(a.name+'.json'))],cwd=GX,env=os.environ|{'SSH_BASE_PORT':'2282'},stdout=f,stderr=subprocess.STDOUT)
paths=re.findall(r'(?:result|logs)=(/[^\s]+)',(P/(a.name+'.log')).read_text());assert paths
run=Path(paths[-1]);run=run.parent if run.name=='result.json' else run
result=json.loads((run/'result.json').read_text());assert r.returncode==0 and result['passed'] and not result['cleanup_errors'],result
with (P/(a.name+'-report.log')).open('w')as f:subprocess.run([str(GX/'tools/gxvm/gxvm'),'report',str(run)],cwd=GX,stdout=f,stderr=subprocess.STDOUT,check=True)
with (P/(a.name+'-audit.log')).open('w')as f:subprocess.run(['python3',str(P/'audit.py'),str(run),'--output',str(P/(a.name+'-audit.json')),'--cpu-db',json.loads((P/(a.name+'.json')).read_text())['files']['cpu_db']],stdout=f,stderr=subprocess.STDOUT,check=True)
(P/(a.name+'-run.json')).write_text(json.dumps({'run':str(run),'controller_wall_seconds':time.monotonic()-start,'result':result},indent=2)+'\n')
print('SOPRANO_TIMING_AUDIT_PASS',a.name,flush=True)
