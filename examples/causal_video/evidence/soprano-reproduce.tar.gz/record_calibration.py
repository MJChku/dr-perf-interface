import hashlib,json,sqlite3
from pathlib import Path
P=Path(__file__).resolve().parent;db=P/'gpu.sqlite';c=sqlite3.connect(f'file:{db}?mode=ro',uri=True)
d={'database_sha256':hashlib.sha256(db.read_bytes()).hexdigest(),'signatures':c.execute('SELECT count(*) FROM kernel_signatures').fetchone()[0],'observed_launches':c.execute('SELECT sum(count) FROM observed_launches').fetchone()[0],'skipped':c.execute('SELECT count(*) FROM skipped_launches').fetchone()[0],'scope':'Initial native A100 kernel-duration calibration. Isolated profile timing is not an unprofiled latency baseline.'};assert d['skipped']==0,d
r=json.loads((P/'kernel-profile.json').read_text());assert r['phase']=='completed';hashes={x['output_sha256']for x in r['iterations']+r['warmups']};assert len(hashes)==1,hashes
(P/'kernel-calibration.json').write_text(json.dumps(d,indent=2)+'\n');print('SOPRANO_CALIBRATION_PASS',d,hashes,flush=True)
