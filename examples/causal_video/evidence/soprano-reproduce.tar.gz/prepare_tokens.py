"""Batch post-generation EOS metadata transfer; keep selection semantics."""
import difflib,json,shutil
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parent;src=P/'source';dst=P/'source-tokens'
assert not dst.exists();shutil.copytree(src,dst,ignore=shutil.ignore_patterns('.git','__pycache__'))
rel='soprano/backends/transformers.py';a=(src/rel).read_text();b=a.replace('        for i in range(len(prompts)):\n            seq = outputs.sequences[i]', '        num_output_tokens = len(outputs.hidden_states)\n        non_eos = (outputs.sequences[:, -num_output_tokens:] != eos_token_id).cpu().tolist()\n        for i in range(len(prompts)):\n            seq = outputs.sequences[i]',1)
b=b.replace('            num_output_tokens = len(outputs.hidden_states)\n','',1).replace('                token = seq[j + seq.size(0) - num_output_tokens]\n                if token != eos_token_id:', '                if non_eos[i][j]:',1).replace("            finish_reason = 'stop' if seq[-1].item() == eos_token_id else 'length'", "            finish_reason = 'stop' if not non_eos[i][-1] else 'length'",1)
assert b!=a;(dst/rel).write_text(b);(P/'batch-tokens.patch').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
# For this fixed batch-one workload, the original per-token checks record
# exactly the non-EOS mask. This derives a tape, never an optimized output.
d=json.loads((P/'controls.json').read_text());arrays=dict(np.load(P/'controls.npz'));removed=[]
for i,events in enumerate(d['requests']):
 rows=[(j,x)for j,x in enumerate(events)if x['tag'][:3]==['__bool__','transformers.py','infer']];assert rows
 lo,hi=rows[0][0],rows[-1][0];assert [j for j,x in rows]==list(range(lo,hi+1));last=events[hi+1];assert last['tag'][:3]==['item','transformers.py','infer'];assert (last['value']==3)==(not rows[-1][1]['value'])
 key=f'batched_eos_{i}';arr=np.array([[x['value']for _,x in rows]],dtype=np.bool_);arrays[key]=arr
 event={'tag':['cpu','transformers.py','infer',list(arr.shape),'torch.bool'],'array':key};d['requests'][i]=events[:lo]+[event]+events[hi+2:];removed.append({'request':i,'removed_scalar_events':len(rows)+1,'added_cpu_mask':list(arr.shape)})
(P/'controls-tokens.json').write_text(json.dumps(d,indent=2)+'\n');np.savez_compressed(P/'controls-tokens.npz',**arrays);(P/'removed-token-controls.json').write_text(json.dumps(removed,indent=2)+'\n')
c=json.loads((P/'partial.json').read_text());c['name']='soprano-tokens';c['files'].update(source=str(dst),controls=str(P/'controls-tokens.json'),control_arrays=str(P/'controls-tokens.npz'));(P/'tokens-after.json').write_text(json.dumps(c,indent=2)+'\n')
print('SOPRANO_TOKEN_CANDIDATE_READY')
