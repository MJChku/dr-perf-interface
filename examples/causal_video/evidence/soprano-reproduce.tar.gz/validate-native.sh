#!/usr/bin/env bash
set -euo pipefail
ulimit -c 0
soprano_selected=$1
soprano_selected_controls=$2
soprano_selected_arrays=$3
export LD_LIBRARY_PATH=/workspace/causal/f5-tts/deps/ffmpeg/lib:/workspace/causal/sglang/cuda13_libs:/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cudnn/lib
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONHASHSEED=0 TOKENIZERS_PARALLELISM=false HF_HUB_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1
export HF_HOME=/workspace/causal/hf-cache LOCAL_FILES_ONLY=true
export FLASHINFER_DISABLE_VERSION_CHECK=1 VLLM_USE_V1=1 VLLM_WORKER_MULTIPROC_METHOD=spawn VLLM_ATTENTION_BACKEND=FLASH_ATTN
export TORCHINDUCTOR_CACHE_DIR=/workspace/causal/soprano/cache-native/inductor
export TRITON_CACHE_DIR=/workspace/causal/soprano/cache-native/triton
export TORCHINDUCTOR_COMPILE_THREADS=2
unset LD_PRELOAD GX_PREDICT_DB GX_PROFILE_SO GX_PROFILE_START_FILE GX_PROFILE_STOP_FILE
soprano_index=0
for soprano_side in before after after before; do
 soprano_index=$((soprano_index+1))
 soprano_source=source
 [[ $soprano_side == before ]] || soprano_source=$soprano_selected
 export PYTHONPATH=/workspace/causal/soprano/$soprano_source:/workspace/causal/soprano/deps:/workspace/causal/f5-tts/deps:/workspace/causal/qwen-tts/deps:/workspace/causal/qwen-tts/source:/workspace/causal/fastgen/deps:/workspace/causal/fastgen/source:/workspace/causal/omni/source:/workspace/causal/omni/extras:/workspace/causal/omni/deps:/workspace/causal/wan2gp/deps:/workspace/causal/wanwrapper/deps:/workspace/causal/sglang/cutlass:/workspace/causal/sglang/cutlass/nvidia_cutlass_dsl/dsl_packages:/workspace/causal/sglang/deps:/workspace/causal/sglang/kernel:/workspace/causal/sglang/source/python:/workspace/causal/deps:/workspace/causal/scope-deps:/workspace/causal/flashdreams-deps:/workspace/deps
 soprano_out=/workspace/causal/runs/soprano-plain-$soprano_index-$soprano_side
 [[ ! -e $soprano_out ]]
 timeout -k 20 900 python3 -u /workspace/causal/soprano/runner.py --model /workspace/causal/models/Soprano --output "$soprano_out" --role native --plain --warmup 3 --repetitions 7 > "$soprano_out.log" 2>&1
 printf 'SOPRANO_NATIVE_PROCESS_PASS %s %s\n' "$soprano_index" "$soprano_side"
done
for soprano_side in before after; do
 soprano_source=source
 soprano_controls=controls.json
 soprano_arrays=controls.npz
 if [[ $soprano_side == after ]]; then
  soprano_source=$soprano_selected
  soprano_controls=$soprano_selected_controls
  soprano_arrays=$soprano_selected_arrays
 fi
 export PYTHONPATH=/workspace/causal/soprano/$soprano_source:/workspace/causal/soprano/deps:/workspace/causal/f5-tts/deps:/workspace/causal/qwen-tts/deps:/workspace/causal/qwen-tts/source:/workspace/causal/fastgen/deps:/workspace/causal/fastgen/source:/workspace/causal/omni/source:/workspace/causal/omni/extras:/workspace/causal/omni/deps:/workspace/causal/wan2gp/deps:/workspace/causal/wanwrapper/deps:/workspace/causal/sglang/cutlass:/workspace/causal/sglang/cutlass/nvidia_cutlass_dsl/dsl_packages:/workspace/causal/sglang/deps:/workspace/causal/sglang/kernel:/workspace/causal/sglang/source/python:/workspace/causal/deps:/workspace/causal/scope-deps:/workspace/causal/flashdreams-deps:/workspace/deps
 soprano_out=/workspace/causal/runs/soprano-control-$soprano_side
 [[ ! -e $soprano_out ]]
 timeout -k 20 900 python3 -u /workspace/causal/soprano/runner.py --model /workspace/causal/models/Soprano --output "$soprano_out" --role native --controls /workspace/causal/soprano/"$soprano_controls" --control-arrays /workspace/causal/soprano/"$soprano_arrays" --warmup 1 --repetitions 1 > "$soprano_out.log" 2>&1
 printf 'SOPRANO_NATIVE_CONTROL_PASS %s\n' "$soprano_side"
done
