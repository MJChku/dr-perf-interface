"""Record simulation and native measurements separately, with compact traces."""
import gzip,hashlib,json,shutil,statistics,subprocess,sys,tarfile,tempfile
from pathlib import Path
P=Path(__file__).resolve().parent;E=P.parents[2]/'examples/causal_video';sys.path.insert(0,str(E))
from compact_gx_trace import compact
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins={'source':{'remote':'https://github.com/ekwek1/soprano.git','commit':subprocess.check_output(['git','-C',str(P/'source'),'rev-parse','HEAD'],text=True).strip()},'model':read(P/'model-manifest.json'),'dependencies':read(P/'kernel-profile.json')['versions'],'workload':read(P/'kernel-profile.json')['request'],'scope':read(P/'kernel-profile.json')['scope']};(P/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
limitations=[
 'One short English request,94,208samples at32kHz,seed42,temperature0 internally clamped to0.001,top_p0.95,repetition_penalty1.2,retries0. Original constructor warmup retained outside request timing. Not a throughput or all-prompt study.',
 'Official Transformers4.57.3 fallback backend with SDPA,79,714,048BF16Qwen3parameters and30,352,642FP32decoder parameters. The default auto backend prefers LMDeploy; this result does not characterize that backend.',
 'GX omits GPU arithmetic. Recorded scalar and CPU waveform values follow their original transfers. GX-only ISTFT shape adapter omits FFT-related work, based on earlier cuFFT failures in other systems; original FFT was not separately attempted under GX for Soprano. Native timing restores original operations; guarded runs check controls and FFT shapes.',
 'Baseline64native-only launches/request include FFT work and48FP32GEMV launches. Their isolated median sum0.571337ms/request is not an end-to-end correction. Selected before/after each have99,846GXlaunches across2requests with identical inventory and no prediction misses.',
 'CPU calibration197unresolved of4759instruction samples(4.14%),7unresolved task samples. GX and native CPU hosts differ; absolute GX times exceed native. This is not a matched-host timing accuracy study.',
 'Mode3 uses10us epochs. Identical GPU launch inventories can have different trace spans because synchronization and epoch granularity affect placement. Outside-GPU spans are a prioritization heuristic, not hardware utilization or a universal speedup bound.',
 'Native unprofiled ABBA has3warmups and7measured requests per process;14samples/variant,all retained. Native output hashes also match the initial calibration. Separate guarded outputs do not enter latency statistics.',
 'Token-batching ablation has only0.0849%mode2gain; it is not in the selected change and has no separate native validation. Its GX control mask was derived from initial scalar controls and CPU selection semantics pass108cases.',
]
out={'system':'Soprano','pins':pins,'change':'Replace no_grad with inference_mode only around the existing model.generate call. Original post-generation hidden-state stacking and CPU waveform return remain outside that context.','gx':{},'traces':{},'limitations':limitations,'native_kernel_calibration':read(P/'kernel-profile.json'),'kernel_calibration':read(P/'kernel-calibration.json'),'cpu_calibration':read(P/'cpu-calibration.json'),'omissions':read(P/'omissions.json'),'cpu_oracles':{'inference_output_type':read(P/'inference-oracle.json'),'token_batching':read(P/'token-oracle.json')},'additional_screen':{'change':'Batch post-generation EOS metadata transfer','before':read(P/'partial-audit.json'),'after':read(P/'tokens-after-audit.json'),'scope':'GXmode2only,0.0849%gain. Not selected; no standalone native validation.'},'selection':read(P/'selected.json')}
for mode,names in [('mode2',('partial','inference-after')),('mode3',('sync-before','sync-after'))]:
 pair={}
 for side,name in zip(('before','after'),names):
  a=read(P/(name+'-audit.json'));assert a['result']['passed']and not a['result']['cleanup_errors'];assert a['model']['runner_sha256']==sha(P/'runner.py');assert a['gpu_db_sha256']==sha(P/'gpu.sqlite')and a['cpu_db_sha256']==sha(P/'cpu.db')
  pair[side]=a|{'runtime':read(Path(a['run'])/'runtime.json'),'controller_wall_seconds':read(P/(name+'-run.json'))['controller_wall_seconds']};pair[side]['means']={k:statistics.mean(x[k]for x in a['iterations'])for k in ('virtual_seconds','cpu_seconds','gpu_span_seconds','outside_gpu_spans_seconds')}
  dst=E/f'evidence/soprano-{mode}-{side}.chrome.json.gz';src=Path(a['run'])/'timeline-report/trace.json.gz';out['traces'][mode+'_'+side]={'file':dst.name,'full_trace':str(src),**compact(src,dst,bin_ms=1)}
 assert pair['before']['runtime']['dynamorio']==pair['after']['runtime']['dynamorio']
 assert pair['before']['model']['iterations'][0]['control_count']==197 and pair['after']['model']['iterations'][0]['control_count']==197;assert pair['before']['launches']==pair['after']['launches'];assert all(x['iterations'][0]['copy_bytes']==pair['before']['iterations'][0]['copy_bytes']for x in pair.values())
 pair['request_reduction_percent']=100*(1-pair['after']['means']['virtual_seconds']/pair['before']['means']['virtual_seconds']);out['gx'][mode]=pair
for key,name,nexpected in [('native_A100','native-summary.json',28)]:
 n=read(P/name);assert n['measured_output_checks']==nexpected
 for block in n['reports']:
  report=block['report'];g=out['gx']['mode2'][block['side']]['model'];assert report['versions']==g['versions']and report['source_sha256']==g['source_sha256'];assert report['plain']and report['runner_sha256']==sha(P/'runner.py');assert {x['output_sha256']for x in report['iterations']}=={n['output_sha256']}
 for x in n['control_reports']:
  d=x['report'];assert all(e['native_shape_checked']for e in d['fft_adapters']);assert {r['output_sha256']for r in d['warmups']+d['iterations']}=={n['output_sha256']}
 out[key]=n|{'hardware':read(P/'native-validation-hardware.json')}
with tempfile.TemporaryDirectory(prefix='soprano-patch-')as td:
 root=Path(td);shutil.copytree(P/'source',root/'source',ignore=shutil.ignore_patterns('.git','__pycache__'))
 subprocess.run(['git','apply',str(P/'inference-mode.patch')],cwd=root/'source',check=True)
 for rel in ['soprano/backends/transformers.py']:assert (root/'source'/rel).read_bytes()==(P/'source-inference'/rel).read_bytes()
out['patch_application_checked']=True
shutil.copyfile(P/'runner.py',E/'soprano_runner.py');shutil.copyfile(P/'inference-mode.patch',E/'cpu_patches/soprano_inference_mode.patch')
files=['pins.json','runner.py','build_runner.py','inference-mode.patch','batch-tokens.patch','prepare_inference.py','prepare_tokens.py','selected.json','model-manifest.json','model-metadata.json','download_model.py','controls.json','controls.npz','controls-tokens.json','controls-tokens.npz','removed-token-controls.json','emu-fft.json','cpu.json','partial.json','inference-after.json','tokens-after.json','sync-before.json','sync-after.json','audit.py','run_timing.py','run_cpu.py','profile.sh','run_native_profile.py','stage_native.py','kernel-calibration.json','cpu-calibration.json','omissions.json','record_calibration.py','record_omissions.py','native-identities.json','native-validation-identities.json','native-profile-hardware.json','native-validation-hardware.json','run_native_validation.py','validate-native.sh','token_oracle.py','token-oracle.json','inference_oracle.py','inference-oracle.json','package_results.py']
bundle=E/'evidence/soprano-reproduce.tar.gz'
with tarfile.open(bundle,'w:gz')as t:
 for name in files:t.add(P/name,arcname=name)
with tarfile.open(bundle,'r:gz')as t:
 assert sorted(t.getnames())==sorted(files)
 for name in files:assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==sha(P/name)
out['reproduction']={'file':bundle.name,'sha256':sha(bundle),'files':files,'note':'Install pinned source/dependencies, adjust host/file paths, and apply inference-mode.patch to the selected source. Both calibration and final comparison use the same runner.py and unmodified control tape. Constructor warmup is request0 of the tape. Native plain timing restores all tensor/FFT hooks. Token-batching patch/tape is an unselected ablation.'}
dbdir=E/'evidence/kernel-databases';manifest=read(dbdir/'manifest.json');artifacts={}
for key,name,target in [('native_database','gpu.sqlite','soprano.sqlite.gz'),('native_report','kernel-profile.json','soprano.report.json.gz'),('cpu_instruction_calibration','cpu.db','soprano.cpu.db.gz')]:
 raw=(P/name).read_bytes();dst=dbdir/target;dst.write_bytes(gzip.compress(raw,compresslevel=9,mtime=0));assert gzip.decompress(dst.read_bytes())==raw;artifacts[key]={'file':target,'uncompressed_bytes':len(raw),'uncompressed_sha256':sha(P/name),'gzip_sha256':sha(dst)}
manifest['artifacts']['soprano']=artifacts;(dbdir/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');out['calibration']=artifacts
allpins=read(E/'pins.json');allpins['Soprano']=pins;(E/'pins.json').write_text(json.dumps(allpins,indent=2)+'\n');(E/'evidence/soprano-cpu.json').write_text(json.dumps(out,indent=2)+'\n')
print('SOPRANO_PACKAGE_PASS',json.dumps({'gx':{m:x['request_reduction_percent']for m,x in out['gx'].items()},'native_median':out['native_A100']['median_reduction_percent'],'native_mean':out['native_A100']['mean_reduction_percent']}),flush=True)
