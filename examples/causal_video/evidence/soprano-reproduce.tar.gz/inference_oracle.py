"""Check API outputs remain ordinary tensors despite scoped inference context."""
import ast,json,types,torch
from pathlib import Path
P=Path(__file__).resolve().parent
def load(folder):
 tree=ast.parse((P/folder/'soprano/backends/transformers.py').read_text());cls=next(x for x in tree.body if isinstance(x,ast.ClassDef));fn=next(x for x in cls.body if isinstance(x,ast.FunctionDef)and x.name=='infer');ns={'torch':torch};exec(compile(ast.Module(body=[fn],type_ignores=[]),folder,'exec'),ns);return ns['infer']
class Inputs(dict):
 def to(self,device):return self
class Tokenizer:
 pad_token_id=3
 def __call__(self,*a,**kw):return Inputs(input_ids=torch.tensor([[1,2]]),attention_mask=torch.ones(1,2,dtype=torch.long))
checks=[]
for grad in [False,True]:
 for folder in ['source','source-inference']:
  modes=[]
  def generate(**kw):
   modes.append(torch.is_inference_mode_enabled());return types.SimpleNamespace(sequences=torch.tensor([[1,2,4,5,3]]),hidden_states=tuple((torch.ones(1,1,8)*j,)for j in range(3)))
  obj=types.SimpleNamespace(device='cpu',tokenizer=Tokenizer(),model=types.SimpleNamespace(config=types.SimpleNamespace(eos_token_id=3),generate=generate))
  with torch.set_grad_enabled(grad):out=load(folder)(obj,['x'])[0]
  h=out['hidden_state'];assert not h.is_inference()and not h.requires_grad;assert torch.equal(h,torch.stack([torch.zeros(8),torch.ones(8)]));assert modes==[folder=='source-inference'];assert out['finish_reason']=='stop';checks.append({'source':folder,'caller_grad_enabled':grad,'generation_inference_mode':modes[0],'output_is_inference':h.is_inference()})
(P/'inference-oracle.json').write_text(json.dumps({'passed':True,'scope':'Actual original/candidate infer function with mocked generation creating tensors inside the actual context. Confirms final stacked hidden-state tensor remains ordinary and matches. Real waveform separately validated on A100.','checks':checks},indent=2)+'\n');print('SOPRANO_INFERENCE_OUTPUT_TYPE_PASS')
