from pathlib import Path
P=Path(__file__).resolve().parent
s=(P.parent/'kokoro/runner.py').read_text();s=s[:s.index('original_arange=')]
s=s.replace('Kokoro public API','Soprano public API').replace("spec={'text':'Hello. This is a test of speech generation.','voice':'af_heart','speed':1.0,'seed':42}","spec={'text':'Hello. This is a test of speech generation.','temperature':0.0,'top_p':0.95,'repetition_penalty':1.2,'retries':0,'seed':42}")
s+='''from soprano import SopranoTTS
import soprano
fft_adapters=[]
original_istft=torch.istft
def istft(input,*args,**kwargs):
 if not tape.active:return original_istft(input,*args,**kwargs)
 key=tag('istft_shape',input,sys._getframe(1))
 assert input.ndim==3 and len(args)>=3 and tuple(args[:3])==(2048,512,2048) and kwargs.get('center') is True
 if physical or not a.fft_shape_adapter:
  out=original_istft(input,*args,**kwargs);info={'shape':list(out.shape),'dtype':str(out.dtype)};tape.exchange(key,info)
 else:
  info=tape.exchange(key);out=torch.empty(info['shape'],device=input.device,dtype=getattr(torch,info['dtype'].split('.')[-1]))
 fft_adapters.append({'operation':'istft','input':list(input.shape),'output':info,'native_shape_checked':physical})
 return out
torch.istft=istft
root=Path(soprano.__file__).parent
report={'phase':'loading','role':a.role,'plain':a.plain,'fft_shape_adapter':a.fft_shape_adapter,'request':spec,'scope':'Original SopranoTTS.infer with official Transformers backend, public text preprocessing, autoregressive generation, Vocos decoder and CPU waveform return. Constructor warmup retained outside measured requests. No file encoding or playback. Default LMDeploy-preferred auto backend is not measured.','runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':{str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest()for f in root.rglob('*.py')},'versions':{n:version(n)for n in ('torch','torchaudio','transformers','numpy','inflect','Unidecode')},'control_reference_sha256':hashlib.sha256(a.controls.read_bytes()).hexdigest()if a.controls else None,'warmups':[],'iterations':[]}
def save():(a.output/'report.json').write_text(json.dumps(report,indent=2)+'\\n')
def seed():torch.manual_seed(42);torch.cuda.manual_seed_all(42);np.random.seed(42);random.seed(42)
if a.plain:
 for name,fn in original.items():setattr(torch.Tensor,name,fn)
 torch.istft=original_istft
save();seed();tape.start(0);start=time.perf_counter();model=SopranoTTS(backend='transformers',device='cuda',model_path=str(a.model));torch.cuda.synchronize();tape.finish()
report.update(phase='loaded',load_host_seconds=time.perf_counter()-start,bootstrap_controls=tape.cursor,parameters=sum(p.numel()for p in model.pipeline.model.parameters()),decoder_parameters=sum(p.numel()for p in model.decoder.parameters()),model_dtype=str(next(model.pipeline.model.parameters()).dtype),decoder_dtype=str(next(model.decoder.parameters()).dtype),model_attention_implementation=model.pipeline.model.config._attn_implementation);save();print('SOPRANO_LOADED',report['load_host_seconds'],flush=True)
def generate(index):
 seed();tape.start(index+1);out=model.infer(**{k:v for k,v in spec.items()if k!='seed'});torch.cuda.synchronize();return out
def check(out):
 w=out.numpy();assert w.ndim==1 and len(w)>0
 row={'sample_rate':32000,'samples':len(w),'dtype':str(w.dtype),'control_count':tape.cursor}
 if physical:
  assert np.isfinite(w).all();row.update(finite=True,output_sha256=hashlib.sha256(w.tobytes()).hexdigest(),minimum=float(w.min()),maximum=float(w.max()))
 return row
for i in range(a.warmup):
 out=generate(i);tape.finish();report['warmups'].append(check(out));save()
print('SOPRANO_WARMUP_DONE',flush=True)
rt=ctypes.CDLL(None)
if a.role=='partial_sync':rt.gxvm_adopt_now();rt.gxvm_timeline_mark.argtypes=[ctypes.c_uint,ctypes.c_int]
if a.role=='cpu-profile':rt.gxvm_ipc_profile_start()
if a.role=='gpu-profile':Path(os.environ['GX_PROFILE_START_FILE']).touch(exist_ok=False)
for i in range(a.repetitions):
 if a.role=='partial_sync':rt.gxvm_timeline_mark(i+1,0)
 start=time.perf_counter();out=generate(a.warmup+i);elapsed=time.perf_counter()-start
 if a.role=='partial_sync':rt.gxvm_timeline_mark(i+1,1)
 tape.finish();report['iterations'].append(check(out)|{'iteration':i+1,'application_clock_seconds':elapsed});save()
if a.role=='cpu-profile':assert rt.gxvm_ipc_profile_stop()==0
if a.role=='gpu-profile':Path(os.environ['GX_PROFILE_STOP_FILE']).touch(exist_ok=False)
if reference is None and not a.plain:
 (a.output/'controls.json').write_text(json.dumps({'request':spec,'requests':tape.records},indent=2)+'\\n');np.savez_compressed(a.output/'controls.npz',**tape.arrays)
report.update(phase='completed',fft_adapters=fft_adapters,peak_gpu_bytes=torch.cuda.max_memory_allocated(),peak_reserved_gpu_bytes=torch.cuda.max_memory_reserved(),peak_host_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024)
save();print('SOPRANO_COMPLETE',json.dumps({k:v for k,v in report.items()if k!='source_sha256'}),flush=True)
'''
(P/'runner.py').write_text(s)
