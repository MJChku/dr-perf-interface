"""Exercise the actual old/new infer functions with deterministic generation outputs."""
import ast,json,itertools,types
from pathlib import Path
import torch
P=Path(__file__).resolve().parent
def load(name):
 tree=ast.parse((P/name/'soprano/backends/transformers.py').read_text());cls=next(x for x in tree.body if isinstance(x,ast.ClassDef));fn=next(x for x in cls.body if isinstance(x,ast.FunctionDef)and x.name=='infer');ns={'torch':torch};exec(compile(ast.Module(body=[fn],type_ignores=[]),str(P/name),'exec'),ns);return ns['infer']
a,b=load('source'),load('source-tokens');torch.manual_seed(42)
class Inputs(dict):
 def to(self,device):return self
class Tokenizer:
 pad_token_id=3
 def __call__(self,*args,**kwargs):return Inputs(input_ids=torch.tensor([[1,2]]),attention_mask=torch.ones(1,2,dtype=torch.long))
rows=[]
for batch,tokens,dtype,mode in itertools.product([1,2,4],[1,3,17],[torch.float32,torch.float16,torch.bfloat16],['none','end','interior','all']):
 seq=torch.randint(4,99,(batch,2+tokens));seq[:,:2]=torch.tensor([1,2])
 if mode=='end':seq[:,-1]=3
 if mode=='interior':
  for i in range(batch):seq[i,2+i%tokens::2]=3
 if mode=='all':seq[:,2:]=3
 hs=tuple((torch.randn(batch,2 if j==0 else 1,8,dtype=dtype),)for j in range(tokens));outputs=types.SimpleNamespace(sequences=seq,hidden_states=hs)
 model=types.SimpleNamespace(config=types.SimpleNamespace(eos_token_id=3),generate=lambda **kw:outputs);obj=types.SimpleNamespace(device='cpu',tokenizer=Tokenizer(),model=model)
 results=[]
 for fn in (a,b):
  try:results.append(fn(obj,['x']*batch))
  except RuntimeError as e:results.append((type(e).__name__,str(e)))
 if isinstance(results[0],tuple):assert results[0]==results[1]
 else:
  assert len(results[0])==len(results[1])==batch
  for x,y in zip(*results):assert x['finish_reason']==y['finish_reason'] and torch.equal(x['hidden_state'],y['hidden_state'])and x['hidden_state'].shape==y['hidden_state'].shape
 rows.append({'batch':batch,'tokens':tokens,'dtype':str(dtype),'eos_pattern':mode,'matching_error':isinstance(results[0],tuple)})
(P/'token-oracle.json').write_text(json.dumps({'passed':True,'cases':len(rows),'scope':'Actual original/candidate infer functions with mocked model generation, exact hidden-state selections/shapes/finish reasons and matching empty-selection errors. Does not validate real model waveform.','rows':rows},indent=2)+'\n');print('SOPRANO_TOKEN_ORACLE_PASS',len(rows))
