"""Avoid computing GPU diagnostics when the root debug logger is disabled."""
import difflib,json,shutil
from pathlib import Path
P=Path(__file__).resolve().parent;src=P/'source';dst=P/'source-debug';
if not dst.exists():shutil.copytree(src,dst,ignore=shutil.ignore_patterns('.git','__pycache__'))
rel='zipvoice/models/modules/zipformer.py';a=(src/rel).read_text();old='    def _print_attn_entropy(self, attn_weights: Tensor):\n';new=old+'''        if not logging.getLogger().isEnabledFor(logging.DEBUG):
            return
''';assert a.count(old)==1;b=a.replace(old,new);(dst/rel).write_text(b);(P/'debug-guard.patch').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
d=json.loads((P/'controls.json').read_text());notes=[]
for i,events in enumerate(d['requests']):
 selected=[x for x in events if x['tag'][1]in('_tensor_str.py','_tensor.py')];assert len(selected)==13
 d['requests'][i]=[x for x in events if x['tag'][1]not in('_tensor_str.py','_tensor.py')];notes.append({'request':i,'removed_disabled_diagnostic_controls':selected,'preserved_all_application_random_draws':True})
(P/'controls-debug.json').write_text(json.dumps(d,indent=2)+'\n');(P/'removed-debug-controls.json').write_text(json.dumps(notes,indent=2)+'\n')
c=json.loads((P/'partial.json').read_text());c['name']='zipvoice-debug';c['files'].update(source=str(dst),controls=str(P/'controls-debug.json'));(P/'debug-after.json').write_text(json.dumps(c,indent=2)+'\n');print('ZIPVOICE_DEBUG_CANDIDATE_READY')
