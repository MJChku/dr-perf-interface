"""Compare the actual duration/index helpers on valid variable-length batches."""
import ast,json,random,typing,torch
from pathlib import Path
P=Path(__file__).resolve().parent
def load(folder):
 tree=ast.parse((P/folder/'zipvoice/utils/common.py').read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in ('prepare_avg_tokens_durations','get_tokens_index')];ns={'torch':torch,'List':typing.List};exec(compile(ast.Module(body=nodes,type_ignores=[]),folder,'exec'),ns);return ns
old,new=load('source'),load('source-metadata');random.seed(42);rows=[]
for batch in [1,2,5]:
 for dtype in [torch.int32,torch.int64]:
  for trial in range(30):
   features=torch.tensor([random.randrange(0,4097)for _ in range(batch)],dtype=dtype);tokens=torch.tensor([random.randrange(1,129)for _ in range(batch)],dtype=dtype);num_frames=int(features.max())+random.randrange(0,17)
   for lists in [False,True]:
    args=(features.tolist(),tokens.tolist())if lists else(features,tokens)
    a=old['prepare_avg_tokens_durations'](*args);b=new['prepare_avg_tokens_durations'](*args)
    assert [[int(v)for v in row]for row in a]==b
    x=old['get_tokens_index'](a,num_frames);y=new['get_tokens_index'](b,num_frames);assert torch.equal(x,y)and x.dtype==y.dtype and x.shape==y.shape
    rows.append({'batch':batch,'dtype':str(dtype),'input_lists':lists,'features':features.tolist(),'tokens':tokens.tolist(),'num_frames':num_frames})
(P/'metadata-oracle.json').write_text(json.dumps({'passed':True,'cases':len(rows),'scope':'Actual original/candidate helpers, valid nonnegative feature lengths and positive token counts, mixed batch lengths, zero feature lengths, extra padded frames, list and CPU integer-tensor inputs. Real CUDA waveform/derived-array validation remains separate.','rows':rows},indent=2)+'\n');print('ZIPVOICE_METADATA_ORACLE_PASS',len(rows))
