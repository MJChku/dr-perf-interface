"""ZipVoice public API and recorded GPU-control replay for GX."""
import argparse,ctypes,hashlib,json,os,random,resource,sys,time
from pathlib import Path
from importlib.metadata import version
import numpy as np
import torch
p=argparse.ArgumentParser();p.add_argument('--model',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--role',choices=['gpu-profile','native','emu','cpu-profile','partial_sync'],required=True);p.add_argument('--controls',type=Path);p.add_argument('--control-arrays',type=Path);p.add_argument('--warmup',type=int,default=2);p.add_argument('--repetitions',type=int,default=1);p.add_argument('--plain',action='store_true');p.add_argument('--fft-shape-adapter',action='store_true');a=p.parse_args()
a.output.mkdir(parents=True,exist_ok=False);os.chdir(a.output)
physical=a.role in ('gpu-profile','native');assert physical or a.controls;assert not a.plain or a.role=='native'
spec={'prompt_text':'Some call me nature, others call me mother nature.','text':'This is a test of speech generation.','num_step':16,'guidance_scale':1.0,'speed':1.0,'t_shift':0.5,'seed':42}
reference=json.loads(a.controls.read_text())if a.controls else None
if reference:assert reference['request']==spec
ref_arrays=dict(np.load(a.control_arrays or a.controls.with_suffix('.npz')))if reference else {}
ref_tensors={k:torch.from_numpy(v)for k,v in ref_arrays.items()}
torch.set_num_threads(1);torch.set_num_interop_threads(1)
original={name:getattr(torch.Tensor,name)for name in ('item','__bool__','__int__','__index__','cpu','to','__getitem__')}
class Tape:
 def __init__(self):self.active=False;self.records=[];self.arrays={}
 def start(self,index):
  self.active=not a.plain;self.index=index;self.events=[];self.cursor=0
  self.selected=reference['requests'][min(index,len(reference['requests'])-1)]if reference else None
 def finish(self):
  self.active=False
  if self.selected is not None and not a.plain:assert self.cursor==len(self.selected),(self.cursor,len(self.selected))
  self.records.append(self.events)
 def exchange(self,tag,value=None,tensor=None):
  if self.selected is not None:
   expected=self.selected[self.cursor];assert expected['tag']==tag,('control path',self.cursor,tag,expected['tag'])
   if tensor is not None:
    key=expected['array'];target=ref_tensors[key]
    if physical:assert torch.equal(tensor,target),('native CPU array mismatch',tag)
    result=target
   else:
    if physical:assert value==expected['value'],('native scalar mismatch',tag,value,expected['value'])
    result=expected['value']
   event=expected
  else:
   assert physical
   if tensor is not None:
    key=f'r{self.index}_e{self.cursor}';self.arrays[key]=tensor.numpy().copy();event={'tag':tag,'array':key};result=tensor
   else:event={'tag':tag,'value':value};result=value
  self.events.append(event);self.cursor+=1;return result

tape=Tape()
original_random=random.random
def application_random():
 value=original_random();frame=sys._getframe(1);filename=Path(frame.f_code.co_filename).name
 if tape.active and filename in ('zipformer.py','scaling.py'):
  return tape.exchange(['random',filename,frame.f_code.co_name],value if physical else None)
 return value
random.random=application_random
def tag(name,t,frame):return [name,Path(frame.f_code.co_filename).name,frame.f_code.co_name,list(t.shape),str(t.dtype)]
for name in ('item','__bool__','__int__','__index__'):
 def scalar(t,*args,_name=name,**kwargs):
  if not tape.active or t.device.type!='cuda':return original[_name](t,*args,**kwargs)
  frame=sys._getframe(1);value=original[_name](t,*args,**kwargs)
  return tape.exchange(tag(_name,t,frame),value if physical else None)
 setattr(torch.Tensor,name,scalar)
def cpu(t,*args,**kwargs):
 result=original['cpu'](t,*args,**kwargs)
 if not tape.active or t.device.type!='cuda':return result
 frame=sys._getframe(1);key=tag('cpu',t,frame)
 # Preloaded native host values keep post-GPU CPU work (including the original
 # watermark) on real inputs. Preserve the original D2H copy and stream wait.
 if physical:return tape.exchange(key,tensor=result)
 expected=tape.selected[tape.cursor];assert expected['tag']==key,(key,expected['tag'])
 return tape.exchange(key,tensor=ref_tensors[expected['array']])
torch.Tensor.cpu=cpu
def getitem(t,index):
 result=original['__getitem__'](t,index)
 if tape.active and isinstance(index,torch.Tensor) and index.dtype==torch.bool and index.device.type=='cuda':
  frame=sys._getframe(1);shape=tape.exchange(tag('boolean_index_shape',t,frame),list(result.shape)if physical else None)
  if not physical and list(result.shape)!=shape:result=t.new_empty(shape)
 return result
torch.Tensor.__getitem__=getitem
# Preserve explicit GPU-to-CPU length transfers used by packed-RNN helpers.
def to_cpu(t,*args,**kwargs):
 result=original['to'](t,*args,**kwargs)
 if not tape.active or t.device.type!='cuda' or result.device.type!='cpu':return result
 frame=sys._getframe(1);key=tag('to_cpu',t,frame)
 if physical:return tape.exchange(key,tensor=result)
 expected=tape.selected[tape.cursor];assert expected['tag']==key,(key,expected['tag'])
 return tape.exchange(key,tensor=ref_tensors[expected['array']])
torch.Tensor.to=to_cpu
original_arange=torch.arange
original_stft=torch.stft;original_istft=torch.istft;original_irfft=torch.fft.irfft
fft_adapters=[]
def arange(*args,**kwargs):
 tensors=[x for x in args if isinstance(x,torch.Tensor)and x.device.type=='cuda']
 if tape.active and tensors:
  key=tag('arange_shape',tensors[0],sys._getframe(1))
  if physical:
   result=original_arange(*args,**kwargs);tape.exchange(key,list(result.shape));return result
  assert len(args)==1
  original['item'](tensors[0]) # retain scalar read/copy/wait
  shape=tape.exchange(key);assert len(shape)==1
  return original_arange(shape[0],**kwargs)
 return original_arange(*args,**kwargs)
torch.arange=arange
for fft_name,fft_original in [('stft',original_stft),('istft',original_istft),('irfft',original_irfft)]:
 def fft(*args,_name=fft_name,_fn=fft_original,**kwargs):
  x=args[0]if args else kwargs['input']
  if not tape.active or x.device.type!='cuda':return _fn(*args,**kwargs)
  key=tag(_name+'_shape',x,sys._getframe(1))
  if physical or not a.fft_shape_adapter:
   result=_fn(*args,**kwargs)
   if physical:shape=tape.exchange(key,{'shape':list(result.shape),'dtype':str(result.dtype)})
   else:shape=tape.exchange(key)
   assert list(result.shape)==shape['shape']and str(result.dtype)==shape['dtype']
  else:
   shape=tape.exchange(key);result=torch.empty(shape['shape'],dtype=getattr(torch,shape['dtype'].split('.')[-1]),device=x.device)
  fft_adapters.append({'operation':_name,'input':list(x.shape),'output':shape,'native_shape_checked':physical})
  return result
 if fft_name=='irfft':torch.fft.irfft=fft
 else:setattr(torch,fft_name,fft)
shape_adapters=[]
original_zeros=torch.zeros
def zeros(*args,**kwargs):
 positions=[i for i,v in enumerate(args)if isinstance(v,torch.Tensor)and v.device.type=='cuda']
 if not tape.active or not positions:return original_zeros(*args,**kwargs)
 key=tag('zeros_shape',args[positions[0]],sys._getframe(1))
 if physical:
  out=original_zeros(*args,**kwargs);shape=tape.exchange(key,list(out.shape))
 else:
  for i in positions:original['item'](args[i])
  shape=tape.exchange(key);concrete=list(args)
  for i in positions:concrete[i]=shape[i]
  out=original_zeros(*concrete,**kwargs)
 assert list(out.shape)==shape;shape_adapters.append({'operation':'zeros','shape':shape,'native_shape_checked':physical});return out
torch.zeros=zeros
import torchaudio
from zipvoice.bin.infer_zipvoice import ZipVoice,EmiliaTokenizer,VocosFbank,get_vocoder,load_checkpoint,generate_sentence
import zipvoice
root=Path(sys.modules['zipvoice.bin.infer_zipvoice'].__file__).parents[1]
report={'phase':'loading','role':a.role,'plain':a.plain,'fft_shape_adapter':a.fft_shape_adapter,'request':spec,'scope':'Original ZipVoice generate_sentence with original prompt loading/silence trimming, Emilia text tokenization, feature extraction,16-step sampling, Vocos decode, output silence trimming and WAV encoding. Resident pretrained FP32 models, supported PyTorch Swoosh fallback (k2 absent); inference_mode as in original CLI. Checkpoint load outside request.','runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':{str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest()for f in root.rglob('*.py')},'versions':{n:version(n)for n in ('torch','torchaudio','transformers','numpy','lhotse','vocos','pydub','cn2an','jieba','piper_phonemize','torchcodec')},'control_reference_sha256':hashlib.sha256(a.controls.read_bytes()).hexdigest()if a.controls else None,'warmups':[],'iterations':[]}
def save():(a.output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def seed():torch.manual_seed(42);torch.cuda.manual_seed_all(42);np.random.seed(42);random.seed(42)
save();seed();start=time.perf_counter();tokenizer=EmiliaTokenizer(token_file=a.model/'zipvoice/tokens.txt');config=json.loads((a.model/'zipvoice/model.json').read_text());model=ZipVoice(**config['model'],vocab_size=tokenizer.vocab_size,pad_id=tokenizer.pad_id);load_checkpoint(filename=a.model/'zipvoice/model.pt',model=model,strict=True);model=model.to('cuda').eval();vocoder=get_vocoder(str(a.model/'vocos')).to('cuda').eval();feature_extractor=VocosFbank()
report.update(phase='loaded',load_host_seconds=time.perf_counter()-start,parameters=sum(p.numel()for p in model.parameters()),vocoder_parameters=sum(p.numel()for p in vocoder.parameters()),model_dtype=str(next(model.parameters()).dtype),vocoder_dtype=str(next(vocoder.parameters()).dtype),reference_sha256=hashlib.sha256((a.model/'reference.wav').read_bytes()).hexdigest());save();print('ZIPVOICE_LOADED',report['load_host_seconds'],flush=True)
if a.plain:
 random.random=original_random
 for name,fn in original.items():setattr(torch.Tensor,name,fn)
 torch.arange=original_arange;torch.stft=original_stft;torch.istft=original_istft;torch.fft.irfft=original_irfft;torch.zeros=original_zeros
@torch.inference_mode()
def generate(index):
 seed();tape.start(index);out=generate_sentence(save_path=str(a.output/'output.wav'),prompt_wav=str(a.model/'reference.wav'),model=model,vocoder=vocoder,tokenizer=tokenizer,feature_extractor=feature_extractor,device=torch.device('cuda'),**{k:v for k,v in spec.items()if k!='seed'});torch.cuda.synchronize();return out
def check(out):
 wave,sr=torchaudio.load(str(a.output/'output.wav'));w=wave.numpy();row={'sample_rate':sr,'samples':wave.shape[-1],'shape':list(wave.shape),'dtype':str(w.dtype),'control_count':tape.cursor,'output_file_bytes':(a.output/'output.wav').stat().st_size}
 if physical:
  assert np.isfinite(w).all();row.update(finite=True,output_sha256=hashlib.sha256(w.tobytes()).hexdigest(),file_sha256=hashlib.sha256((a.output/'output.wav').read_bytes()).hexdigest(),minimum=float(w.min()),maximum=float(w.max()))
 return row
for i in range(a.warmup):
 out=generate(i);tape.finish();report['warmups'].append(check(out));save()
print('ZIPVOICE_WARMUP_DONE',flush=True)
rt=ctypes.CDLL(None)
if a.role=='partial_sync':rt.gxvm_adopt_now();rt.gxvm_timeline_mark.argtypes=[ctypes.c_uint,ctypes.c_int]
if a.role=='cpu-profile':rt.gxvm_ipc_profile_start()
if a.role=='gpu-profile':Path(os.environ['GX_PROFILE_START_FILE']).touch(exist_ok=False)
for i in range(a.repetitions):
 if a.role=='partial_sync':rt.gxvm_timeline_mark(i+1,0)
 start=time.perf_counter();out=generate(a.warmup+i);elapsed=time.perf_counter()-start
 if a.role=='partial_sync':rt.gxvm_timeline_mark(i+1,1)
 tape.finish();report['iterations'].append(check(out)|{'iteration':i+1,'application_clock_seconds':elapsed});save()
if a.role=='cpu-profile':assert rt.gxvm_ipc_profile_stop()==0
if a.role=='gpu-profile':Path(os.environ['GX_PROFILE_STOP_FILE']).touch(exist_ok=False)
if reference is None and not a.plain:
 (a.output/'controls.json').write_text(json.dumps({'request':spec,'requests':tape.records},indent=2)+'\n');np.savez_compressed(a.output/'controls.npz',**tape.arrays)
report.update(phase='completed',fft_adapters=fft_adapters,shape_adapters=shape_adapters,peak_gpu_bytes=torch.cuda.max_memory_allocated(),peak_reserved_gpu_bytes=torch.cuda.max_memory_reserved(),peak_host_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024)
save();print('ZIPVOICE_COMPLETE',json.dumps({k:v for k,v in report.items()if k!='source_sha256'}),flush=True)
