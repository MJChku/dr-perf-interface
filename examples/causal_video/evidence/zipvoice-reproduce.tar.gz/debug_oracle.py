import ast,json,logging,random,types,torch
from pathlib import Path
P=Path(__file__).resolve().parent
def load(folder):
 tree=ast.parse((P/folder/'zipvoice/models/modules/zipformer.py').read_text());fn=next(x for c in tree.body if isinstance(c,ast.ClassDef)for x in c.body if isinstance(x,ast.FunctionDef)and x.name=='_print_attn_entropy');ns={'torch':torch,'Tensor':torch.Tensor,'logging':logging};exec(compile(ast.Module(body=[fn],type_ignores=[]),folder,'exec'),ns);return ns[fn.name]
class Capture(logging.Handler):
 def emit(self,record):self.rows.append(record.getMessage())
h=Capture();h.rows=[];root=logging.getLogger();level=root.level;root.addHandler(h);obj=types.SimpleNamespace(name='oracle');x=torch.softmax(torch.arange(256,dtype=torch.float32).reshape(4,1,8,8),-1);rows=[]
try:
 for setting in [logging.WARNING,logging.DEBUG]:
  outcomes=[];root.setLevel(setting)
  for folder in ['source','source-debug']:
   h.rows=[];before=random.getstate();out=load(folder)(obj,x);assert out is None and before==random.getstate();outcomes.append(h.rows.copy())
  assert outcomes[0]==outcomes[1];assert bool(outcomes[1])==(setting==logging.DEBUG);rows.append({'level':logging.getLevelName(setting),'identical_diagnostic_messages':outcomes[0]})
finally:root.setLevel(level);root.removeHandler(h)
(P/'debug-oracle.json').write_text(json.dumps({'passed':True,'scope':'Actual original/candidate entropy method preserves enabled-debug messages and Python RNG state; disabled-debug messages absent in both. Numerical waveform validated separately.','checks':rows},indent=2)+'\n');print('ZIPVOICE_DEBUG_ORACLE_PASS')
