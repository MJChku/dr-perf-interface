"""Move length metadata to the CPU once before the existing CPU index loop."""
import difflib,json,shutil
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parent;src=P/'source';dst=P/'source-metadata';
if not dst.exists():shutil.copytree(src,dst,ignore=shutil.ignore_patterns('.git','__pycache__'))
rel='zipvoice/utils/common.py';a=(src/rel).read_text();old='def prepare_avg_tokens_durations(features_lens, tokens_lens):\n    tokens_durations = []';new='''def prepare_avg_tokens_durations(features_lens, tokens_lens):
    # get_tokens_index builds a CPU tensor with a Python slice loop. Transfer
    # lengths once instead of repeatedly reading GPU scalars in that loop.
    if isinstance(features_lens, torch.Tensor):
        features_lens = features_lens.cpu().tolist()
    if isinstance(tokens_lens, torch.Tensor):
        tokens_lens = tokens_lens.cpu().tolist()
    tokens_durations = []''';assert a.count(old)==1;b=a.replace(old,new);(dst/rel).write_text(b);(P/'cpu-lengths.patch').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
# The fixed calibration request has batch size1. Recorded maximum feature
# length therefore is that element; the original list-repeat count is its
# token length. Native guarded validation must verify both derived arrays.
d=json.loads((P/'controls.json').read_text());arrays=dict(np.load(P/'controls.npz'));notes=[]
for i,events in enumerate(d['requests']):
 starts=[j for j,x in enumerate(events)if x['tag'][:3]==['__index__','common.py','prepare_avg_tokens_durations']];assert len(starts)==1;lo=starts[0];hi=lo+1
 while hi<len(events)and events[hi]['tag'][1:3]==['common.py','get_tokens_index']:hi+=1
 assert events[lo]['value']>0;feature=[x['value']for x in events[:lo]if x['tag'][:3]==['__int__','zipvoice.py','forward_text_condition']];assert len(feature)==1
 for name,values in [('features',feature),('tokens',[events[lo]['value']])]:arrays[f'lengths_{i}_{name}']=np.array(values,dtype=np.int64)
 replacement=[{'tag':['cpu','common.py','prepare_avg_tokens_durations',[1],'torch.int64'],'array':f'lengths_{i}_{name}'}for name in ('features','tokens')]
 d['requests'][i]=events[:lo]+replacement+events[hi:];notes.append({'request':i,'removed_events':hi-lo,'added_cpu_arrays':2,'features_lens':feature,'tokens_lens':[events[lo]['value']],'precondition':'Calibration is batch1, so max(features_lens) identifies the single element. Original scalar list-repeat count identifies tokens_lens. Native guarded validation required.'})
(P/'controls-metadata.json').write_text(json.dumps(d,indent=2)+'\n');np.savez_compressed(P/'controls-metadata.npz',**arrays);(P/'removed-metadata-controls.json').write_text(json.dumps(notes,indent=2)+'\n')
c=json.loads((P/'partial.json').read_text());c['name']='zipvoice-metadata';c['files'].update(source=str(dst),controls=str(P/'controls-metadata.json'),control_arrays=str(P/'controls-metadata.npz'));(P/'metadata-after.json').write_text(json.dumps(c,indent=2)+'\n');print('ZIPVOICE_METADATA_CANDIDATE_READY')
