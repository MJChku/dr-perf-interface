"""Download only pinned inference checkpoints; verify sizes and LFS digests."""
import concurrent.futures,hashlib,json,shutil,urllib.request
from pathlib import Path
P=Path(__file__).resolve().parent;root=Path('/home/ubuntu/gx-ix14/causal/models/ZipVoice');raw=json.loads((P/'model-metadata.json').read_text());meta={raw['repository']:{'revision':raw['revision'],'files':[dict(x,path=x['rfilename'])for x in raw['files']]}};need=sum(x['size']for m in meta.values()for x in m['files']);assert shutil.disk_usage(root.parent).free>need+3000000000
jobs=[(repo,m['revision'],x)for repo,m in meta.items()for x in m['files']]
def fetch(job):
 repo,rev,x=job;f=root/x['path'];f.parent.mkdir(parents=True,exist_ok=True)
 if not f.exists():
  tmp=f.with_suffix(f.suffix+'.download')
  with urllib.request.urlopen(f'https://huggingface.co/{repo}/resolve/{rev}/{x["path"]}',timeout=180)as inp,tmp.open('wb')as out:shutil.copyfileobj(inp,out,4*1024*1024)
  assert tmp.stat().st_size==x['size'];tmp.replace(f)
 assert f.stat().st_size==x['size']
 with f.open('rb')as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
 if 'lfs'in x:assert digest==x['lfs']['sha256']
 print('VERIFIED',repo,x['path'],x['size'],flush=True);return {'repository':repo,'revision':rev,'path':str(f.relative_to(root)),'bytes':x['size'],'sha256':digest,'lfs_sha_verified':'lfs'in x}
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as ex:rows=list(ex.map(fetch,jobs))
(P/'model-manifest.json').write_text(json.dumps({'root':str(root),'files':rows},indent=2)+'\n')

# Reused pinned Vocos assets and reference recording are part of the workload.
extra=[('charactr/vocos-mel-24khz','0feb3fdd929bcd6649e0e7c5a688cf7dd012ef21','config.yaml','vocos/config.yaml'),('charactr/vocos-mel-24khz','0feb3fdd929bcd6649e0e7c5a688cf7dd012ef21','pytorch_model.bin','vocos/pytorch_model.bin')]
for repo,rev,name,dest in extra:
 f=root/dest;f.parent.mkdir(parents=True,exist_ok=True)
 if not f.exists():
  with urllib.request.urlopen(f'https://huggingface.co/{repo}/resolve/{rev}/{name}',timeout=180)as inp,f.open('wb')as out:shutil.copyfileobj(inp,out)
 expected={'vocos/config.yaml':'da9033922f969a47f0c160010226919e59f27761fd5066f3828d46de6650b0fc','vocos/pytorch_model.bin':'97ec976ad1fd67a33ab2682d29c0ac7df85234fae875aefcc5fb215681a91b2a'}
 assert hashlib.sha256(f.read_bytes()).hexdigest()==expected[dest]
 rows.append(dict(repository=repo,revision=rev,path=dest,bytes=f.stat().st_size,sha256=expected[dest]))
f=root/'reference.wav';url='https://raw.githubusercontent.com/SWivid/F5-TTS/9c614e9657089213efc6a7421b30630be138a3f5/src/f5_tts/infer/examples/basic/basic_ref_en.wav'
if not f.exists():
 with urllib.request.urlopen(url,timeout=120)as inp,f.open('wb')as out:shutil.copyfileobj(inp,out)
assert hashlib.sha256(f.read_bytes()).hexdigest()=='b0e22048e72414fcc1e6b6342e47a774d748a195ed34e4a5b3fcf416707f2b71'
rows.append(dict(repository='SWivid/F5-TTS',revision='9c614e9657089213efc6a7421b30630be138a3f5',path='reference.wav',bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
(P/'model-manifest.json').write_text(json.dumps({'root':str(root),'files':rows},indent=2)+'\n')
