"""GX metadata probe: does Torch already pin nonblocking CPU destinations?"""
import json,sys,torch
from pathlib import Path
assert 'gx_cuda.so' in Path('/proc/self/maps').read_text()
rows=[]
for n in (16,1048576,16777216):
 for nonblocking in (False,True):
  source=torch.empty(n,dtype=torch.uint8,device='cuda')
  destination=source.to('cpu',non_blocking=nonblocking)
  torch.cuda.synchronize()
  pinned=destination.pin_memory()
  rows.append(dict(bytes=n,non_blocking=nonblocking,destination_pinned=destination.is_pinned(),pin_memory_same_storage=destination.data_ptr()==pinned.data_ptr()))
p=Path(sys.argv[1]);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(dict(torch=torch.__version__,rows=rows),indent=2)+'\n');print('OMNI_PIN_PROBE',json.dumps(rows),flush=True)
