#!/usr/bin/env bash
set -euo pipefail
ulimit -c 0
export PYTHONPATH=/workspace/causal/omni/source-async:/workspace/causal/omni/extras:/workspace/causal/omni/deps:/workspace/causal/wan2gp/deps:/workspace/causal/wanwrapper/deps:/workspace/causal/sglang/cutlass:/workspace/causal/sglang/cutlass/nvidia_cutlass_dsl/dsl_packages:/workspace/causal/sglang/deps:/workspace/causal/sglang/kernel:/workspace/causal/sglang/source/python:/workspace/causal/deps:/workspace/causal/scope-deps:/workspace/causal/flashdreams-deps:/workspace/deps
export LD_LIBRARY_PATH=/workspace/causal/sglang/cuda13_libs:/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cudnn/lib
export LD_PRELOAD=/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cublas/lib/libcublas.so.12:/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cublas/lib/libcublasLt.so.12
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONHASHSEED=0 TOKENIZERS_PARALLELISM=false HF_HUB_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1
export FLASHINFER_DISABLE_VERSION_CHECK=1 VLLM_USE_V1=1 VLLM_WORKER_MULTIPROC_METHOD=spawn VLLM_ATTENTION_BACKEND=FLASH_ATTN
export GLOO_SOCKET_IFNAME=lo NCCL_SOCKET_IFNAME=lo
index=0
for side in before after after before; do
 index=$((index+1))
 base=/workspace/causal/runs/omni-async-${index}-${side}
 [[ ! -e "$base" ]]
 export OMNI_ASYNC_UPLOAD=0
 if [[ "$side" == after ]]; then export OMNI_ASYNC_UPLOAD=1; fi
 timeout -k 20 1800 python3 -u /workspace/causal/omni/runner_async.py \
 --model /workspace/causal/models/Wan2.1-T2V-1.3B-Diffusers \
 --output "$base" --role native --warmup 2 --repetitions 5 \
 --frames 17 --steps 8 --height 256 --width 448 > "$base.log" 2>&1
done
