"""Publish audited GX and native results; keep failed hypotheses and limitations."""
import gzip, hashlib, json, shutil, statistics, sys, tarfile
from pathlib import Path

P = Path(__file__).resolve().parent
E = P.parents[2] / 'examples/causal_video'
sys.path.insert(0, str(E))
from compact_gx_trace import compact, events

def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def reduced(r): return {k: v for k, v in r.items() if k != 'source_sha256'}
def aggregate(values):
    return {'seconds': values, 'mean_seconds': statistics.mean(values),
            'median_seconds': statistics.median(values)}

pins = read(P / 'pins.json')
pins.update(stage='GX modes 2/3 and native ABBA completed',
            selected_runner_sha256=sha(P / 'runner_async.py'),
            candidate_source_sha256=sha(P / 'source-async/vllm_omni/diffusion/offloader/sequential_backend.py'))
out = {'system': 'vLLM-Omni', 'pins': pins, 'workload': pins['workload'],
       'change': 'Queue CUDA component weight uploads nonblocking, retaining final pre_forward device synchronization, CPU offload and all transfer bytes. HSDP and non-CUDA use the original blocking policy.',
       'flag': 'OMNI_ASYNC_UPLOAD=0 versus 1, same patched source on both sides.',
       'gx': {}, 'traces': {}, 'native_A100': {},
       'scheduler_adapter': read(P / 'scheduler-omission.json'),
       'attachment_controls': read(P / 'attachment-controls.json'),
       'negative_screen': read(P / 'pinned-screen.json'),
       'limitations': [
           'Mode 2 client and worker clocks are independent. Worker markers exclude IPC packing and client postprocessing; client mode-2 intervals are not end-to-end latency. Mode 3 provides separate whole-client request intervals.',
           'This is CPU submission/wait scheduling: mode-2 CPU instruction cost is nearly unchanged, while overlap improves. It is not reduced transfer traffic or model compute.',
           'GX skips Euler initial-index nonzero/scalar-read operations, retaining comparison and preceding-stream wait. Three identified omitted CUB launches total 17.407 us/request in the native calibration; omitted scalar-read and CPU bookkeeping are not quantified. Native runs retain the original lookup and verify index zero.',
           'GX and native can choose different cuDNN plans; malformed/missing signatures contribute zero predicted compute. Launch-count coverage is not time coverage or exact native replay.',
           'CPU calibration has 11003 resolved and 2365 unresolved instruction samples (17.69% unresolved). GX host EPYC 7702P differs from native A100 host EPYC 9554.',
           'GX cannot validate numerical output. Native checks finite returned float32 video and exact paired hashes, for one prompt, seed, shape, single GPU and serial requests. Training, concurrent parameter mutation and HSDP are not validated.',
           'GX timing skips only the optional cosmetic worker process-title change to avoid a DR environment-relocation attachment failure. Explicit trace export occurs during worker shutdown, outside request markers.',
       ]}
for mode, prefix in [('mode2', 'async'), ('mode3', 'async-sync')]:
    records, audits = {}, {}
    pair = read(P / f'{prefix}-pair.json')
    assert pair.get('finished_unix')
    for side in ('before', 'after'):
        a = read(P / f'{prefix}-{side}-audit.json'); audits[side] = a
        assert a['result']['passed'] and not a['result']['cleanup_errors']
        assert a['model']['runner_sha256'] == pins['selected_runner_sha256']
        assert a['model']['async_upload'] == (side == 'after')
        out.setdefault('source_sha256', a['model']['source_sha256'])
        assert out['source_sha256'] == a['model']['source_sha256']
        records[side] = {k: a[k] for k in ('run', 'result', 'summary', 'iterations', 'misses', 'kernel_inventory', 'gpu_db_sha256', 'cpu_db_sha256')}
        records[side]['model'] = reduced(a['model'])
        records[side]['worker'] = aggregate([i['virtual_seconds'] for i in a['gpu_worker_iterations']])
        records[side]['client'] = aggregate([i['virtual_seconds'] for i in a['client_iterations']])
        records[side]['controller_wall_seconds'] = pair['runs'][side]['controller_wall_seconds']
        records[side]['runtime'] = read(Path(a['run']) / 'runtime.json')
        records[side]['worker_reports'] = {f.name: read(f) for f in (Path(a['run']) / 'host-0/model').glob('worker-*.json')}
        src = Path(a['run']) / 'timeline-report/trace.json.gz'
        dst = E / f'evidence/omni-{mode}-{side}.chrome.json.gz'
        out['traces'][f'{mode}_{side}'] = {'file': dst.name, 'full_trace': str(src), **compact(src, dst, bin_ms=10)}
    assert records['before']['summary']['copies'] == records['after']['summary']['copies']
    assert records['before']['runtime']['dynamorio'] == records['after']['runtime']['dynamorio']
    records['full_compute_inventories_match'] = audits['before']['launches'] == audits['after']['launches']
    for scope in ('worker', 'client'):
        records[scope + '_reduction_percent'] = 100 * (1 - records['after'][scope]['mean_seconds'] / records['before'][scope]['mean_seconds'])
    out['gx'][mode] = records

reports, workers = [], []
for i, side in enumerate(('before', 'after', 'after', 'before'), 1):
    r = read(P / f'native-async-{i}-{side}.json')
    w = read(P / f'native-async-{i}-{side}-workers.json')
    assert r['phase'] == 'completed' and len(r['iterations']) == 5 and len(w) == 5
    assert r['source_sha256'] == out['source_sha256']
    assert r['runner_sha256'] == pins['selected_runner_sha256']
    assert r['async_upload'] == (side == 'after')
    assert all(c['native_checked'] and not c['nonzero_and_index_read_omitted'] for v in w.values() for c in v['control_checks'])
    reports.append(reduced(r) | {'variant': side})
    workers.append({'process_index': i, 'variant': side, 'reports': w})
all_iterations = [i for r in reports for i in r['iterations']]
assert all(i['finite'] and i['dtype'] == 'float32' for i in all_iterations)
assert {i['output_sha256'] for i in all_iterations} == {'cada5e65c8f8da0d7d113377688a4a22ea9d3d947bde9f04de22a4b875c578e8'}
n = {'status': 'complete', 'process_order': ['before', 'after', 'after', 'before'],
     'warmup_per_process': 2, 'repetitions_per_process': 5, 'reports': reports,
     'worker_reports': workers, 'all_20_float32_outputs_finite_and_identical': True,
     'hardware': read(P / 'native-async-hardware.json')}
for side in ('before', 'after'):
    n[side] = aggregate([i['client_host_seconds'] for r in reports if r['variant'] == side for i in r['iterations']])
    ws = [v for w in workers if w['variant'] == side for v in w['reports'].values()]
    n[side]['worker'] = aggregate([v['worker_clock_seconds'] for v in ws])
    for key in ('peak_gpu_bytes', 'peak_reserved_gpu_bytes', 'peak_host_rss_bytes'):
        n[side][key] = [v[key] for v in ws]
for stat in ('mean', 'median'):
    n[stat + '_reduction_percent'] = 100 * (1 - n['after'][stat + '_seconds'] / n['before'][stat + '_seconds'])
out['native_A100'] = n

shutil.copyfile(P / 'async-upload.patch', E / 'cpu_patches/omni_async_upload.patch')
shutil.copyfile(P / 'runner_async.py', E / 'omni_runner.py')
out['patch'] = {'file': '../cpu_patches/omni_async_upload.patch', 'sha256': sha(P / 'async-upload.patch')}
names = ['runner.py', 'runner_async.py', 'async-upload.patch', 'run_async_pair.py', 'run_async_sync_pair.py', 'run_native_async.py', 'validate-async-native.sh', 'async-before.json', 'async-after.json', 'async-sync-before.json', 'async-sync-after.json', 'cpu.json', 'pins.json', 'cpu-calibration.json', 'native-async-hardware.json', 'native-async-identities.json', 'audit.py', 'package_async.py', 'scheduler-omission.json', 'attachment-controls.json', 'runner_late_noflush.py', 'pinned-screen.json', 'direct-pinned-d2h.patch', 'pinned_probe.py', 'pinned-probe.json']
(P / 'pins.json').write_text(json.dumps(pins, indent=2) + '\n')
bundle = E / 'evidence/omni-reproduce.tar.gz'
with tarfile.open(bundle, 'w:gz') as tar:
    for name in names: tar.add(P / name, arcname=name)
out['reproduction'] = {'file': bundle.name, 'sha256': sha(bundle), 'files': names,
                       'note': 'Install pinned dependencies, apply patch to pinned vLLM-Omni, adjust host/asset paths. Shared launcher and audit utilities are in this repository.'}
dbdir = E / 'evidence/kernel-databases'; manifest = read(dbdir / 'manifest.json'); calibration = {}
for key, src, name in [('database', 'gpu.sqlite', 'omni-wan.sqlite.gz'), ('native_report', 'kernel-profile.json', 'omni-wan.report.json.gz'), ('cpu_instruction_calibration', 'cpu.db', 'omni-wan.cpu.db.gz')]:
    raw = (P / src).read_bytes(); dst = dbdir / name
    dst.write_bytes(gzip.compress(raw, compresslevel=9, mtime=0)); assert gzip.decompress(dst.read_bytes()) == raw
    calibration[key] = {'file': name, 'source': str(P / src), 'uncompressed_bytes': len(raw), 'uncompressed_sha256': sha(P / src), 'gzip_sha256': sha(dst)}
calibration['scope'] = out['workload']; out['calibration'] = calibration
manifest['artifacts']['vllm-omni-wan'] = calibration
(dbdir / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(E / 'evidence/omni-cpu.json').write_text(json.dumps(out, indent=2) + '\n')
print('OMNI_PACKAGE_PASS', {m: r['worker_reduction_percent'] for m, r in out['gx'].items()}, n['median_reduction_percent'], n['mean_reduction_percent'])
