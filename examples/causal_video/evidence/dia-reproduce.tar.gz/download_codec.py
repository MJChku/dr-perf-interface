import hashlib,json,urllib.request,shutil
from pathlib import Path
P=Path(__file__).resolve().parent;root=Path('/home/ubuntu/gx-ix14/causal/models/Dia');root.mkdir(parents=True,exist_ok=True);url='https://github.com/descriptinc/descript-audio-codec/releases/download/0.0.1/weights.pth';f=root/'dac-44khz-8kbps-0.0.1.pth'
if not f.exists():
 with urllib.request.urlopen(url,timeout=180)as inp,f.with_suffix('.download').open('wb')as out:shutil.copyfileobj(inp,out,4*1024*1024)
 f.with_suffix('.download').replace(f)
with f.open('rb')as stream:h=hashlib.file_digest(stream,'sha256').hexdigest()
(P/'codec-manifest.json').write_text(json.dumps({'url':url,'file':str(f),'bytes':f.stat().st_size,'sha256':h,'selection':'Exact dac.utils.download() default in descript-audio-codec1.0.0:44khz8kbps tag0.0.1'},indent=2)+'\n');print('DIA_CODEC_PASS',f.stat().st_size,flush=True)
