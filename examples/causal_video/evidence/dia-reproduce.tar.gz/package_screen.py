"""Retain an inconclusive GX screen with explicit timing coverage limitations."""
import gzip,hashlib,json,statistics,subprocess,tarfile,tempfile,shutil
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[2];E=R/'examples/causal_video/evidence'
def read(n):return json.loads((P/n).read_text())
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def means(d):return {k:statistics.mean(x[k]for x in d['iterations'])for k in ('virtual_seconds','cpu_seconds','gpu_span_seconds','outside_gpu_spans_seconds')}
b=read('partial-audit.json');variants={n:read(n+'-audit.json')for n in ('dense-after',)};native=read('kernel-profile.json');cpu=read('cpu-calibration.json');bm=means(b)
for d in [b,*variants.values()]:assert d['result']['passed']and not d['result']['cleanup_errors'];assert d['model']['runner_sha256']==sha(P/'runner.py');assert d['model']['versions']==b['model']['versions']
assert b['model']['source_sha256']==native['source_sha256']
traces={}
for name,d in [('before',b),*variants.items()]:
 target=E/f'dia-mode2-{name}.chrome.json.gz';subprocess.run(['python3',str(R/'examples/causal_video/compact_gx_trace.py'),str(Path(d['run'])/'timeline-report/trace.json.gz'),str(target),'--bin-ms','1'],check=True,stdout=subprocess.DEVNULL);json.loads(gzip.decompress(target.read_bytes()));traces[name]={'file':target.name,'sha256':sha(target),'bytes':target.stat().st_size}
limitations=[
 'Unselected low-gain CPU candidate: mode2 improvement0.8554%, identical selected GPU inventories/copy bytes. No mode3 or optimized A100 validation; initial isolated kernel calibration is not an unprofiled latency baseline or full-model candidate correctness check.',
 'Native Dia1.6B0626 original Dia.generate,128token cap,greedytemperature0,CFG3,seed42,text[S1]Hello.Thisisatest.,noaudio prompt,eager,originalDAC44kHz8kbps. Produces57344samples; this is a bounded greedy workload, not full-utterance quality or general throughput.',
 'Original native checkpoint6.444GB SHA verified in memory; state tensors cast to actual native model dtypes for compute_dtype=float16:263FP16 and80FP32 tensors, preserving FP32 normalization. Transformers-converted safetensors were rejected, not used. Original Torch2.11cu128/NumPy1.26 stack retained despite upstream Torch2.6/NumPy>=2.2 declarations; this workload completed successfully.',
 'First cold native warmup hash38422938... differs from second warmup and measured calibration aed486be...; all controls and output hashes are retained. No hardware performance statistic is derived from calibration.',
 'GX replays GPU scalar and CPU array controls after original transfers/waits. Boolean-index shape/count adapter substitutes native-recorded cardinality and omits nonzero work; it adds24index kernels/request and omits5974native launches/request, including4572FP32GEMVs. Isolated omitted medians sum47.471490ms/request, not an end-to-end correction; zero prediction misses does not imply complete coverage.',
 'CPU profile651unresolved of18333instruction samples(3.55%),28unresolved task samples. CPU calibration host differs from A100 host. Outside-GPU1.223s/3.033s is a screening heuristic, not hardware utilization or a universal optimization bound.',
 'Actual DenseGeneral CPU helper passes99 output cases and2 gradient cases acrossFP32/FP16/BF16, shapes/layouts and fallbacks. Scalar outputs retain original tensordot because a first shortcut test exposed a rounding difference. Full-model candidate waveform equivalence remains unvalidated.',
]
source={'remote':'https://github.com/nari-labs/dia.git','commit':subprocess.check_output(['git','-C',str(P/'source'),'rev-parse','HEAD'],text=True).strip(),'status':'Unselected low-gain GX CPU screen; additional opportunities remain unexplored. No optimized A100 validation.'}
comparisons={n:{'after':means(d),'request_reduction_percent':100*(1-means(d)['virtual_seconds']/bm['virtual_seconds']),'audit':d}for n,d in variants.items()}
record={'source':source,'model':read('model-manifest.json'),'baseline':bm,'candidates':comparisons,'baseline_audit':b,'native_kernel_calibration':read('kernel-calibration.json'),'native_kernel_report':native,'native_optimization_validation':None,'cpu_calibration':cpu,'omissions':read('omissions.json'),'oracles':{'dense':read('dense-oracle.json')},'limitations':limitations,'compact_traces':traces}
with tempfile.TemporaryDirectory(prefix='dia-patch-check-')as td:
 root=Path(td);shutil.copytree(P/'source',root/'source',ignore=shutil.ignore_patterns('.git','__pycache__'));subprocess.run(['git','apply',str(P/'dense-trailing.patch')],cwd=root/'source',check=True);assert (root/'source/dia/layers.py').read_bytes()==(P/'source-dense/dia/layers.py').read_bytes()
record['patch_application_checked']=True
(P/'screen-summary.json').write_text(json.dumps({'source':source,'baseline':bm,'candidates':{k:{x:y for x,y in v.items()if x!='audit'}for k,v in comparisons.items()},'limitations':limitations},indent=2)+'\n')
files=['runner.py','runner-calibration.py','audit.py','run_timing.py','run_cpu.py','profile.sh','run_native_profile.py','stage_native.py','download_model.py','download_codec.py','model-manifest.json','model-metadata.json','codec-manifest.json','target-state-dtypes.json','native-calibration-identities.json','native-profile-hardware.json','kernel-calibration.json','kernel-profile.json','controls.json','controls.npz','cpu-calibration.json','cpu.json','partial.json','dense-after.json','partial-audit.json','dense-after-audit.json','dense_oracle.py','dense-oracle.json','dense-trailing.patch','record_omissions.py','omissions.json','screen-summary.json','package_screen.py']
with tarfile.open(E/'dia-reproduce.tar.gz','w:gz')as t:
 for name in files:t.add(P/name,arcname=name)
with tarfile.open(E/'dia-reproduce.tar.gz','r:gz')as t:
 assert sorted(t.getnames())==sorted(files)
 for name in files:assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==sha(P/name)
record['reproduction_bundle']={'file':'dia-reproduce.tar.gz','sha256':sha(E/'dia-reproduce.tar.gz'),'members':files}
f=E/'cpu-screen-negative.json';all_cases=json.loads(f.read_text());all_cases['cases']['Dia']=record;f.write_text(json.dumps(all_cases,indent=2)+'\n')
f=R/'examples/causal_video/pins.json';pins=json.loads(f.read_text());pins['Dia']=source;f.write_text(json.dumps(pins,indent=2)+'\n')
f=E/'kernel-databases/manifest.json';manifest=json.loads(f.read_text());entry={}
for key,name,out in [('database','gpu.sqlite','dia.sqlite.gz'),('native_report','kernel-profile.json','dia.report.json.gz'),('cpu_instruction_calibration','cpu.db','dia.cpu.db.gz')]:
 raw=(P/name).read_bytes();z=E/'kernel-databases'/out;z.write_bytes(gzip.compress(raw,compresslevel=9,mtime=0));assert gzip.decompress(z.read_bytes())==raw;entry[key]={'file':out,'source':str(P/name),'uncompressed_bytes':len(raw),'uncompressed_sha256':sha(P/name),'gzip_sha256':sha(z)}
entry['scope']=native['scope'];manifest['artifacts']['dia']=entry;f.write_text(json.dumps(manifest,indent=2)+'\n')
print('DIA_SCREEN_PACKAGE_PASS',bm,{k:v['request_reduction_percent']for k,v in comparisons.items()},flush=True)
