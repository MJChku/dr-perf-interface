"""Retain only exact FP16 casts of pinned original FP32 weights to limit disk use."""
import gc,hashlib,json,shutil,urllib.request,io
from pathlib import Path
import torch
from safetensors.torch import load,save_file
P=Path(__file__).resolve().parent;root=Path('/home/ubuntu/gx-ix14/causal/models/Dia');root.mkdir(parents=True,exist_ok=True)
meta=json.loads((P/'model-metadata.json').read_text());assert shutil.disk_usage(root).free>500000000
state={};records=[];dtypes=json.loads((P/'target-state-dtypes.json').read_text())
for x in meta['files']:
 name=x['rfilename']
 if name not in ('dia-v1.pth','config.json'):continue
 url=f"https://huggingface.co/{meta['repository']}/resolve/{meta['revision']}/{name}"
 with urllib.request.urlopen(url,timeout=240)as f:raw=f.read()
 assert len(raw)==x['size'];digest=hashlib.sha256(raw).hexdigest()
 if 'lfs'in x:assert digest==x['lfs']['sha256']
 records.append({'file':name,'bytes':len(raw),'sha256':digest})
 if name=='config.json':(root/name).write_bytes(raw)
 else:
  tensors=torch.load(io.BytesIO(raw),map_location='cpu',weights_only=True)
  for k,v in tensors.items():
   assert k not in state
   state[k]=v.to(getattr(torch,dtypes[k].split('.')[-1]))
  del tensors
 del raw;gc.collect();print('DIA_ORIGINAL_VERIFIED',name,flush=True)
assert set(state)==set(dtypes) and all(str(v.dtype)==dtypes[k]for k,v in state.items())
# Previously downloaded HF safetensors have Transformers-converted keys and are not the native Dia architecture. Remove only our own rejected conversion after original native weights verified in memory.
old=root/'model.safetensors'
if old.exists():old.unlink()
file=root/'native-fp16.pth';torch.save(state,file)
manifest={'root':str(root),'repository':meta['repository'],'revision':meta['revision'],'original_files':records,'conversion':'Each tensor cast to its actual native DiaModel state dtype for compute_dtype=float16 (263FP16,80FP32); FP32 normalization parameters remain exact. Original byte SHA256 checked in memory before conversion; no original FP32 disk copy retained. No quantization or architecture change.','torch_conversion_version':torch.__version__,'tensor_count':len(state),'parameters':sum(v.numel()for v in state.values()),'files':[]}
for f in root.iterdir():
 with f.open('rb')as stream:h=hashlib.file_digest(stream,'sha256').hexdigest()
 manifest['files'].append({'path':f.name,'bytes':f.stat().st_size,'sha256':h})
(P/'model-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('DIA_HALF_CHECKPOINT_PASS',file.stat().st_size,flush=True)
