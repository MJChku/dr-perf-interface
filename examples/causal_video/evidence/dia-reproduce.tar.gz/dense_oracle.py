import hashlib,importlib.util,json,os,sys,types
from pathlib import Path
import torch
P=Path(__file__).resolve().parent
pkg=types.ModuleType('dia');pkg.__path__=[str(P/'source/dia')];sys.modules['dia']=pkg
classes=[]
for name,path in [('original',P/'source/dia/layers.py'),('candidate',P/'source-dense/dia/layers.py')]:
 spec=importlib.util.spec_from_file_location('dia.layers_'+name,path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);classes.append(mod.DenseGeneral)
torch.set_num_threads(1);torch.manual_seed(123);cases=0;gradchecks=0
for dtype in (torch.float32,torch.float16,torch.bfloat16):
 for dims,outs,axes in [((8,),(3,4),(-1,)),((2,4),(7,),(-2,-1)),((8,),(),(-1,)),((8,),(0,),(-1,))]:
  for batch in ((),(1,),(2,3),(0,)):
   for layout in ('contiguous','strided'):
    a,b=[cls(dims,outs,axis=axes,weight_dtype=dtype)for cls in classes]
    with torch.no_grad():a.weight.normal_();b.weight.copy_(a.weight)
    shape=batch+dims
    x=torch.randn(shape,dtype=dtype)if layout=='contiguous'else torch.randn(shape+(2,),dtype=dtype)[...,0]
    y=a(x);z=b(x);assert torch.equal(y,z),(dtype,dims,outs,batch,layout,(y-z).abs().max());cases+=1
# Nontrailing and positive axes preserve the general fallback.
for axes,shape in [((0,),(8,2,3)),((1,),(2,8,3)),((-2,),(2,8,3))]:
 a,b=[cls((8,),(4,),axis=axes)for cls in classes]
 with torch.no_grad():a.weight.normal_();b.weight.copy_(a.weight)
 x=torch.randn(shape);assert torch.equal(a(x),b(x));cases+=1
for dims,shape in [((8,),(2,3,8)),((2,4),(2,3,2,4))]:
 a,b=[cls(dims,(3,),axis=tuple(range(-len(dims),0)))for cls in classes]
 with torch.no_grad():a.weight.normal_();b.weight.copy_(a.weight)
 x=torch.randn(shape,requires_grad=True);z=x.detach().clone().requires_grad_();a(x).sum().backward();b(z).sum().backward();assert torch.equal(x.grad,z.grad)and torch.equal(a.weight.grad,b.weight.grad);gradchecks+=1
out={'passed':True,'cases':cases,'gradient_checks':gradchecks,'torch_version':torch.__version__,'scope':'Actual original/candidate DenseGeneral CPU modules, FP32/FP16/BF16, multiple/empty batch dimensions, contiguous/strided inputs, no output axes, empty outputs, fallback axes and FP32 gradients. Exact outputs and gradients; full model A100 validation still required.','patch_sha256':hashlib.sha256((P/'dense-trailing.patch').read_bytes()).hexdigest()}
Path(os.environ.get('ORACLE_OUTPUT',str(P/'dense-oracle.json'))).write_text(json.dumps(out,indent=2)+'\n');print('DIA_DENSE_ORACLE_PASS',json.dumps(out),flush=True)
