"""Stage isolated FastGen sources/dependencies and verify resident model hashes."""
import hashlib, json, subprocess
from pathlib import Path
P=Path(__file__).resolve().parent
base='/home/jcm/drperf-wan-a100-20260916/causal/fastgen'
ssh=['ssh','-o','ConnectTimeout=10','-o','ConnectionAttempts=3','jcm@A100']
checks={}
def digest(f):
 with f.open('rb') as stream: return hashlib.file_digest(stream,'sha256').hexdigest()
need=sum(f.stat().st_size for folder in (P/'deps',P.parent/'FastGen')for f in folder.rglob('*') if f.is_file() and '.git' not in f.parts)
subprocess.run(ssh+['python3 -'],input='import shutil; f=shutil.disk_usage(%r).free; assert f>%d+1000000000,(f,%d)'%(str(Path(base).parent),need,need),text=True,check=True)
for target,folder in [('source',P.parent/'FastGen'),('deps',P/'deps')]:
 subprocess.run(ssh+['mkdir -p '+base+'/'+target],check=True)
 sender=subprocess.Popen(['tar','--exclude=.git','--exclude=__pycache__','-C',str(folder),'-cf','-','.'],stdout=subprocess.PIPE)
 try:subprocess.run(ssh+['tar --no-same-owner -C '+base+'/'+target+' -xf -'],stdin=sender.stdout,check=True)
 finally:sender.stdout.close()
 assert sender.wait()==0
 for f in folder.rglob('*'):
  if f.is_file() and '.git' not in f.parts and '__pycache__' not in f.parts: checks[base+'/'+target+'/'+str(f.relative_to(folder))]=digest(f)
 print('NATIVE_STAGED',target,flush=True)
for name in ('runner.py','profile.sh'):
 subprocess.run(['rsync','-az','-e','ssh -o ConnectTimeout=10 -o ConnectionAttempts=3',str(P/name),'jcm@A100:'+base+'/'+name],check=True)
 checks[base+'/'+name]=digest(P/name)
checkpoint=Path('/home/ubuntu/gx-ix14/causal/models/Wan2.1-T2V-1.3B-Diffusers')
for f in checkpoint.rglob('*'):
 if f.is_file(): checks['/home/jcm/drperf-wan-a100-20260916/causal/models/Wan2.1-T2V-1.3B-Diffusers/'+str(f.relative_to(checkpoint))]=digest(f)
script='''import hashlib,json
checks=json.loads(%r)
for name,expected in checks.items():
 with open(name,'rb') as stream: assert hashlib.file_digest(stream,'sha256').hexdigest()==expected,name
print('FASTGEN_NATIVE_IDENTITIES_PASS',len(checks))
'''%json.dumps(checks)
subprocess.run(ssh+['python3 -'],input=script,text=True,check=True)
(P/'native-identities.json').write_text(json.dumps(checks,indent=2)+'\n')
