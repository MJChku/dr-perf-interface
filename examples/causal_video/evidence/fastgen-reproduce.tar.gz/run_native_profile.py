"""One initial kernel calibration, gated by GX functional success and GPU1 availability."""
import argparse,hashlib,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[2]
p=argparse.ArgumentParser();p.add_argument('gx_run',type=Path);a=p.parse_args()
r=json.loads((a.gx_run/'result.json').read_text());assert r['passed'] and not r['cleanup_errors']
model=json.loads((a.gx_run/'host-0/model/report.json').read_text());assert model['phase']=='completed';assert model['runner_sha256']==hashlib.sha256((P/'runner.py').read_bytes()).hexdigest()
ssh=['ssh','-o','ConnectTimeout=10','-o','ConnectionAttempts=3','jcm@A100']
checks=json.loads((P/'native-identities.json').read_text())
script='import json,hashlib; d=json.loads(%r); assert all(hashlib.sha256(open(f,"rb").read()).hexdigest()==h for f,h in d.items()); print("FASTGEN_NATIVE_IDENTITIES_PASS",len(d))'%json.dumps(checks)
subprocess.run(ssh+['python3 -'],input=script,text=True,check=True)
active=subprocess.check_output(ssh+['nvidia-smi --query-compute-apps=gpu_uuid,pid --format=csv,noheader'],text=True)
assert 'GPU-521def15-8599-2c15-65ee-6dac40f31a64' not in active,active
hardware={'gpu_inventory':subprocess.check_output(ssh+['nvidia-smi --query-gpu=index,name,uuid,driver_version,memory.total --format=csv'],text=True),'active_compute_processes':active,'device_requests':json.loads(subprocess.check_output(ssh+['docker inspect --format "{{json .HostConfig.DeviceRequests}}" drperf-wan-native-0'],text=True))}
assert hardware['device_requests'][0]['DeviceIDs']==['1'];(P/'native-profile-hardware.json').write_text(json.dumps(hardware,indent=2)+'\n')
helper=R/'examples/wan_gx/native_container.py'
try:
 subprocess.run(['python3',str(helper),'resume'],check=True)
 subprocess.run(ssh+['docker exec -u jma drperf-wan-native-0 bash /workspace/causal/fastgen/profile.sh'],check=True)
 rsync=['rsync','-az','-e','ssh -o ConnectTimeout=10 -o ConnectionAttempts=3']
 remote='jcm@A100:/home/jcm/drperf-wan-a100-20260916/causal/runs/fastgen-kernels'
 subprocess.run(rsync+[remote+'/report.json',str(P/'kernel-profile.json')],check=True)
 subprocess.run(rsync+[remote+'.rank0.pid*.sqlite',str(P/'gpu.sqlite')],check=True)
 print('FASTGEN_NATIVE_PROFILE_PASS',flush=True)
finally:subprocess.run(['python3',str(helper),'stop'],check=True)
