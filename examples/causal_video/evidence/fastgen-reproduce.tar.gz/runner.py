"""FastGen's pretrained Wan sampling and preprocessing APIs, no training state."""
import argparse, ast, ctypes, functools, hashlib, inspect, json, os, resource, textwrap, time
from pathlib import Path
import torch
from diffusers import UniPCMultistepScheduler
from fastgen.networks.Wan.network import Wan
from fastgen.networks.noise_schedule import BaseNoiseSchedule
from fastgen.utils.basic_utils import inference_mode

p = argparse.ArgumentParser()
p.add_argument('--model', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--role', choices=['emu','cpu-profile','gpu-profile','partial_sync','native'], default='emu')
p.add_argument('--warmup', type=int, default=1)
p.add_argument('--repetitions', type=int, default=1)
p.add_argument('--frames', type=int, default=17)
p.add_argument('--height', type=int, default=256)
p.add_argument('--width', type=int, default=448)
p.add_argument('--steps', type=int, default=8)
a = p.parse_args()
a.output.mkdir(parents=True, exist_ok=False); os.chdir(a.output)
physical = a.role in ('native','gpu-profile')
assert ('gx_cuda.so' not in Path('/proc/self/maps').read_text()) == physical
torch.set_num_threads(1); torch.set_num_interop_threads(1)
checks = {'scalar_bounds': 0, 'valid_timesteps': 0, 'initial_indices': 0,
          'solve_status_reads': 0,
          'native_checked': physical, 'nonzero_index_read_omitted': not physical}

# Keep the original GPU bound rounding, scalar reads and waits. Only replace
# their emulated values with independently computed CPU metadata. Native checks
# each value. Cache CPU references after warmup to avoid repeated extra work.
@functools.lru_cache(maxsize=64)
def expected_scalar(bound, dtype, inward):
    v = torch.as_tensor(bound, dtype=dtype, device='cpu')
    if inward:
        toward = float('inf') if inward == 'lower' else float('-inf')
        v = torch.nextafter(v, torch.tensor(toward, dtype=dtype, device='cpu'))
    return v.item()

def checked_scalar(value, bound, inward):
    observed = value.item()
    expected = expected_scalar(bound, value.dtype, inward)
    if physical: assert observed == expected, (observed, expected, bound, value.dtype, inward)
    checks['scalar_bounds'] += 1
    return expected

class AdaptBounds(ast.NodeTransformer):
    def visit_Call(self, node):
        self.generic_visit(node)
        if isinstance(node.func, ast.Attribute) and node.func.attr == 'item':
            expr = ast.unparse(node.func.value)
            which = 'lower' if 'min_tensor' in expr else 'upper' if 'max_tensor' in expr else None
            assert which is not None, expr
            inward = None if isinstance(node.func.value, ast.Name) else which
            return ast.copy_location(ast.Call(func=ast.Name(id='_checked_scalar', ctx=ast.Load()),
                args=[node.func.value, ast.Name(id='min' if which == 'lower' else 'max', ctx=ast.Load()), ast.Constant(inward)], keywords=[]), node)
        return node

original_bounds = BaseNoiseSchedule.safe_clamp
tree = ast.parse(textwrap.dedent(inspect.getsource(original_bounds)))
tree.body[0].decorator_list = []
tree = ast.fix_missing_locations(AdaptBounds().visit(tree))
namespace = dict(original_bounds.__globals__, _checked_scalar=checked_scalar)
exec(compile(tree, '<GX-known-timestep-bound-values>', 'exec'), namespace)
BaseNoiseSchedule.safe_clamp = staticmethod(namespace['safe_clamp'])

original_valid = BaseNoiseSchedule.is_t_valid
def checked_valid(self, t):
    observed = bool(original_valid(self, t))
    if physical: assert observed, ('Invalid native timestep', t)
    checks['valid_timesteps'] += 1
    return True
BaseNoiseSchedule.is_t_valid = checked_valid

original_index = UniPCMultistepScheduler.index_for_timestep
def checked_index(self, timestep, schedule_timesteps=None):
    if physical:
        observed = original_index(self, timestep, schedule_timesteps)
        assert observed == 0, ('Unexpected initial UniPC index', observed)
    else:
        schedule = self.timesteps if schedule_timesteps is None else schedule_timesteps
        comparison = schedule == timestep
        assert comparison.shape == schedule.shape
    torch.cuda.current_stream().synchronize()
    checks['initial_indices'] += 1
    return 0
UniPCMultistepScheduler.index_for_timestep = checked_index

# UniPC's order-two corrector solves [[1,1],[rk,1]] with rk<0 along
# this monotone schedule. Keep the solve and scalar status read; GX does not
# execute the kernel that writes info. Native explicitly verifies success.
original_solve = torch.linalg.solve
def checked_solve(A, B, *, left=True, out=None):
    if A.device.type != 'cuda' or tuple(A.shape) != (2,2) or tuple(B.shape) != (2,) or out is not None:
        return original_solve(A, B, left=left, out=out)
    result, info = torch.linalg.solve_ex(A, B, left=left, check_errors=False)
    observed = info.item()
    if physical: assert observed == 0, ('UniPC solve failed', observed)
    checks['solve_status_reads'] += 1
    return result
torch.linalg.solve = checked_solve

def save(): (a.output/'report.json').write_text(json.dumps(report, indent=2)+'\n')
import fastgen
from importlib.metadata import version
root = Path(fastgen.__file__).parent
report = {'phase':'loading', 'config':{k:str(v) if isinstance(v,Path) else v for k,v in vars(a).items()},
          'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'source_sha256':{str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in root.rglob('*.py')},
          'versions':{n:version(n) for n in ('torch','numpy','transformers','diffusers','huggingface-hub','accelerate')},
          'scope':'FastGen Wan.sample, original text encoder and VAE, BF16 resident weights, UniPC, CFG5, negative embedding reused as in official video inference script; includes positive encoding and float32 CPU video output, no file encoding or training state.'}
save(); start = time.perf_counter()
net = Wan(model_id_or_local_path=str(a.model), enable_logvar_linear=False,
          r_timestep=False, use_wan_official_sinusoidal=False, disable_grad_ckpt=True)
# Resolve the same model locally for lazy scheduler/preprocessor loading.
net.model_id = str(a.model)
net.init_preprocessors()
net.eval().requires_grad_(False).to(device='cuda', dtype=torch.bfloat16)
with inference_mode(net.text_encoder):
    negative = net.text_encoder.encode([''], precision=torch.bfloat16)
report.update(phase='loaded', load_seconds=time.perf_counter()-start,
              parameter_counts={'transformer':sum(x.numel() for x in net.transformer.parameters()),
                                'text_encoder':sum(x.numel() for x in net.text_encoder.text_encoder.parameters()),
                                'vae':sum(x.numel() for x in net.vae.vae.parameters())})
save(); print('FASTGEN_LOADED', json.dumps(report['parameter_counts']), flush=True)

def generate():
    with inference_mode(net.text_encoder):
        condition = net.text_encoder.encode(['A cat walks on the grass, realistic style'], precision=torch.bfloat16)
    noise = torch.randn((1,16,(a.frames-1)//4+1,a.height//8,a.width//8), device='cuda', dtype=torch.bfloat16,
                        generator=torch.Generator(device='cuda').manual_seed(42))
    with inference_mode(net):
        latents = net.sample(noise, condition=condition, neg_condition=negative,
                             guidance_scale=5.0, num_steps=a.steps, shift=3.0)
    with inference_mode(net.vae):
        video = net.vae.decode(latents).float().cpu()
    return video

for i in range(a.warmup): generate()
torch.cuda.synchronize(); print('FASTGEN_WARMUP_DONE', flush=True)
rt = ctypes.CDLL(None)
if a.role == 'partial_sync':
    rt.gxvm_adopt_now(); rt.gxvm_timeline_mark.argtypes=[ctypes.c_uint,ctypes.c_int]
if a.role == 'cpu-profile': rt.gxvm_ipc_profile_start()
if a.role == 'gpu-profile': Path(os.environ['GX_PROFILE_START_FILE']).touch(exist_ok=False)
report['iterations'] = []
for i in range(a.repetitions):
    if a.role == 'partial_sync': rt.gxvm_timeline_mark(i+1,0)
    start=time.perf_counter(); video=generate(); torch.cuda.synchronize(); seconds=time.perf_counter()-start
    if a.role == 'partial_sync': rt.gxvm_timeline_mark(i+1,1)
    row={'iteration':i+1,'application_clock_seconds':seconds}
    if physical:
        value=video.numpy(); assert __import__('numpy').isfinite(value).all()
        row.update(shape=list(value.shape),dtype=str(value.dtype),finite=True,
                   output_sha256=hashlib.sha256(value.tobytes()).hexdigest(),minimum=float(value.min()),maximum=float(value.max()))
    report['iterations'].append(row)
if a.role == 'cpu-profile': assert rt.gxvm_ipc_profile_stop()==0
if a.role == 'gpu-profile': Path(os.environ['GX_PROFILE_STOP_FILE']).touch(exist_ok=False)
report.update(phase='completed', control_checks=checks, peak_gpu_bytes=torch.cuda.max_memory_allocated(),
              peak_reserved_gpu_bytes=torch.cuda.max_memory_reserved(), peak_host_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024)
save(); print('FASTGEN_COMPLETE',json.dumps({k:v for k,v in report.items()if k!='source_sha256'}),flush=True)
