"""Compare exact source functions on CPU, including rounding and errors."""
import ast,functools,itertools,json,math
from pathlib import Path
import torch
P=Path(__file__).resolve().parent
def load(path):
 tree=ast.parse(path.read_text()); nodes=[]
 for node in tree.body:
  if isinstance(node,ast.FunctionDef) and node.name=='_cpu_clamp_bound':nodes.append(node)
  if isinstance(node,ast.ClassDef) and node.name=='BaseNoiseSchedule':
   for f in node.body:
    if isinstance(f,ast.FunctionDef) and f.name=='safe_clamp':f.decorator_list=[];nodes.append(f)
 ns={'torch':torch,'lru_cache':functools.lru_cache}
 exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),ns)
 return ns
before=load(P.parent/'FastGen/fastgen/networks/noise_schedule.py')
after=load(P/'source-clamp/fastgen/networks/noise_schedule.py')
bounds=[None,-float('inf'),-1e30,-10000.,-1.,-0.999,-1e-8,-1e-40,-0.,0.,1e-40,1e-8,0.1,0.999,1.,10000.,1e30,float('inf'),float('nan')]
matched=errors=0
for dtype,lower,upper in itertools.product((torch.float16,torch.bfloat16,torch.float32,torch.float64),bounds,bounds):
 x=torch.tensor([-float('inf'),-1e30,-10.,-1.,-0.999,-1e-8,-1e-40,-0.,0.,1e-40,1e-8,0.1,0.999,1.,10.,1e30,float('inf'),float('nan')],dtype=dtype,device='cpu')
 outputs=[]
 for ns in (before,after):
  try:outputs.append(ns['safe_clamp'](x,min=lower,max=upper))
  except (RuntimeError,AssertionError,TypeError)as e:outputs.append(type(e).__name__)
 left,right=outputs
 if isinstance(left,str) or isinstance(right,str):assert left==right,(dtype,lower,upper,outputs);errors+=1
 else:assert torch.equal(left.nan_to_num(),right.nan_to_num()) and torch.equal(left.isnan(),right.isnan()),(dtype,lower,upper,left,right)
 matched+=1
info=after['_cpu_clamp_bound'].cache_info();assert info.hits>0 and info.currsize<=256
result={'passed':True,'comparisons':matched,'matching_error_cases':errors,'torch':torch.__version__,'device':'CPU','dtypes':['float16','bfloat16','float32','float64'],'cache_info':info._asdict(),'limitation':'CPU source equivalence covers rounding/control/error behavior. Native output validation separately checks selected CUDA workload; this does not establish every CUDA dtype/backend equivalence.'}
(P/'bounds-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
