"""Avoid boxing generated FP32 waveforms into a Python float list."""
import difflib,shutil
from pathlib import Path
P=Path(__file__).resolve().parent;src=P/'source';dst=P/'source-concat'
if not dst.exists():shutil.copytree(src,dst,ignore=shutil.ignore_patterns('.git','__pycache__'))
rel='melo/api.py';a=(src/rel).read_text();old='''        audio_segments = []
        for segment_data in segment_data_list:
            audio_segments += segment_data.reshape(-1).tolist()
            audio_segments += [0] * int((sr * 0.05) / speed)
        audio_segments = np.array(audio_segments).astype(np.float32)
        return audio_segments''';new='''        # Generated waveforms are NumPy float32 arrays. Keep their samples in
        # array storage rather than boxing every sample into a Python float.
        if isinstance(segment_data_list, (list, tuple)) and all(segment.dtype == np.float32 for segment in segment_data_list):
            if not segment_data_list:
                return np.empty(0, dtype=np.float32)
            silence = np.zeros(max(0, int((sr * 0.05) / speed)), dtype=np.float32)
            parts = []
            for segment in segment_data_list:
                parts.extend((segment.reshape(-1), silence))
            return np.concatenate(parts) if parts else np.empty(0, dtype=np.float32)
        audio_segments = []
        for segment_data in segment_data_list:
            audio_segments += segment_data.reshape(-1).tolist()
            audio_segments += [0] * int((sr * 0.05) / speed)
        audio_segments = np.array(audio_segments).astype(np.float32)
        return audio_segments''';assert a.count(old)==1;b=a.replace(old,new);(dst/rel).write_text(b);(P/'audio-concat.patch').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
