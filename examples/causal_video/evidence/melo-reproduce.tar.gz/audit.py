"""Audit per-iteration GPU work and CPU gaps; compare measured launch inventory."""
import argparse,gzip,hashlib,json,re,sqlite3,sys
from collections import Counter
from pathlib import Path
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parents[2]/'examples/causal_video'))
from summarize_partial import event_stream
from audit_kernel_trace import signature_key,entries,database_inventory
p=argparse.ArgumentParser();p.add_argument('run',type=Path);p.add_argument('--output',type=Path,required=True);p.add_argument('--cpu-db',type=Path,default=P/'cpu.db');a=p.parse_args();r=a.run
result=json.loads((r/'result.json').read_text());assert result['passed'] and not result['cleanup_errors'];s=json.loads((r/'timeline-report/summary.json').read_text());model=json.loads((r/'host-0/model/report.json').read_text());iters=[]
mark_threads={}
for f in (r/'host-0/d0/timeline').glob('*.jsonl*'):
 record=str(f)[:-3]if f.suffix=='.gz'else str(f)
 with (gzip.open(f,'rt')if f.suffix=='.gz'else f.open())as stream:
  for line in stream:
   row=json.loads(line)
   if row.get('op')=='mark':
    key=(record,row['iteration']);assert key not in mark_threads or mark_threads[key]==row['tid'];mark_threads[key]=row['tid']
for b in s['iterations']:iters.append(b|{'thread_id':mark_threads[(b['record'],b['iteration'])],'intervals':[],'cpu_ns':0,'copy_bytes':Counter(),'copy_counts':Counter()})
lanes={}
for e in event_stream(r/'timeline-report/trace.json.gz'):
 if e.get('ph')=='M' and e.get('name')=='thread_name':
  lanes[(e.get('pid'),e.get('tid'))]=e.get('args',{}).get('record_lane','');continue
 if e.get('ph')!='X':continue
 lane=lanes.get((e.get('pid'),e.get('tid')),'')
 record=lane.rsplit(':cpu:',1)[0] if ':cpu:' in lane else lane.rsplit(':gpu:',1)[0] if ':gpu:' in lane else None
 for it in iters:
  if it['record']!=record:continue
  lo=max(it['start_ns'],e['ts']*1000);hi=min(it['end_ns'],(e['ts']+e['dur'])*1000)
  if hi<=lo:continue
  args=e.get('args',{})
  if 'resource_domain' in args:it['intervals'].append((lo,hi))
  if e.get('cat')=='cpu' and lane.endswith(':cpu:'+str(it['thread_id'])):it['cpu_ns']+=hi-lo
  if 'copy' in args:
   c=args['copy'];it['copy_bytes'][str(c['kind'])]+=c['bytes'];it['copy_counts'][str(c['kind'])]+=1
for it in iters:
 merged=[]
 for lo,hi in sorted(it.pop('intervals')):
  if merged and lo<=merged[-1][1]:merged[-1]=(merged[-1][0],max(hi,merged[-1][1]))
  else:merged.append((lo,hi))
 busy=sum(hi-lo for lo,hi in merged);it.update(gpu_span_seconds=busy/1e9,outside_gpu_spans_seconds=(it['virtual_ns']-busy)/1e9,cpu_seconds=it.pop('cpu_ns')/1e9,virtual_seconds=it['virtual_ns']/1e9)
ids_by_pid={}
for f in (r/'host-0/d0/timeline').glob('*.jsonl*'):
 pid=int(re.search(r'pid-(\d+)\.jsonl',f.name)[1]);ids=ids_by_pid.setdefault(pid,set())
 for line in (gzip.open(f,"rt") if f.suffix==".gz" else f.open()):
  e=json.loads(line)
  if e.get('op')=='submit' and e.get('kind') in ('COMPUTE','CUBLAS'):ids.add(e['id'])
counts=Counter();misses=Counter()
for f in (r/'host-0/model/kernel_profile_gx').glob('chrome_trace*.json*'):
 pid=int(re.search(r'chrome_trace_(\d+)',f.name)[1]);ids=ids_by_pid.get(pid,set())
 for e in event_stream(f):
  args=e.get('args',{})
  if e.get('ph')=='X' and e.get('name') in ('kernel_predict','cublas_predict') and args.get('task_id') in ids:
   key=signature_key(args.get('kernel_name') or args.get('operation'),args['grid'],args['block']);counts[key]+=1
   if args.get('prediction_status')!='hit':misses[key]+=1
assert sum(counts.values())==s['prediction_hits']+s['prediction_misses'], {'trace_count':sum(counts.values()),'summary_count':s['prediction_hits']+s['prediction_misses'],'ids':sum(map(len,ids_by_pid.values())),'trace_misses':sum(misses.values()),'summary_misses':s['prediction_misses']}
assert sum(misses.values())==s['prediction_misses']
c=sqlite3.connect(P/'gpu.sqlite');pid=c.execute('SELECT pid FROM profile_runs').fetchone()[0];c.close();_,native_counts,_,skipped,_=database_inventory(P/'gpu.sqlite',pid);native_counts=Counter({k:v*sum(i['iteration']<1000 for i in iters) for k,v in native_counts.items()})
out=dict(run=str(r),summary=s,iterations=iters,model=model,result=result,launches=entries(counts),misses=entries(misses),kernel_inventory=dict(native_total=sum(native_counts.values()),gx_total=sum(counts.values()),matching=counts==native_counts,native_only=entries(native_counts-counts),gx_only=entries(counts-native_counts),native_skipped=skipped),gpu_calibration_db_sha256=hashlib.sha256((P/'gpu.sqlite').read_bytes()).hexdigest(),gpu_db_sha256=hashlib.sha256((P/'gpu.sqlite').read_bytes()).hexdigest(),cpu_db_sha256=None if s['timing_mode']=='gpu_only_partial_sync' else hashlib.sha256(a.cpu_db.read_bytes()).hexdigest(),cpu_profile_header=None if s['timing_mode']=='gpu_only_partial_sync' else a.cpu_db.read_text().splitlines()[0],gpu_worker_iterations=[i for i in iters if i['iteration']<1000],client_iterations=[i for i in iters if i['iteration']>=1000],limitations=['Fixed original MeloTTS English-v3 public request. GPU scalar/CPU arrays replayed after original transfers and waits. Narrow arange shape adapter uses native-recorded dimensions.', 'FP32 SGEMM and cuDNN timing coverage must be audited against native inventory; zero prediction misses does not establish complete coverage.', 'Native kernel calibration is not an unprofiled latency validation. GX cannot validate waveform values.', 'CPU unresolved samples, different hosts, cuDNN plans and uncovered launches limit timing accuracy.', 'Outside-GPU spans are a prioritization heuristic, not hardware utilization or a universal speedup bound.'])
a.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k] for k in ['iterations','misses','kernel_inventory']},indent=2))
