"""Pin and verify MeloTTS and all eagerly imported tokenizers; English BERT only."""
import concurrent.futures,hashlib,json,shutil,urllib.request
from pathlib import Path
P=Path(__file__).resolve().parent;root=Path('/home/ubuntu/gx-ix14/causal/models/MeloTTS');root.mkdir(parents=True,exist_ok=True)
repos=['myshell-ai/MeloTTS-English-v3','bert-base-uncased','bert-base-multilingual-uncased','tohoku-nlp/bert-base-japanese-v3','kykim/bert-kor-base','dbmdz/bert-base-french-europeana-cased','dccuchile/bert-base-spanish-wwm-uncased']
metadata=[];jobs=[]
for repo in repos:
 with urllib.request.urlopen('https://huggingface.co/api/models/'+repo+'?blobs=true',timeout=120)as f:m=json.load(f)
 rev=m['sha'];keep=[]
 for x in m['siblings']:
  name=x['rfilename']
  if repo.startswith('myshell-ai/'):selected=name in ('config.json','checkpoint.pth')
  else:selected=name in ('config.json','tokenizer.json','tokenizer_config.json','special_tokens_map.json','added_tokens.json','vocab.txt','spiece.model')or(repo=='bert-base-uncased'and name=='model.safetensors')
  if selected:keep.append(x)
 metadata.append(dict(repository=repo,revision=rev,files=keep))
 for x in keep:
  dest=root/x['rfilename']if repo.startswith('myshell-ai/')else root/'hf-cache/hub'/('models--'+repo.replace('/','--'))/'snapshots'/rev/x['rfilename']
  jobs.append((repo,rev,x,dest))
 if not repo.startswith('myshell-ai/'):
  ref=root/'hf-cache/hub'/('models--'+repo.replace('/','--'))/'refs/main';ref.parent.mkdir(parents=True,exist_ok=True);ref.write_text(rev)
(P/'all-model-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
need=sum(x['size']for _,_,x,f in jobs if not f.exists());assert shutil.disk_usage(root).free>need+1200000000

def fetch(job):
 repo,rev,x,f=job;f.parent.mkdir(parents=True,exist_ok=True)
 if not f.exists():
  tmp=f.with_suffix(f.suffix+'.download')
  with urllib.request.urlopen(f'https://huggingface.co/{repo}/resolve/{rev}/{x["rfilename"]}',timeout=180)as inp,tmp.open('wb')as out:shutil.copyfileobj(inp,out,4*1024*1024)
  assert tmp.stat().st_size==x['size'];tmp.replace(f)
 assert f.stat().st_size==x['size']
 with f.open('rb')as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
 if 'lfs'in x:assert digest==x['lfs']['sha256']
 print('VERIFIED',repo,x['rfilename'],x['size'],flush=True);return dict(repository=repo,revision=rev,path=str(f.relative_to(root)),bytes=x['size'],sha256=digest,lfs_sha_verified='lfs'in x)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as ex:rows=list(ex.map(fetch,jobs))
for f in root.glob('hf-cache/hub/*/refs/main'):rows.append(dict(path=str(f.relative_to(root)),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest(),kind='pinned-cache-reference'))
(P/'model-manifest.json').write_text(json.dumps(dict(root=str(root),files=rows),indent=2)+'\n')
