"""Check actual old/new static methods on varied waveforms, chunks and dtypes."""
import ast,hashlib,json
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parent
functions=[]
for source in ('source','source-concat'):
 tree=ast.parse((P/source/'melo/api.py').read_text());cls=next(x for x in tree.body if isinstance(x,ast.ClassDef)and x.name=='TTS');fn=next(x for x in cls.body if isinstance(x,ast.FunctionDef)and x.name=='audio_numpy_concat');fn.decorator_list=[];ns={'np':np};exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),source,'exec'),ns);functions.append(ns[fn.name])
rng=np.random.default_rng(42);count=0
for dtype in (np.float16,np.float32,np.float64,np.int16,np.int64):
 for n in (0,1,2,7):
  for sr in (8000,24000,44100):
   for speed in (.5,1.,1.7):
    waves=[rng.normal(size=(2,i*19+1)).astype(dtype)for i in range(n)];a,b=[f(waves,sr,speed)for f in functions];assert a.dtype==b.dtype==np.float32;assert a.shape==b.shape;assert a.tobytes()==b.tobytes();count+=1
for speed in (0., -1.):
 a,b=[f([],44100,speed)for f in functions];assert a.tobytes()==b.tobytes();count+=1
for waves in ([np.array([],dtype=np.float32)],[np.array([-0.,0.,np.inf,-np.inf,np.nan],dtype=np.float32)],[np.arange(20,dtype=np.float32)[::2],np.ones((2,3),dtype=np.float32).T]):
 a,b=[f(waves,44100)for f in functions];assert np.array_equal(a,b,equal_nan=True);assert a.shape==b.shape;count+=1
(P/'concat-oracle.json').write_text(json.dumps({'passed':True,'cases':count,'method':'Actual source methods extracted via AST, byte-identical outputs across finite cases; NaN-aware equality for special values. This is not full-model validation.','patch_sha256':hashlib.sha256((P/'audio-concat.patch').read_bytes()).hexdigest()},indent=2)+'\n');print('MELO_CONCAT_ORACLE_PASS',count)
