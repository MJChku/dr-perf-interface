"""Replay native Boolean-index cardinalities; no emulated arithmetic claim."""
from pathlib import Path
P=Path(__file__).resolve().parent;f=P/'runner.py';s=f.read_text().replace("'cpu','to','__getitem__')","'cpu','to','__getitem__','__setitem__')")
start=s.index('def getitem(');end=s.index('# Preserve explicit GPU-to-CPU',start)
s=s[:start]+'''def boolean_mask(index):
 parts=index if isinstance(index,tuple)else(index,)
 masks=[(i,x)for i,x in enumerate(parts)if isinstance(x,torch.Tensor)and x.dtype==torch.bool and x.device.type=='cuda']
 return parts,masks

def fixed_index(index,count):
 parts,masks=boolean_mask(index);assert len(masks)==1
 position,mask=masks[0];assert position==0
 # Empty integer-coordinate buffers supply only the calibrated cardinality.
 # GX predicts gathers/scatters, without executing numerical indexing. This
 # omits GPU nonzero/cardinality work; launch audits quantify that omission.
 coords=tuple(torch.empty((count,),dtype=torch.int64,device=mask.device)for _ in range(mask.ndim))
 return coords+tuple(parts[1:])

def getitem(t,index):
 parts,masks=boolean_mask(index)
 if not tape.active or not masks:return original['__getitem__'](t,index)
 frame=sys._getframe(1);key=tag('boolean_index_shape',t,frame)
 if physical:
  result=original['__getitem__'](t,index);tape.exchange(key,list(result.shape));return result
 shape=tape.exchange(key);result=original['__getitem__'](t,fixed_index(index,shape[0]));assert list(result.shape)==shape,(list(result.shape),shape)
 return result

def setitem(t,index,value):
 parts,masks=boolean_mask(index)
 if not tape.active or not masks:return original['__setitem__'](t,index,value)
 assert len(masks)==1;frame=sys._getframe(1);key=tag('boolean_setitem_count',t,frame)
 count=int(original['cpu'](masks[0][1]).numpy().sum())if physical else None
 count=tape.exchange(key,count)
 return original['__setitem__'](t,index if physical else fixed_index(index,count),value)
torch.Tensor.__getitem__=getitem;torch.Tensor.__setitem__=setitem
'''+s[end:]
s=s.replace('Narrow arange','Narrow arange')
f.write_text(s)
# Reuse the existing controlled INITIAL-calibration orchestration.
s=(P.parent/'zipvoice/run_shape_calibration.py').read_text().replace('zipvoice','melo').replace('ZIPVOICE','MELO').replace('profile-control2.sh','profile-control.sh').replace('melo-controls2','melo-controls').replace('control-calibration2.json','control-calibration.json');s=s.replace(";assert all(x['native_shape_checked']for x in report['fft_adapters']+report['shape_adapters'])","")
(P/'run_control_calibration.py').write_text(s)
s=(P/'profile.sh').read_text();s=s.replace('melo-kernels','melo-controls');s=s[:s.index('export GX_PROFILE_SO')]+'''unset LD_PRELOAD GX_PROFILE_SO GX_PROFILE_DB GX_PROFILE_START_FILE GX_PROFILE_STOP_FILE
exec timeout -k 20 900 python3 -u /workspace/causal/melo/runner.py \\
 --model /workspace/causal/models/MeloTTS --output "$base" --role native --warmup 2 > "$base.log" 2>&1
''';(P/'profile-control.sh').write_text(s)
