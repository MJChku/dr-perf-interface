#!/usr/bin/env bash
set -euo pipefail
ulimit -c 0
melo_selected=$1
melo_selected_controls=$2
melo_selected_arrays=$3
export LD_LIBRARY_PATH=/workspace/causal/f5-tts/deps/ffmpeg/lib:/workspace/causal/sglang/cuda13_libs:/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cudnn/lib
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONHASHSEED=0 TOKENIZERS_PARALLELISM=false HF_HUB_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1
export HF_HOME=/workspace/causal/models/MeloTTS/hf-cache NLTK_DATA=/workspace/causal/models/MeloTTS/nltk_data LOCAL_FILES_ONLY=true
export FLASHINFER_DISABLE_VERSION_CHECK=1 VLLM_USE_V1=1 VLLM_WORKER_MULTIPROC_METHOD=spawn VLLM_ATTENTION_BACKEND=FLASH_ATTN
export TORCHINDUCTOR_CACHE_DIR=/workspace/causal/melo/cache-native/inductor
export TRITON_CACHE_DIR=/workspace/causal/melo/cache-native/triton
export TORCHINDUCTOR_COMPILE_THREADS=2
unset LD_PRELOAD GX_PREDICT_DB GX_PROFILE_SO GX_PROFILE_START_FILE GX_PROFILE_STOP_FILE
melo_index=0
for melo_side in before after after before; do
 melo_index=$((melo_index+1))
 melo_source=source
 [[ $melo_side == before ]] || melo_source=$melo_selected
 export PYTHONPATH=/workspace/causal/melo/$melo_source:/workspace/causal/melo/deps:/workspace/causal/zipvoice/deps:/workspace/causal/soprano/deps:/workspace/causal/f5-tts/deps:/workspace/causal/qwen-tts/deps:/workspace/causal/qwen-tts/source:/workspace/causal/fastgen/deps:/workspace/causal/fastgen/source:/workspace/causal/omni/source:/workspace/causal/omni/extras:/workspace/causal/omni/deps:/workspace/causal/wan2gp/deps:/workspace/causal/wanwrapper/deps:/workspace/causal/sglang/cutlass:/workspace/causal/sglang/cutlass/nvidia_cutlass_dsl/dsl_packages:/workspace/causal/sglang/deps:/workspace/causal/sglang/kernel:/workspace/causal/sglang/source/python:/workspace/causal/deps:/workspace/causal/scope-deps:/workspace/causal/flashdreams-deps:/workspace/deps
 melo_out=/workspace/causal/runs/melo-plain-$melo_index-$melo_side
 [[ ! -e $melo_out ]]
 timeout -k 20 900 python3 -u /workspace/causal/melo/runner.py --model /workspace/causal/models/MeloTTS --output "$melo_out" --role native --plain --warmup 5 --repetitions 20 > "$melo_out.log" 2>&1
 printf 'MELO_NATIVE_PROCESS_PASS %s %s\n' "$melo_index" "$melo_side"
done
for melo_side in before after; do
 melo_source=source
 melo_controls=controls.json
 melo_arrays=controls.npz
 if [[ $melo_side == after ]]; then
  melo_source=$melo_selected
  melo_controls=$melo_selected_controls
  melo_arrays=$melo_selected_arrays
 fi
 export PYTHONPATH=/workspace/causal/melo/$melo_source:/workspace/causal/melo/deps:/workspace/causal/zipvoice/deps:/workspace/causal/soprano/deps:/workspace/causal/f5-tts/deps:/workspace/causal/qwen-tts/deps:/workspace/causal/qwen-tts/source:/workspace/causal/fastgen/deps:/workspace/causal/fastgen/source:/workspace/causal/omni/source:/workspace/causal/omni/extras:/workspace/causal/omni/deps:/workspace/causal/wan2gp/deps:/workspace/causal/wanwrapper/deps:/workspace/causal/sglang/cutlass:/workspace/causal/sglang/cutlass/nvidia_cutlass_dsl/dsl_packages:/workspace/causal/sglang/deps:/workspace/causal/sglang/kernel:/workspace/causal/sglang/source/python:/workspace/causal/deps:/workspace/causal/scope-deps:/workspace/causal/flashdreams-deps:/workspace/deps
 melo_out=/workspace/causal/runs/melo-control-$melo_side
 [[ ! -e $melo_out ]]
 timeout -k 20 900 python3 -u /workspace/causal/melo/runner.py --model /workspace/causal/models/MeloTTS --output "$melo_out" --role native --controls /workspace/causal/melo/"$melo_controls" --control-arrays /workspace/causal/melo/"$melo_arrays" --warmup 1 --repetitions 1 > "$melo_out.log" 2>&1
 printf 'MELO_NATIVE_CONTROL_PASS %s\n' "$melo_side"
done
