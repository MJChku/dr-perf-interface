#!/usr/bin/env bash
set -euo pipefail
ulimit -c 0
base=/workspace/causal/runs/melo-controls
[[ ! -e "$base" && ! -e "$base.start" && ! -e "$base.stop" ]]
export PYTHONPATH=/workspace/causal/melo/source:/workspace/causal/melo/deps:/workspace/causal/zipvoice/deps:/workspace/causal/soprano/deps:/workspace/causal/f5-tts/deps:/workspace/causal/qwen-tts/deps:/workspace/causal/qwen-tts/source:/workspace/causal/fastgen/deps:/workspace/causal/fastgen/source:/workspace/causal/omni/source:/workspace/causal/omni/extras:/workspace/causal/omni/deps:/workspace/causal/wan2gp/deps:/workspace/causal/wanwrapper/deps:/workspace/causal/sglang/cutlass:/workspace/causal/sglang/cutlass/nvidia_cutlass_dsl/dsl_packages:/workspace/causal/sglang/deps:/workspace/causal/sglang/kernel:/workspace/causal/sglang/source/python:/workspace/causal/deps:/workspace/causal/scope-deps:/workspace/causal/flashdreams-deps:/workspace/deps
export LD_LIBRARY_PATH=/workspace/causal/f5-tts/deps/ffmpeg/lib:/workspace/causal/sglang/cuda13_libs:/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cudnn/lib
export LD_PRELOAD=/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cublas/lib/libcublas.so.12:/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cublas/lib/libcublasLt.so.12
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONHASHSEED=0 TOKENIZERS_PARALLELISM=false HF_HUB_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1
export HF_HOME=/workspace/causal/models/MeloTTS/hf-cache NLTK_DATA=/workspace/causal/models/MeloTTS/nltk_data LOCAL_FILES_ONLY=true
export FLASHINFER_DISABLE_VERSION_CHECK=1 VLLM_USE_V1=1 VLLM_WORKER_MULTIPROC_METHOD=spawn VLLM_ATTENTION_BACKEND=FLASH_ATTN
export TORCHINDUCTOR_CACHE_DIR=/workspace/causal/melo/cache-native/inductor
export TRITON_CACHE_DIR=/workspace/causal/melo/cache-native/triton
export TORCHINDUCTOR_COMPILE_THREADS=2
unset LD_PRELOAD GX_PROFILE_SO GX_PROFILE_DB GX_PROFILE_START_FILE GX_PROFILE_STOP_FILE
exec timeout -k 20 900 python3 -u /workspace/causal/melo/runner.py \
 --model /workspace/causal/models/MeloTTS --output "$base" --role native --warmup 2 > "$base.log" 2>&1
