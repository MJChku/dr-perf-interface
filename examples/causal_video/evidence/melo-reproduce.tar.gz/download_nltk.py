import hashlib,io,json,urllib.request,zipfile
from pathlib import Path
P=Path(__file__).resolve().parent;root=Path('/home/ubuntu/gx-ix14/causal/models/MeloTTS')
with urllib.request.urlopen('https://api.github.com/repos/nltk/nltk_data/commits/gh-pages',timeout=60)as f:rev=json.load(f)['sha']
rows=[]
for rel in ['corpora/cmudict.zip','taggers/averaged_perceptron_tagger.zip','taggers/averaged_perceptron_tagger_eng.zip']:
 with urllib.request.urlopen(f'https://raw.githubusercontent.com/nltk/nltk_data/{rev}/packages/{rel}',timeout=120)as f:data=f.read()
 dest=root/'nltk_data'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 with zipfile.ZipFile(io.BytesIO(data))as z:
  for n in z.namelist():assert not n.startswith('/')and'..'not in Path(n).parts
  z.extractall(dest.parent)
for f in (root/'nltk_data').rglob('*'):
 if f.is_file():rows.append(dict(repository='nltk/nltk_data',revision=rev,path=str(f.relative_to(root)),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
p=P/'model-manifest.json';d=json.loads(p.read_text());d['files']=[x for x in d['files']if not x['path'].startswith('nltk_data/')]+rows;p.write_text(json.dumps(d,indent=2)+'\n');print('NLTK_PINNED',rev,len(rows))
