"""Resolve only explicitly pinned HF repo aliases to local snapshots at load time."""
import os
from pathlib import Path
from transformers import AutoTokenizer,AutoModelForMaskedLM
model_cache_root=Path(os.environ['HF_HOME'])/'hub'
allowed={'bert-base-uncased','bert-base-multilingual-uncased','tohoku-nlp/bert-base-japanese-v3','kykim/bert-kor-base','dbmdz/bert-base-french-europeana-cased','dccuchile/bert-base-spanish-wwm-uncased'}
for cls in (AutoTokenizer,AutoModelForMaskedLM):
 loader_original=cls.from_pretrained
 def local(cls,name,*args,_original=loader_original,**kwargs):
  if name in allowed:
   folder=model_cache_root/('models--'+name.replace('/','--'));rev=(folder/'refs/main').read_text().strip();name=str(folder/'snapshots'/rev);kwargs['local_files_only']=True
  return _original(name,*args,**kwargs)
 cls.from_pretrained=classmethod(local)
