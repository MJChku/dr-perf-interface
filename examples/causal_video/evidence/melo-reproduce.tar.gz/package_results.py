"""Keep GX predictions, initial calibration and final A100 validation distinct."""
import gzip,hashlib,json,shutil,statistics,subprocess,sys,tarfile,tempfile
from pathlib import Path
P=Path(__file__).resolve().parent;E=P.parents[2]/'examples/causal_video';sys.path.insert(0,str(E))
from compact_gx_trace import compact
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins={'source':{'remote':'https://github.com/myshell-ai/MeloTTS.git','commit':subprocess.check_output(['git','-C',str(P/'source'),'rev-parse','HEAD'],text=True).strip()},'model':read(P/'model-manifest.json'),'dependencies':read(P/'kernel-profile.json')['versions'],'workload':read(P/'kernel-profile.json')['request'],'scope':read(P/'kernel-profile.json')['scope']};(P/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
limits=[
 'One English-v3 request,113309samples at44100Hz,seed42,sdp_ratio0.2,noise_scale0.6,noise_scale_w0.8,speed1. Original public TTS.tts_to_file with output_path=None; text/phoneme processing,BERT features,synthesis,empty_cache and CPU audio concatenation included. No file encoding. Resident pretrained models, not a throughput or all-prompt study.',
 'Original51,808,433FP32synthesizer plus109,514,298FP32EnglishBERTparameters. ExistingTorch2.11cu128 andTransformers4.57.3 retained. Pinned local model aliases avoid an unrelated offline Mistral-tokenizer metadata query; English tokenization unchanged.',
 'GX omits arithmetic. Native-recorded scalar and CPU arrays replayed after original transfers/waits. Initial GX failed at Boolean index assignment because fake cardinality was1019645071. Narrow GX-only indexing adapter uses empty integer-coordinate tensors with native-recorded counts; it preserves gather/scatter shapes but omits nonzero/cardinality work. Native plain timing restores all Tensor/arange hooks; separate guarded runs check controls against real values.',
 'Baseline167native-only launches/request include74FP32SGEMMs and Boolean-index cardinality work. Their isolated median sum6.347728ms/request is not an end-to-end correction. Selected before/after GPU inventories and copy bytes are identical; zero prediction misses alone does not establish complete timing coverage.',
 'CPU calibration21unresolved of367instruction samples(5.72%),1unresolved task sample. GX and native CPU hosts differ. Compare relative improvements; this is not a matched-host absolute timing accuracy study.',
 'Mode3 uses10us epochs. GPU spans include epoch placement effects. Outside-GPU fractions are screening heuristics, not hardware utilization or universal speedup bounds.',
 'Native unprofiled ABBA has5warmups and20measured requests/process,40samples per variant,all80retained. Separate guarded runs do not enter latency statistics. Finite FP32 waveform concatenation is byte-exact; non-FP32 inputs retain the original implementation.',
]
out={'system':'MeloTTS','pins':pins,'change':'Keep generated float32 waveform samples in NumPy arrays and concatenate chunks/silence directly, avoiding per-sample Python floats and the intermediate float64 array. Preserve the original fallback for other dtypes.','gx':{},'traces':{},'limitations':limits,'native_kernel_calibration':read(P/'kernel-profile.json'),'kernel_calibration':read(P/'kernel-calibration.json'),'native_control_calibration':read(P/'control-calibration.json'),'cpu_calibration':read(P/'cpu-calibration.json'),'omissions':read(P/'omissions.json'),'cpu_oracles':read(P/'concat-oracle.json'),'selection':read(P/'selected.json')}
for mode,names in [('mode2',('partial','concat-after')),('mode3',('sync-before','sync-after'))]:
 pair={}
 for side,name in zip(('before','after'),names):
  a=read(P/(name+'-audit.json'));assert a['result']['passed']and not a['result']['cleanup_errors'];assert a['model']['runner_sha256']==sha(P/'runner.py');assert a['gpu_db_sha256']==sha(P/'gpu.sqlite')and a['cpu_db_sha256']==sha(P/'cpu.db')
  pair[side]=a|{'runtime':read(Path(a['run'])/'runtime.json'),'controller_wall_seconds':read(P/(name+'-run.json'))['controller_wall_seconds']};pair[side]['means']={k:statistics.mean(x[k]for x in a['iterations'])for k in ('virtual_seconds','cpu_seconds','gpu_span_seconds','outside_gpu_spans_seconds')}
  dst=E/f'evidence/melo-{mode}-{side}.chrome.json.gz';src=Path(a['run'])/'timeline-report/trace.json.gz';out['traces'][mode+'_'+side]={'file':dst.name,'full_trace':str(src),**compact(src,dst,bin_ms=1)}
 assert pair['before']['runtime']['dynamorio']==pair['after']['runtime']['dynamorio'];assert pair['before']['launches']==pair['after']['launches'];assert all(x['iterations'][0]['copy_bytes']==pair['before']['iterations'][0]['copy_bytes']for x in pair.values());assert all(x['model']['iterations'][0]['control_count']==40 for x in pair.values())
 pair['request_reduction_percent']=100*(1-pair['after']['means']['virtual_seconds']/pair['before']['means']['virtual_seconds']);out['gx'][mode]=pair
n=read(P/'native-summary.json');assert n['measured_output_checks']==80
for block in n['reports']:
 report=block['report'];g=out['gx']['mode2'][block['side']]['model'];assert report['versions']==g['versions']and report['source_sha256']==g['source_sha256'];assert report['plain']and report['runner_sha256']==sha(P/'runner.py');assert {x['output_sha256']for x in report['iterations']}=={n['output_sha256']}
for x in n['control_reports']:
 d=x['report'];assert {r['output_sha256']for r in d['warmups']+d['iterations']}=={n['output_sha256']}
out['native_A100']=n|{'hardware':read(P/'native-validation-hardware.json')}
with tempfile.TemporaryDirectory(prefix='melo-patch-')as td:
 root=Path(td);shutil.copytree(P/'source',root/'source',ignore=shutil.ignore_patterns('.git','__pycache__'));subprocess.run(['git','apply',str(P/'audio-concat.patch')],cwd=root/'source',check=True);assert (root/'source/melo/api.py').read_bytes()==(P/'source-concat/melo/api.py').read_bytes()
out['patch_application_checked']=True
shutil.copyfile(P/'runner.py',E/'melo_runner.py');shutil.copyfile(P/'audio-concat.patch',E/'cpu_patches/melo_audio_concat.patch')
files=['pins.json','runner.py','runner-calibration.py','audio-concat.patch','prepare_concat.py','selected.json','model-manifest.json','model-metadata.json','all-model-metadata.json','download_model.py','download_nltk.py','offline_bootstrap.py','controls.json','controls.npz','controls-calibration.json','controls-calibration.npz','emu.json','emu-index.json','cpu.json','partial.json','concat-after.json','sync-before.json','sync-after.json','audit.py','run_timing.py','run_cpu.py','profile.sh','profile-control.sh','run_native_profile.py','run_control_calibration.py','stage_native.py','kernel-calibration.json','control-calibration.json','cpu-calibration.json','omissions.json','record_omissions.py','native-calibration-identities.json','native-shape-identities.json','native-validation-identities.json','native-profile-hardware.json','native-shape-hardware.json','native-validation-hardware.json','run_native_validation.py','validate-native.sh','concat_oracle.py','concat-oracle.json','add_index_adapter.py','package_results.py']
bundle=E/'evidence/melo-reproduce.tar.gz'
with tarfile.open(bundle,'w:gz')as t:
 for name in files:t.add(P/name,arcname=name)
with tarfile.open(bundle,'r:gz')as t:
 assert sorted(t.getnames())==sorted(files)
 for name in files:assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==sha(P/name)
out['reproduction']={'file':bundle.name,'sha256':sha(bundle),'files':files,'note':'Install pinned source/dependencies, adjust host/file paths, and apply audio-concat.patch to candidate source. runner-calibration.py records original kernel calibration; runner.py includes the native-checked Boolean-index shape adapter used in GX. Native plain timing restores all tensor-control hooks.'}
dbdir=E/'evidence/kernel-databases';manifest=read(dbdir/'manifest.json');artifacts={}
for key,name,target in [('native_database','gpu.sqlite','melo.sqlite.gz'),('native_report','kernel-profile.json','melo.report.json.gz'),('cpu_instruction_calibration','cpu.db','melo.cpu.db.gz')]:
 raw=(P/name).read_bytes();dst=dbdir/target;dst.write_bytes(gzip.compress(raw,compresslevel=9,mtime=0));assert gzip.decompress(dst.read_bytes())==raw;artifacts[key]={'file':target,'uncompressed_bytes':len(raw),'uncompressed_sha256':sha(P/name),'gzip_sha256':sha(dst)}
manifest['artifacts']['melo']=artifacts;(dbdir/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');out['calibration']=artifacts
allpins=read(E/'pins.json');allpins['MeloTTS']=pins;(E/'pins.json').write_text(json.dumps(allpins,indent=2)+'\n');(E/'evidence/melo-cpu.json').write_text(json.dumps(out,indent=2)+'\n')
print('MELO_PACKAGE_PASS',json.dumps({'gx':{m:x['request_reduction_percent']for m,x in out['gx'].items()},'native_median':out['native_A100']['median_reduction_percent'],'native_mean':out['native_A100']['mean_reduction_percent']}),flush=True)
