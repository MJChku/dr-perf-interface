"""CPU-only source-level validation; not GX timing or pretrained validation."""
import ast,hashlib,json,subprocess,types
from pathlib import Path
import torch,transformers
from transformers import Qwen2Config,Qwen2ForCausalLM,DynamicCache
P=Path(__file__).resolve().parent
source=P.parent/'CosyVoice/cosyvoice/llm/llm.py'
tree=ast.parse((P/'llm-candidate.py').read_text())
parts=[x for x in tree.body if isinstance(x,(ast.ClassDef,ast.FunctionDef))and x.name in ('Qwen2Encoder','_inference_mask')]
space={'torch':torch,'Qwen2ForCausalLM':Qwen2ForCausalLM}
exec(compile(ast.Module(body=parts,type_ignores=[]),str(source),'exec'),space)
cls=space['Qwen2Encoder'];helper=space['_inference_mask']
torch.set_num_threads(1);torch.manual_seed(42)
enc=cls.__new__(cls);torch.nn.Module.__init__(enc)
rows=[]
for n in (1,2,3,7,32,257,1024,4096):
 old=torch.tril(torch.ones((1,n,n))).to(torch.bool);new=helper(enc,n,'cpu')
 assert torch.equal(old[:,-1,:],new[:,-1,:]);rows.append({'length':n,'old_elements':old.numel(),'new_elements':new.numel()})
class CustomEncoder(cls):pass
for target in (object(),CustomEncoder.__new__(CustomEncoder)):
 for n in (1,3,32):
  assert torch.equal(helper(target,n,'cpu'),torch.tril(torch.ones((1,n,n))).bool())
config=Qwen2Config(vocab_size=32,hidden_size=32,intermediate_size=64,num_hidden_layers=2,num_attention_heads=4,num_key_value_heads=2,max_position_embeddings=256)
config._attn_implementation='eager'
model=Qwen2ForCausalLM(config).eval();enc.model=model
checks=0
with torch.inference_mode():
 for dtype in (torch.float32,torch.bfloat16):
  model.to(dtype)
  for total_length_mask in (False,True):
   cache_a=DynamicCache(config=config);cache_b=DynamicCache(config=config);seen=0
   for count in (7,1,1,4,1):
    x=torch.randn(1,count,32,dtype=dtype);seen+=count;n=seen if total_length_mask else count
    old=torch.tril(torch.ones((1,n,n))).bool();new=helper(enc,n,'cpu')
    a,cache_a=enc.forward_one_step(x,old,cache_a);b,cache_b=enc.forward_one_step(x,new,cache_b)
    assert torch.equal(a,b),(dtype,total_length_mask,count);checks+=1
out={'status':'cpu_oracle_pass','source_remote':'https://github.com/FunAudioLLM/CosyVoice.git','source_commit':subprocess.check_output(['git','-C',str(P.parent/'CosyVoice'),'rev-parse','HEAD'],text=True).strip(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'patch_sha256':hashlib.sha256((P/'last-row-mask.patch').read_bytes()).hexdigest(),'mask_cases':rows,'custom_encoder_fallback_cases':6,'actual_qwen2_forward_checks':checks,'torch':torch.__version__,'transformers':transformers.__version__,'scope':'AST-extracted original Qwen2Encoder forward_one_step, candidate helper, random tiny Qwen2 model with independent real DynamicCaches. CPU FP32/BF16, prefill and decode, both current-length and full-history masks. Exact hidden outputs. Different stack from GX; no pretrained correctness or timing claim.','gx_evaluation':None,'A100_validation':None}
(P/'mask-oracle.json').write_text(json.dumps(out,indent=2)+'\n');print('COSYVOICE_MASK_ORACLE_PASS',checks)
