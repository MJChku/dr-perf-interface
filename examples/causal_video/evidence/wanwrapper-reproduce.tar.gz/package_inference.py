"""Archive the selected inference-mode experiment, including every native sample."""
import gzip, hashlib, json, shutil, statistics, sys, tarfile
from collections import Counter
from pathlib import Path
P = Path(__file__).resolve().parent
R = P.parents[2]
E = R / 'examples/causal_video'
sys.path.insert(0, str(E))
from compact_gx_trace import compact
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def reduced(r): return {k:v for k,v in r.items() if k not in ('source_sha256','comfy_source_sha256')}
def inventory(rows):
    return Counter({(r['name'],tuple(r['grid']),tuple(r['block'])):r['count'] for r in rows})
out = {
    'system': 'ComfyUI-WanVideoWrapper', 'pins': read(P/'pins.json'),
    'workload': 'Real pretrained Wan 1.3B; public model-loading, text-encoding, sampling and VAE-decode nodes, under ComfyUI inference_mode. 17 frames, 256x448, 8 Euler steps, CFG 5, seed 42; CPU offload retained. UI, graph queue, previews and video encoding excluded.',
    'change': 'Opt-in caching of CPU checkpoint dtype conversions before weight uploads. Versioned source and result tensors, identity and dtype invalidate cached entries. CPU checkpoint loading and cached CPU conversions leave inference_mode only to retain version counters; node GPU execution remains in inference_mode.',
    'flag': 'WANWRAPPER_CPU_CAST_CACHE=0 versus 1, read at module import',
    'gx': {}, 'native_A100': {}, 'traces': {},
    'checks': read(P/'cast-cache-inference-check.json'),
    'limitations': [
        'Cache retains 2,836,681,856 bytes of extra CPU tensors. This is a host-memory-for-CPU-time tradeoff, not a free optimization.',
        'GX host CPU is EPYC 7702P; A100 validation host CPU is EPYC 9554. Calibration is not matched to native CPU hardware.',
        'GX CPU calibration has 9,339 resolved and 2,594 unresolved samples (21.74% unresolved).',
        'Mode 2 predicted launch inventories match; ten unpredicted cuDNN transform launches have differing malformed dimensions. Mode 3 also selects different cuDNN plans, with 10 versus 40 misses. Missing launches receive no predicted service; coverage by launch count is not time coverage.',
        'GX overestimates the native reduction. Native timings drift across ABBA process groups; all samples and both mean and median are retained.',
        'Single prompt, seed, shape, unquantized checkpoint and ordinary CPU offload. Training, arbitrary streams, direct .data mutation, concurrent weight mutation, and arbitrary ComfyUI graphs are not validated.',
        'The initial native kernel calibration used no_grad; the selected timing experiment uses inference_mode. Calibration report peak_gpu_bytes covers only the post-reset VAE phase; selected reports preserve peaks across all internal resets.',
        'Physical GPU1 was idle before validation; unrelated GPU0 work may share host resources.',
    ],
}
for mode,prefix in [('mode2','inference'),('mode3','infer-sync')]:
    records={}; audits={}
    for side in ('before','after'):
        a=read(P/f'{prefix}-{side}-audit.json'); audits[side]=a
        assert a['result']['passed'] and not a['result']['cleanup_errors']
        records[side]={k:a[k] for k in ('run','result','summary','iterations','misses','gpu_db_sha256','cpu_db_sha256')}
        records[side]['model']=reduced(a['model'])
        records[side]['mean_seconds']=statistics.mean(i['virtual_seconds'] for i in a['iterations'])
        for name in ('source_sha256','comfy_source_sha256'):
            if name not in out: out[name]=a['model'][name]
            assert out[name]==a['model'][name]
        assert a['model']['runner_sha256']==sha(P/'runner_inference.py')
        if mode=='mode2':
            src=Path(a['run'])/'timeline-report/trace.json.gz'
            dst=E/f'evidence/wanwrapper-mode2-{side}.chrome.json.gz'
            out['traces'][side]={'file':dst.name,'full_trace':str(src),**compact(src,dst,bin_ms=10)}
    assert records['before']['summary']['copies']==records['after']['summary']['copies']
    records['reduction_percent']=100*(1-records['after']['mean_seconds']/records['before']['mean_seconds'])
    records['full_compute_inventories_match']=audits['before']['launches']==audits['after']['launches']
    records['predicted_compute_inventories_match']=(inventory(audits['before']['launches'])-inventory(audits['before']['misses'])==inventory(audits['after']['launches'])-inventory(audits['after']['misses']))
    out['gx'][mode]=records
reports=[]
for i,side in enumerate(('before','after','after','before'),1):
    r=read(P/f'native-cast-{i}-{side}.json')
    assert r['phase']=='completed' and len(r['iterations'])==5
    for name in ('source_sha256','comfy_source_sha256'): assert out[name]==r[name]
    assert r['runner_sha256']==sha(P/'runner_inference.py')
    assert bool(r['cpu_cast_cache_bytes'])==(side=='after')
    assert all(t['finite'] for t in r['iterations'])
    reports.append(reduced(r)|{'variant':side})
n={'status':'complete','process_order':['before','after','after','before'],'warmup_per_process':2,'repetitions_per_process':5,'reports':reports,'hardware':read(P/'native-cast-hardware.json')}
assert len({i['output_sha256'] for r in reports for i in r['iterations']})==1
n['all_20_output_hashes_identical']=True
for side in ('before','after'):
    rs=[r for r in reports if r['variant']==side]
    times=[i['application_clock_seconds'] for r in rs for i in r['iterations']]
    n[side]={'seconds':times,'mean_seconds':statistics.mean(times),'median_seconds':statistics.median(times),'peak_host_rss_bytes':[r['peak_host_rss_bytes'] for r in rs],'peak_gpu_bytes':[r['peak_gpu_bytes'] for r in rs],'cpu_cast_cache_bytes':[r['cpu_cast_cache_bytes'] for r in rs]}
for stat in ('mean','median'): n[stat+'_reduction_percent']=100*(1-n['after'][stat+'_seconds']/n['before'][stat+'_seconds'])
out['native_A100']=n
shutil.copyfile(P/'cpu-cast-cache-inference.patch',E/'cpu_patches/wanwrapper_cpu_cast_cache.patch')
shutil.copyfile(P/'runner_inference.py',E/'wanwrapper_runner.py')
out['patch']={'file':'../cpu_patches/wanwrapper_cpu_cast_cache.patch','sha256':sha(P/'cpu-cast-cache-inference.patch')}
names=['runner_inference.py','runner-calibration.py','cpu-cast-cache-inference.patch','check_cast_inference.py','utils-inference.py','cast-cache-inference-check.json','run_inference_pair.py','run_infer_sync_pair.py','run_native_cast.py','validate-cast-native.sh','inference-before.json','inference-after.json','infer-sync-before.json','infer-sync-after.json','pins.json','cpu-inference-calibration.json','native-cast-hardware.json','audit.py','package_inference.py']
bundle=E/'evidence/wanwrapper-reproduce.tar.gz'
with tarfile.open(bundle,'w:gz') as tar:
    for name in names: tar.add(P/name,arcname=name)
out['reproduction']={'file':bundle.name,'sha256':sha(bundle),'files':names,'note':'Adjust host and asset paths; apply patch to pinned Wrapper source. Reuses the existing native kernel database. Shared GX worker launcher and audit helpers live in this repository.'}
dbdir=E/'evidence/kernel-databases'; m=read(dbdir/'manifest.json'); calibration={}
for key,src,dest in [('database','gpu.sqlite','wanwrapper-wan.sqlite.gz'),('native_report','kernel-profile.json','wanwrapper-wan.report.json.gz'),('cpu_instruction_calibration','cpu-inference.db','wanwrapper-wan.cpu.db.gz')]:
    raw=(P/src).read_bytes(); target=dbdir/dest; target.write_bytes(gzip.compress(raw,compresslevel=9,mtime=0)); assert gzip.decompress(target.read_bytes())==raw
    calibration[key]={'file':dest,'source':str(P/src),'uncompressed_bytes':len(raw),'uncompressed_sha256':sha(P/src),'gzip_sha256':sha(target)}
calibration['scope']=out['workload'];out['calibration']=calibration
# Retain the manifest's existing schema and other systems.
assert 'wanwrapper-wan' not in m or isinstance(m['wanwrapper-wan'],dict)
target = m['artifacts']
target['wanwrapper-wan']=calibration
(dbdir/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
(E/'evidence/wanwrapper-cpu.json').write_text(json.dumps(out,indent=2)+'\n')
print('WANWRAPPER_PACKAGE_PASS', {mode:r['reduction_percent'] for mode,r in out['gx'].items()}, {stat:n[stat+'_reduction_percent'] for stat in ('mean','median')})
