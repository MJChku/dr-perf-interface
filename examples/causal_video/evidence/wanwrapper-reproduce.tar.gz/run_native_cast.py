"""Confirm the GX-screened inference-context candidate; retain every sample."""
import hashlib, json, subprocess
from pathlib import Path
P = Path(__file__).resolve().parent
R = P.parents[2]
pair = json.loads((P/'inference-pair.json').read_text())
assert pair.get('finished_unix')
reports = {}
for side in ('before', 'after'):
    a = json.loads((P/f'inference-{side}-audit.json').read_text())
    assert a['result']['passed'] and not a['result']['cleanup_errors']
    reports[side] = a
assert reports['before']['summary']['copies'] == reports['after']['summary']['copies']
assert reports['after']['model']['cpu_cast_cache_bytes'] > 0
ssh = ['ssh', '-o', 'ConnectTimeout=10', '-o', 'ConnectionAttempts=3', 'jcm@A100']
base = '/home/jcm/drperf-wan-a100-20260916/causal/wanwrapper'
checks = {base+'/source-cast/'+str(f.relative_to(P/'source-cast')): hashlib.sha256(f.read_bytes()).hexdigest()
          for f in (P/'source-cast').rglob('*.py')}
checks.update({base+'/comfy/'+str(f.relative_to(P.parent/'ComfyUI')): hashlib.sha256(f.read_bytes()).hexdigest()
               for f in (P.parent/'ComfyUI').rglob('*.py')})
for name in ('runner_inference.py', 'validate-cast-native.sh'):
    checks[base+'/'+name] = hashlib.sha256((P/name).read_bytes()).hexdigest()
script = 'import json,hashlib; checks=json.loads(%r); assert all(hashlib.sha256(open(p,"rb").read()).hexdigest()==v for p,v in checks.items()); print("NATIVE_CAST_IDENTITIES_PASS",len(checks))' % json.dumps(checks)
subprocess.run(ssh+['python3 -'], input=script, text=True, check=True)
(P/'native-cast-identities.json').write_text(json.dumps(checks, indent=2)+'\n')
active = subprocess.check_output(ssh+['nvidia-smi --query-compute-apps=gpu_uuid,pid --format=csv,noheader'], text=True)
assert 'GPU-521def15-8599-2c15-65ee-6dac40f31a64' not in active, active
hardware = {
    'gpu_inventory_csv': subprocess.check_output(ssh+['nvidia-smi --query-gpu=index,name,uuid,driver_version,memory.total --format=csv'], text=True),
    'active_compute_processes_before_start_csv': active,
    'container_device_requests': json.loads(subprocess.check_output(ssh+['docker inspect --format "{{json .HostConfig.DeviceRequests}}" drperf-wan-native-0'], text=True)),
    'note': 'Validation uses physical GPU1; GPU0 may have unrelated work sharing host resources.',
}
assert hardware['container_device_requests'][0]['DeviceIDs'] == ['1']
(P/'native-cast-hardware.json').write_text(json.dumps(hardware, indent=2)+'\n')
helper = R/'examples/wan_gx/native_container.py'
try:
    subprocess.run(['python3', str(helper), 'resume'], check=True)
    subprocess.run(ssh+['docker exec -u jma drperf-wan-native-0 bash /workspace/causal/wanwrapper/validate-cast-native.sh'], check=True)
    for i, side in enumerate(('before', 'after', 'after', 'before'), 1):
        subprocess.run(['rsync', '-az', '-e', 'ssh -o ConnectTimeout=10 -o ConnectionAttempts=3',
                        f'jcm@A100:/home/jcm/drperf-wan-a100-20260916/causal/runs/wanwrapper-cast-{i}-{side}/report.json',
                        str(P/f'native-cast-{i}-{side}.json')], check=True)
    print('WANWRAPPER_NATIVE_CAST_PASS', flush=True)
finally:
    subprocess.run(['python3', str(helper), 'stop'], check=True)
