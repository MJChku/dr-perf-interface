"""Check CPU cache values, invalidation, and ownership without a CUDA device."""
import ast, gc, json, weakref
from pathlib import Path
import torch
P = Path(__file__).resolve().parent
tree = ast.parse((P/'utils-inference.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == '_cached_cpu_cast')
ns = {'torch': torch, 'weakref': weakref}
exec(compile(ast.Module(body=[node], type_ignores=[]), '<tested helper>', 'exec'), ns)
cast = ns['_cached_cpu_cast']
checks = []
torch.manual_seed(42)
with torch.no_grad():
    for layout in ('contiguous', 'transposed'):
        m = torch.nn.Module()
        x = torch.randn(11, 7)
        if layout == 'transposed': x = x.t()
        y = cast(m, 'weight', x, torch.bfloat16, 'cuda:0')
        assert torch.equal(y, x.to(torch.bfloat16))
        assert cast(m, 'weight', x, torch.bfloat16, 'cuda:0') is y
        x.add_(0.75)
        z = cast(m, 'weight', x, torch.bfloat16, 'cuda:0')
        assert z is not y and torch.equal(z, x.to(torch.bfloat16))
        z.zero_()
        z2 = cast(m, 'weight', x, torch.bfloat16, 'cuda:0')
        assert z2 is not z and torch.equal(z2, x.to(torch.bfloat16))
        x2 = torch.zeros_like(x)
        z3 = cast(m, 'weight', x2, torch.bfloat16, 'cuda:0')
        assert torch.equal(z3, x2.to(torch.bfloat16)) and z3 is not z2
        z4 = cast(m, 'weight', x2, torch.float16, 'cuda:0')
        assert z4.dtype == torch.float16 and torch.equal(z4, x2.to(torch.float16))
        assert cast(m, 'weight', x2, torch.float16, 'cpu') is not z4
        assert cast(m, 'weight', x2, x2.dtype, 'cuda:0') is x2
        m.to('meta')
        assert m._wan_cpu_cast_cache['weight'][3].device.type == 'cpu'
        assert not m.state_dict()
        ref = weakref.ref(x2)
        del x2
        gc.collect()
        assert ref() is None
        checks.append(layout + ': values, hits, source/target version changes, identity, dtype, CPU fallback, ownership')

m = torch.nn.Module()
x = torch.randn(7, requires_grad=True)
with torch.enable_grad():
    y = cast(m, 'weight', x, torch.float64, 'cuda:0')
    y.sum().backward()
assert torch.equal(x.grad, torch.ones_like(x)) and not hasattr(m, '_wan_cpu_cast_cache')
with torch.no_grad():
    cast(m, 'weight', x, torch.bfloat16, 'cuda:0')
assert not hasattr(m, '_wan_cpu_cast_cache')
checks.append('autograd and requires-grad sources fall back')
with torch.inference_mode():
    x = torch.randn(7)
    y = cast(m, 'weight', x, torch.bfloat16, 'cuda:0')
    assert torch.equal(y, x.to(torch.bfloat16)) and not hasattr(m, '_wan_cpu_cast_cache')
with torch.inference_mode():
    # The candidate loader explicitly creates versioned checkpoint tensors.
    with torch.inference_mode(False), torch.no_grad(): x = torch.randn(7)
    y = cast(m, 'weight', x, torch.bfloat16, 'cuda:0')
    assert torch.equal(y, x.to(torch.bfloat16)) and y._version == 0
    assert cast(m, 'weight', x, torch.bfloat16, 'cuda:0') is y
    version = x._version
    x.add_(1)
    assert x._version > version
    z = cast(m, 'weight', x, torch.bfloat16, 'cuda:0')
    assert z is not y and torch.equal(z, x.to(torch.bfloat16))
checks.append('versionless sources fall back; versioned checkpoint sources cache and invalidate inside inference_mode')
out = {'passed': True, 'checks': checks, 'scope': 'CPU conversion cache only; CUDA scheduling and complete outputs require separate native validation.'}
(P/'cast-cache-inference-check.json').write_text(json.dumps(out, indent=2)+'\n')
print('CAST_CACHE_CHECK_PASS', json.dumps(checks))
