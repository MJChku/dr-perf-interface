"""Managed serial before/after runs and reports; stop on any failed cleanup."""
import json,os,re,subprocess,time
from pathlib import Path
P=Path(__file__).resolve().parent;GX=Path('/home/ubuntu/GX/NEX');ROOT=P.parents[2]
state={'started_unix':time.time(),'runs':{}}
def save():(P/'async-all-pair.json').write_text(json.dumps(state,indent=2)+'\n')
save()
for key in ['before','after']:
 side=key
 start=time.monotonic()
 with (P/('async-all-'+side+'.log')).open('w') as f:
  result=subprocess.run(['python3',str(P.parent/'inferix-kv-14b-timing/run_on_worker.py'),str(P/('async-all-'+side+'.json'))],cwd=GX,env=os.environ|{'SSH_BASE_PORT':'2268'},stdout=f,stderr=subprocess.STDOUT)
 log=(P/('async-all-'+side+'.log')).read_text();paths=re.findall(r'(?:result|logs)=(/[^\s]+)',log);assert paths,log[-4000:]
 run=Path(paths[-1]);run=run.parent if run.name=='result.json' else run
 r=json.loads((run/'result.json').read_text());state['runs'][side]={'run':str(run),'controller_wall_seconds':time.monotonic()-start,'result':r};save();assert result.returncode==0 and r['passed'] and not r['cleanup_errors'],r
 with (P/('async-all-report-'+side+'.log')).open('w') as f:subprocess.run([str(GX/'tools/gxvm/gxvm'),'report',str(run)],cwd=GX,stdout=f,stderr=subprocess.STDOUT,check=True)
 state['runs'][side]['summary']=json.loads((run/'timeline-report/summary.json').read_text());save()
state['finished_unix']=time.time();save();print('DIFFSYNTH_ASYNC_ALL_PAIR_PASS',flush=True)
