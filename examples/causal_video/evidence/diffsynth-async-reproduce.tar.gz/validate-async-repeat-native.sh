#!/usr/bin/env bash
set -euo pipefail
ulimit -c 0
export PYTHONPATH=/workspace/causal/diffsynth/deps:/workspace/causal/scope-deps:/workspace/causal/flashdreams-deps:/workspace/causal/deps:/workspace/deps
export LD_LIBRARY_PATH=/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cudnn/lib
export LD_PRELOAD=/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cublas/lib/libcublas.so.12:/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cublas/lib/libcublasLt.so.12
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONHASHSEED=0 TOKENIZERS_PARALLELISM=false HF_HUB_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1
export DIFFSYNTH_SKIP_DOWNLOAD=True DIFFSYNTH_ATTENTION_IMPLEMENTATION=flash_attention_2
index=0
for side in before after after before; do
  index=$((index+1))
  busy=$(nvidia-smi -i GPU-521def15-8599-2c15-65ee-6dac40f31a64 --query-compute-apps=pid --format=csv,noheader)
  [[ -z "$busy" ]] || { echo "GPU1 busy at boundary"; exit 1; }
  result=/workspace/causal/runs/diffsynth-async-repeat-${index}-${side}
  [[ ! -e "$result" ]]
  export DIFFSYNTH_ASYNC_WEIGHT_UPLOADS=0
  if [[ "$side" == after ]]; then export DIFFSYNTH_ASYNC_WEIGHT_UPLOADS=1; fi
  timeout -k 20 1200 python3 -u /workspace/causal/diffsynth/runner_async.py \
    --tree /workspace/causal/diffsynth/source-async --base /workspace/checkpoint \
    --output "$result" --role native --warmup 2 --repetitions 5 \
    --frames 17 --steps 8 --height 256 --width 448 --vram-limit 0 > "${result}.log" 2>&1
  echo "NATIVE_GROUP_PASS ${index} ${side}"
done
