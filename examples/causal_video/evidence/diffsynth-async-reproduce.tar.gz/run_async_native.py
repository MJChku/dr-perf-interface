"""A100 confirmation of the GX-screened asynchronous H2D candidate."""
import hashlib,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[2];remote='/home/jcm/drperf-wan-a100-20260916/causal/diffsynth'
a,b=[json.loads((P/f'async-all-{s}-audit.json').read_text()) for s in ['before','after']]
assert a['result']['passed'] and b['result']['passed'];assert a['summary']['copies']==b['summary']['copies']
checks={remote+'/source-async/'+str(f.relative_to(P/'source-async')):hashlib.sha256(f.read_bytes()).hexdigest() for f in (P/'source-async/diffsynth').rglob('*.py')}
for n in ['runner_async.py','validate-async-native.sh']:checks[remote+'/'+n]=hashlib.sha256((P/n).read_bytes()).hexdigest()
script='import hashlib,json;checks=json.loads(%r);assert all(hashlib.sha256(open(p,"rb").read()).hexdigest()==v for p,v in checks.items());print("ASYNC_NATIVE_IDENTITIES_PASS",len(checks))'%json.dumps(checks)
subprocess.run(['ssh','-o','ConnectTimeout=10','-o','ConnectionAttempts=3','jcm@A100','python3 -'],input=script,text=True,check=True)
active=subprocess.check_output(['ssh','-o','ConnectTimeout=10','jcm@A100','nvidia-smi --query-compute-apps=gpu_uuid,pid --format=csv,noheader'],text=True);assert 'GPU-521def15-8599-2c15-65ee-6dac40f31a64' not in active,active
(P/'async-native-identities.json').write_text(json.dumps(checks,indent=2)+'\n')
helper=R/'examples/wan_gx/native_container.py'
try:
 subprocess.run(['python3',str(helper),'resume'],check=True)
 subprocess.run(['python3',str(helper),'command','bash /workspace/causal/diffsynth/validate-async-native.sh'],check=True)
 for i,side in enumerate(['before','after','after','before'],1):subprocess.run(['rsync','-a',f'jcm@A100:/home/jcm/drperf-wan-a100-20260916/causal/runs/diffsynth-async-{i}-{side}/report.json',str(P/f'native-async-{i}-{side}.json')],check=True)
 print('DIFFSYNTH_ASYNC_NATIVE_PASS',flush=True)
finally:subprocess.run(['python3',str(helper),'stop'],check=True)
