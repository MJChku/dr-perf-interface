"""Preserve every sample, including the slow first native candidate request."""
import gzip, hashlib, json, shutil, statistics, sys, tarfile
from pathlib import Path
P = Path(__file__).resolve().parent
R = P.parents[2]
E = R / 'examples/causal_video'
sys.path.insert(0, str(E))
from compact_gx_trace import compact

def read(path):
    return json.loads(path.read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def reduced(report):
    return {k: v for k, v in report.items() if k not in ('source_sha256', 'cast_to')}

out = {
    'baseline': 'Previously hardened normalization copying; checkpoint loader change also present on both sides. This is an incremental comparison, not original upstream versus all changes.',
    'change': 'Opt-in nonblocking CPU-to-CUDA weight uploads during inference. CPU weights remain pipeline-owned and immutable; consumption remains stream-ordered. CPU/D2H/autograd paths retain original behavior.',
    'flag': 'DIFFSYNTH_ASYNC_WEIGHT_UPLOADS=0 versus 1, sampled at module import',
    'gx': {}, 'native_A100': {}, 'traces': {},
    'limitations': [
        'Both GX timing pairs selected different cuDNN plans; launch misses receive no predicted service. Exact attribution of the predicted change is limited.',
        'Mode-2 instruction CPU work increases slightly; this change reduces host waiting and improves overlap, rather than reducing transferred bytes or arithmetic.',
        'The first native candidate group contains a 15.393-second measured request. It is retained in every aggregate for that experiment. A separate fixed-length repeat was scheduled to investigate variability, not to replace the original samples.',
        'Same single prompt, seed and shape; no claim for concurrent weight mutation, arbitrary streams or training.',
        'Inherited calibration limitations: GPU profile used adaptive 2-GiB residency; timing runs force full offload, and CPU calibration contains unresolved samples.',
    ],
    'checks': {n: read(P / f'{n}.json') for n in ('async-direction-check', 'async-all-norm-check')},
}
for mode, prefix in [('mode2', 'async-all'), ('mode3', 'async-sync')]:
    records = {}
    for side in ('before', 'after'):
        a = read(P / f'{prefix}-{side}-audit.json')
        assert a['result']['passed'] and not a['result']['cleanup_errors']
        records[side] = {k: a[k] for k in ('run', 'result', 'summary', 'iterations', 'misses', 'gpu_db_sha256', 'cpu_db_sha256')}
        records[side]['model'] = reduced(a['model'])
        records[side]['mean_seconds'] = statistics.mean(i['virtual_seconds'] for i in a['iterations'])
        if 'source_sha256' not in out:
            out['source_sha256'] = a['model']['source_sha256']
        assert out['source_sha256'] == a['model']['source_sha256']
        if mode == 'mode2':
            src = Path(a['run']) / 'timeline-report/trace.json.gz'
            dst = E / f'evidence/diffsynth-async-mode2-{side}.chrome.json.gz'
            out['traces'][side] = {'file': dst.name, 'full_trace': str(src), **compact(src, dst, bin_ms=10)}
    assert records['before']['summary']['copies'] == records['after']['summary']['copies']
    records['reduction_percent'] = 100 * (1 - records['after']['mean_seconds'] / records['before']['mean_seconds'])
    records['compute_launch_inventories_identical'] = read(P / f'{prefix}-before-audit.json')['launches'] == read(P / f'{prefix}-after-audit.json')['launches']
    out['gx'][mode] = records

for name, prefix, warmup, repetitions in [('initial', 'native-async', 1, 3), ('repeat', 'native-async-repeat', 2, 5)]:
    paths = [P / f'{prefix}-{i}-{s}.json' for i, s in enumerate(('before', 'after', 'after', 'before'), 1)]
    if not all(p.exists() for p in paths):
        out['native_A100'][name] = {'status': 'pending', 'warmup': warmup, 'repetitions_per_process': repetitions}
        continue
    reports = [read(p) for p in paths]
    for report in reports:
        assert report['phase'] == 'completed'
        assert report['source_sha256'] == out['source_sha256']
        assert report['runner_sha256'] == sha(P / 'runner_async.py')
        assert len(report['iterations']) == repetitions
    assert len({i['output_sha256'] for r in reports for i in r['iterations']}) == 1
    n = {'status': 'complete', 'process_order': ['before', 'after', 'after', 'before'], 'warmup_per_process': warmup,
         'repetitions_per_process': repetitions, 'reports': [reduced(r) for r in reports],
         'source_manifest': out['source_sha256'], 'all_output_hashes_identical': True}
    for side in ('before', 'after'):
        chosen = [r for r in reports if r['async_weight_uploads'] == (side == 'after')]
        times = [i['application_clock_seconds'] for r in chosen for i in r['iterations']]
        n[side] = {'seconds': times, 'median_seconds': statistics.median(times), 'mean_seconds': statistics.mean(times),
                   'peak_allocated_bytes': [r['peak_gpu_bytes'] for r in chosen]}
    for statistic in ('median', 'mean'):
        n[f'{statistic}_reduction_percent'] = 100 * (1 - n['after'][f'{statistic}_seconds'] / n['before'][f'{statistic}_seconds'])
    out['native_A100'][name] = n

patch = E / 'cpu_patches/diffsynth_async_upload.patch'
shutil.copyfile(P / 'async-all-weight-upload.patch', patch)
shutil.copyfile(P / 'runner_async.py', E / 'diffsynth_runner.py')
out['patch'] = {'file': '../cpu_patches/' + patch.name, 'sha256': sha(patch), 'apply_after': 'diffsynth_norm_copy.patch; loader patch was also present in measured trees, outside measured generation'}
names = ['runner.py', 'runner_async.py', 'async-all-weight-upload.patch', 'async-all-before.json', 'async-all-after.json',
         'async-sync-before.json', 'async-sync-after.json', 'run_async_all_pair.py', 'run_async_sync_pair.py',
         'run_async_native.py', 'run_async_repeat_native.py', 'validate-async-native.sh', 'validate-async-repeat-native.sh',
         'async-direction-check.json', 'async-all-norm-check.json', 'check_async_norm.py', 'package_async.py']
bundle = E / 'evidence/diffsynth-async-reproduce.tar.gz'
with tarfile.open(bundle, 'w:gz') as tar:
    for name in names:
        assert (P / name).is_file(), name
        tar.add(P / name, arcname=name)
out['reproduction'] = {'file': bundle.name, 'sha256': sha(bundle), 'files': names, 'note': 'Adjust host and asset paths. Uses existing DiffSynth kernel and CPU databases. Historical GX runner differs from native runner only in report metadata.'}
evidence = E / 'evidence/diffsynth-cpu.json'
d = read(evidence)
d['async_uploads'] = out
evidence.write_text(json.dumps(d, indent=2) + '\n')
print('PACKAGE_ASYNC_PASS', json.dumps({m: r['reduction_percent'] for m, r in out['gx'].items()}))
for name, r in out['native_A100'].items():
    print(name, r['status'], r.get('median_reduction_percent'), r.get('mean_reduction_percent'))
