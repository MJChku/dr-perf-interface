import json,resource,time
from importlib.metadata import version
import torch
from kokoro import KModel,KPipeline
print('KOKORO_IMPORT_PASS',json.dumps({n:version(n)for n in ('torch','torchaudio','transformers','numpy','kokoro','misaki','spacy','en-core-web-sm')}),flush=True)
torch.set_num_threads(1);torch.set_num_interop_threads(1);start=time.perf_counter()
base='/workspace/causal/models/Kokoro-82M/'
model=KModel(repo_id='hexgrad/Kokoro-82M',config=base+'config.json',model=base+'kokoro-v1_0.pth').to('cuda').eval()
pipeline=KPipeline(lang_code='a',repo_id='hexgrad/Kokoro-82M',model=model)
voice=pipeline.load_voice(base+'voices/af_heart.pt')
print('KOKORO_LOAD_PASS',json.dumps({'seconds':time.perf_counter()-start,'parameters':sum(p.numel()for p in model.parameters()),'voice_shape':list(voice.shape),'peak_gpu_bytes':torch.cuda.max_memory_allocated(),'peak_host_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'phonemization':pipeline.g2p('Hello. This is a test of speech generation.')[0]}),flush=True)
