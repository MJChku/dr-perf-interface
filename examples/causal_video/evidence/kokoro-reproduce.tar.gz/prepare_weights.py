"""Opt-in inference preparation after final device/dtype placement."""
from pathlib import Path
import difflib,json,shutil
P=Path(__file__).resolve().parent;src=P/'source';dst=P/'source-prepared';assert not dst.exists();shutil.copytree(P/'source-optimized',dst)
f=dst/'kokoro/model.py';s=f.read_text();needle='    @property\n    def device(self):';insert='''    @torch.no_grad()
    def prepare_for_inference(self):
        """Materialize parametrized weights after loading and final placement.

        This is an opt-in, irreversible inference conversion: the resulting
        state_dict stores plain weights. Reload the original model to train or
        load a checkpoint that uses weight-normalization parametrizations.
        """
        if self.training:
            raise RuntimeError("Call eval() before prepare_for_inference()")
        from torch.nn.utils import parametrize
        for module in self.modules():
            if parametrize.is_parametrized(module, "weight"):
                parametrize.remove_parametrizations(module, "weight", leave_parametrized=True)
        return self

''';assert needle in s;f.write_text(s.replace(needle,insert+needle))
patch=[]
for rel in ['kokoro/model.py','kokoro/modules.py']:
 old=(src/rel).read_text();new=(dst/rel).read_text();patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(P/'prepared-inference.patch').write_text(''.join(patch))
r=(P/'runner.py').read_text();r=r.replace("p.add_argument('--plain',action='store_true');","p.add_argument('--plain',action='store_true');p.add_argument('--prepare-inference',action='store_true');")
r=r.replace("'plain':a.plain,","'plain':a.plain,'prepare_inference':a.prepare_inference,")
r=r.replace("pipeline=KPipeline(lang_code='a'", "if a.prepare_inference:model.prepare_for_inference()\npipeline=KPipeline(lang_code='a'")
(P/'runner-prepared.py').write_text(r)
for side in ['before','after']:
 x=json.loads((P/('partial.json'if side=='before'else'optimized.json')).read_text());x['name']='kokoro-prep-'+side;x['files']['runner']=str(P/'runner-prepared.py')
 if side=='after':x['files']['source']=str(dst);x['application']['command'].append('--prepare-inference')
 (P/('prepared-'+side+'.json')).write_text(json.dumps(x,indent=2)+'\n')
print('KOKORO_WEIGHT_CANDIDATE_PREPARED')
