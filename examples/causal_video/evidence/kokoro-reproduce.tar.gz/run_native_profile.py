"""Initial kernel and GPU-dependent control calibration; GPU1 only, if idle."""
import hashlib,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[2]
load=Path('/home/ubuntu/GX/NEX/build/experiments/kokoro-load2-1789830958331329510')
result=json.loads((load/'result.json').read_text());assert result['passed'] and not result['cleanup_errors']
assert any('KOKORO_LOAD_PASS' in f.read_text()for f in (load/'host-0').glob('*.log'))
checks=json.loads((P/'native-identities.json').read_text())
assert checks['/home/jcm/drperf-wan-a100-20260916/causal/kokoro/runner.py']==hashlib.sha256((P/'runner.py').read_bytes()).hexdigest()
ssh=['ssh','-o','ConnectTimeout=10','-o','ConnectionAttempts=3','jcm@A100']
script='''import hashlib,json
checks=json.loads(%r)
for name,expected in checks.items():
 with open(name,'rb')as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==expected,name
print('KOKORO_NATIVE_IDENTITIES_PASS',len(checks))
'''%json.dumps(checks)
subprocess.run(ssh+['python3 -'],input=script,text=True,check=True)
active=subprocess.check_output(ssh+['nvidia-smi --query-compute-apps=gpu_uuid,pid --format=csv,noheader'],text=True)
assert 'GPU-521def15-8599-2c15-65ee-6dac40f31a64' not in active,active
hardware={'gpu_inventory':subprocess.check_output(ssh+['nvidia-smi --query-gpu=index,name,uuid,driver_version,memory.total --format=csv'],text=True),'active_compute_processes':active,'device_requests':json.loads(subprocess.check_output(ssh+['docker inspect --format "{{json .HostConfig.DeviceRequests}}" drperf-wan-native-0'],text=True))}
assert hardware['device_requests'][0]['DeviceIDs']==['1'];(P/'native-profile-hardware.json').write_text(json.dumps(hardware,indent=2)+'\n')
helper=R/'examples/wan_gx/native_container.py'
try:
 subprocess.run(['python3',str(helper),'resume'],check=True)
 subprocess.run(ssh+['docker exec -u jma drperf-wan-native-0 bash /workspace/causal/kokoro/profile.sh'],check=True)
 rsync=['rsync','-az','-e','ssh -o ConnectTimeout=10 -o ConnectionAttempts=3']
 remote='jcm@A100:/home/jcm/drperf-wan-a100-20260916/causal/runs/kokoro-kernels'
 for filename,target in [('report.json','kernel-profile.json'),('controls.json','controls.json'),('controls.npz','controls.npz')]:
  subprocess.run(rsync+[remote+'/'+filename,str(P/target)],check=True)
 dbs=subprocess.check_output(ssh+['find /home/jcm/drperf-wan-a100-20260916/causal/runs -maxdepth 1 -name \'kokoro-kernels.rank*.sqlite\' -print'],text=True).splitlines();assert len(dbs)==1,dbs
 subprocess.run(rsync+['jcm@A100:'+dbs[0],str(P/'gpu.sqlite')],check=True)
 print('KOKORO_NATIVE_PROFILE_PASS',flush=True)
finally:subprocess.run(['python3',str(helper),'stop'],check=True)
