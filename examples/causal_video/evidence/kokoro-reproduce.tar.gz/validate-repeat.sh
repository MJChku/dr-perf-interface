#!/usr/bin/env bash
set -euo pipefail
ulimit -c 0
export LD_LIBRARY_PATH=/workspace/causal/sglang/cuda13_libs:/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cudnn/lib
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONHASHSEED=0 TOKENIZERS_PARALLELISM=false HF_HUB_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1
export HF_HOME=/workspace/causal/hf-cache LOCAL_FILES_ONLY=true
export FLASHINFER_DISABLE_VERSION_CHECK=1
unset LD_PRELOAD GX_PREDICT_DB GX_PROFILE_SO GX_PROFILE_START_FILE GX_PROFILE_STOP_FILE
kokoro_index=0
for kokoro_side in before after after before; do
 kokoro_index=$((kokoro_index+1))
 kokoro_prepare=()
 [[ $kokoro_side == before ]] || kokoro_prepare=(--prepare-inference)
 kokoro_source=source
 [[ $kokoro_side == before ]] || kokoro_source=source-prepared
 export PYTHONPATH=/workspace/causal/kokoro/$kokoro_source:/workspace/causal/kokoro/deps:/workspace/causal/qwen-tts/deps:/workspace/causal/fastgen/deps:/workspace/causal/omni/extras:/workspace/causal/omni/deps:/workspace/causal/wan2gp/deps:/workspace/causal/wanwrapper/deps:/workspace/causal/sglang/deps:/workspace/causal/deps:/workspace/causal/scope-deps:/workspace/causal/flashdreams-deps:/workspace/deps
 kokoro_out=/workspace/causal/runs/kokoro-repeat-plain-$kokoro_index-$kokoro_side
 [[ ! -e $kokoro_out ]]
 timeout -k 20 900 python3 -u /workspace/causal/kokoro/runner-prepared.py --model /workspace/causal/models/Kokoro-82M --output "$kokoro_out" "${kokoro_prepare[@]}" --role native --plain --warmup 10 --repetitions 20 > "$kokoro_out.log" 2>&1
 printf 'KOKORO_NATIVE_PROCESS_PASS %s %s\n' "$kokoro_index" "$kokoro_side"
done
# One additional pair checks original native scalar/CPU-array controls and
# STFT shape formulas. These guarded runs do not enter latency statistics.
for kokoro_side in before after; do
 kokoro_controls=controls.json
 [[ $kokoro_side == before ]] || kokoro_controls=controls-optimized.json
 kokoro_prepare=()
 [[ $kokoro_side == before ]] || kokoro_prepare=(--prepare-inference)
 kokoro_source=source
 [[ $kokoro_side == before ]] || kokoro_source=source-prepared
 export PYTHONPATH=/workspace/causal/kokoro/$kokoro_source:${PYTHONPATH#*:}
 kokoro_out=/workspace/causal/runs/kokoro-repeat-control-$kokoro_side
 [[ ! -e $kokoro_out ]]
 timeout -k 20 900 python3 -u /workspace/causal/kokoro/runner-prepared.py --model /workspace/causal/models/Kokoro-82M --output "$kokoro_out" "${kokoro_prepare[@]}" --role native --controls /workspace/causal/kokoro/"$kokoro_controls" --control-arrays /workspace/causal/kokoro/controls.npz --warmup 1 --repetitions 1 > "$kokoro_out.log" 2>&1
 printf 'KOKORO_NATIVE_CONTROL_PASS %s\n' "$kokoro_side"
done
