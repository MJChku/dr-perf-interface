"""Whole CPU model equivalence for inference preparation; not CUDA validation."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent
code='''import hashlib,json,random,sys,numpy as np,torch
from kokoro import KModel,KPipeline
torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.manual_seed(42)
base='/home/ubuntu/gx-ix14/causal/models/Kokoro-82M/'
model=KModel(repo_id='hexgrad/Kokoro-82M',config=base+'config.json',model=base+'kokoro-v1_0.pth').eval()
count=sum(torch.nn.utils.parametrize.is_parametrized(m,'weight') for m in model.modules())
if sys.argv[1]=='after':
 model.prepare_for_inference();assert not any(torch.nn.utils.parametrize.is_parametrized(m,'weight') for m in model.modules());model.prepare_for_inference()
pipeline=KPipeline(lang_code='a',repo_id='hexgrad/Kokoro-82M',model=model);voice=pipeline.load_voice(base+'voices/af_heart.pt')
torch.manual_seed(42);np.random.seed(42);random.seed(42)
x=list(pipeline('Hello. This is a test of speech generation.',voice=voice,speed=1.0))[0];w=x.audio.numpy();assert np.isfinite(w).all()
print('ORACLE '+json.dumps({'torch':torch.__version__,'samples':len(w),'hash':hashlib.sha256(w.tobytes()).hexdigest(),'durations':x.pred_dur.tolist(),'weight_normalized_modules':count}))
'''
reports={}
for side,folder in [('before','source'),('after','source-prepared')]:
 paths=[P/folder,P/'deps',P.parent/'qwen-tts/deps',P.parent/'fastgen/deps',P.parent/'sglang/deps']
 r=subprocess.run([sys.executable,'-c',code,side],env=os.environ|{'PYTHONPATH':':'.join(map(str,paths))},text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(P/('oracle-'+side+'.log')).write_text(r.stdout);assert r.returncode==0,r.stdout[-2000:];reports[side]=json.loads(next(x[7:]for x in r.stdout.splitlines()if x.startswith('ORACLE ')))
assert reports['before']==reports['after'],reports
(P/'weights-oracle.json').write_text(json.dumps({'reports':reports,'exact':True,'scope':'CPU whole-model oracle only. Actual A100 output/latency validation remains necessary.'},indent=2)+'\n');print('KOKORO_WEIGHT_ORACLE_PASS',reports['before'])
