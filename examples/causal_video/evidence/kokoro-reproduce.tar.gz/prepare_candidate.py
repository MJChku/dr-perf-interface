"""Keep known lengths on CPU and avoid sorting a one-element packed batch."""
from pathlib import Path
import difflib,json,shutil
P=Path(__file__).resolve().parent;src=P/'source';dst=P/'source-optimized';assert not dst.exists();shutil.copytree(src,dst,ignore=shutil.ignore_patterns('.git','__pycache__','build','*.egg-info'))
patch=[]
for rel in ('kokoro/model.py','kokoro/modules.py'):
 f=dst/rel;old=f.read_text()
 if rel.endswith('model.py'):
  new=old.replace('            device=input_ids.device,','            device="cpu",')
  before='''        text_mask = torch.arange(input_lengths.max()).unsqueeze(0).expand(input_lengths.shape[0], -1).type_as(input_lengths)
        text_mask = torch.gt(text_mask+1, input_lengths.unsqueeze(1)).to(self.device)'''
  after='''        # Every row spans the full input width; packing consumes host lengths.
        text_mask = torch.zeros(input_ids.shape, dtype=torch.bool, device=self.device)'''
  assert before in new;new=new.replace(before,after)
 else:
  assert old.count('enforce_sorted=False')==3
  new=old.replace('enforce_sorted=False','enforce_sorted=(lengths.numel() == 1)')
 f.write_text(new);patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(P/'metadata.patch').write_text(''.join(patch))
d=json.loads((P/'controls.json').read_text());removed=[]
for events in d['requests']:
 gone=[e for e in events if e['tag'][0]=='arange_shape' or e['tag'][:3]==['to_cpu','modules.py','forward'] or e['tag'][:3]==['cpu','rnn.py','pad_packed_sequence']]
 assert len(gone)==9
 removed.append(gone);events[:]=[e for e in events if e not in gone]
 assert len(events)==4
(P/'controls-optimized.json').write_text(json.dumps(d,indent=2)+'\n');(P/'removed-controls.json').write_text(json.dumps(removed,indent=2)+'\n')
x=json.loads((P/'partial.json').read_text());x['name']='kokoro-optimized';x['files']['source']=str(dst);x['files']['controls']=str(P/'controls-optimized.json');(P/'optimized.json').write_text(json.dumps(x,indent=2)+'\n')
print('KOKORO_CANDIDATE_PREPARED',flush=True)
