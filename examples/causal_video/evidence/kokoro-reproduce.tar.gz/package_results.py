"""Record simulation and native measurements separately, with compact traces."""
import gzip,hashlib,json,shutil,statistics,subprocess,sys,tarfile,tempfile
from pathlib import Path
P=Path(__file__).resolve().parent;E=P.parents[2]/'examples/causal_video';sys.path.insert(0,str(E))
from compact_gx_trace import compact
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins={'source':{'remote':'https://github.com/hexgrad/kokoro.git','commit':subprocess.check_output(['git','-C',str(P/'source'),'rev-parse','HEAD'],text=True).strip()},'model':read(P/'model-manifest.json'),'dependencies':read(P/'kernel-profile.json')['versions'],'workload':read(P/'kernel-profile.json')['request'],'scope':read(P/'kernel-profile.json')['scope']};(P/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
limitations=[
 'One short English request, af_heart voice, seed42, resident FP32 model,73800samples at24kHz. Not an all-prompt, throughput or multi-request study.',
 'Opt-in prepare_for_inference must follow checkpoint loading, final device/dtype placement and eval(). It materializes89parametrized weights and changes state_dict format; reload the original model for training or loading parametrized checkpoints. Setup cost is outside warmed request latency.',
 'GX omits GPU arithmetic. Original scalar/array transfers remain except repeat_interleave shape discovery, for which recorded output_size123 avoids allocation from arbitrary fake durations. Original waveform/duration D2H copies remain; native CPU values are replayed for original word-timestamp processing.',
 'Real cuFFT fails with CUFFT_INTERNAL_ERROR under this GX runtime. GX-only20point/hop5STFT/ISTFT shape adapters omit FFT-related work and host dispatch. Native retains original FFT; guarded runs check actual shapes and controls. Baseline has13controls/request; candidates have4after9metadata controls are removed.',
 'Initial baseline has6106GX versus6170native launches for2requests; native-only isolated medians sum0.472045ms/request, including FFT/shape-discovery/FP32 GEMV omissions and different cuDNN plans. This is not an end-to-end correction. Six versus four uncovered submissions remain in selected before/after pairs.',
 'CPU calibration9unresolved out563instruction samples(1.60%),2unresolved task samples. GXhostEPYC7702P and nativehostEPYC9554 differ. Native primary timing removes tensor/FFT hooks. GX absolute times overpredict native; this is not a matched-host accuracy study.',
 'Mode3 uses10us epochs; CPU/GPU spans include synchronization/granularity effects. Outside-GPU spans are a prioritization heuristic, not hardware utilization or a universal speedup bound.',
 'Initial native2warmup/5measured ABBA had startup variation; both that comparison and a prespecified10warmup/20measured-per-process ABBA repeat are retained. The longer-warmup repeat is primary, with40samples/variant; no samples excluded.',
]
out={'system':'Kokoro','pins':pins,'change':'Opt-in materialization of89weight-normalized layers once for inference, plus CPU-known lengths/masks and a single-element packed-RNN sort specialization. Original model/source retained separately.','gx':{},'traces':{},'limitations':limitations,'native_kernel_calibration':read(P/'kernel-profile.json'),'kernel_calibration':read(P/'kernel-calibration.json'),'cpu_calibration':read(P/'cpu-calibration.json'),'omissions':read(P/'omissions.json'),'cpu_oracles':{'metadata':read(P/'metadata_oracle.json'),'whole_model':read(P/'weights-oracle.json')},'additional_screen':{'change':'Metadata-only','before':read(P/'partial-audit.json'),'after':read(P/'optimized-audit.json'),'scope':'GXmode2only,0.665%modeled gain. No standalone native validation.'}}
for mode,names in [('mode2',('prepared-before','prepared-after')),('mode3',('sync-before','sync-after'))]:
 pair={}
 for side,name in zip(('before','after'),names):
  a=read(P/(name+'-audit.json'));assert a['result']['passed']and not a['result']['cleanup_errors'];assert a['model']['runner_sha256']==sha(P/'runner-prepared.py');assert a['gpu_db_sha256']==sha(P/'gpu.sqlite')and a['cpu_db_sha256']==sha(P/'cpu.db')
  pair[side]=a|{'runtime':read(Path(a['run'])/'runtime.json'),'controller_wall_seconds':read(P/(name+'-run.json'))['controller_wall_seconds']};pair[side]['means']={k:statistics.mean(x[k]for x in a['iterations'])for k in ('virtual_seconds','cpu_seconds','gpu_span_seconds','outside_gpu_spans_seconds')}
  dst=E/f'evidence/kokoro-{mode}-{side}.chrome.json.gz';src=Path(a['run'])/'timeline-report/trace.json.gz';out['traces'][mode+'_'+side]={'file':dst.name,'full_trace':str(src),**compact(src,dst,bin_ms=.1)}
 assert pair['before']['runtime']['dynamorio']==pair['after']['runtime']['dynamorio']
 assert pair['before']['model']['iterations'][0]['control_count']==13 and pair['after']['model']['iterations'][0]['control_count']==4
 pair['request_reduction_percent']=100*(1-pair['after']['means']['virtual_seconds']/pair['before']['means']['virtual_seconds']);out['gx'][mode]=pair
for key,name,nexpected in [('native_A100','native-repeat-summary.json',80),('native_A100_initial','native-summary.json',20)]:
 n=read(P/name);assert n['measured_output_checks']==nexpected
 for block in n['reports']:
  report=block['report'];g=out['gx']['mode2'][block['side']]['model'];assert report['versions']==g['versions']and report['source_sha256']==g['source_sha256'];assert report['plain']and report['runner_sha256']==sha(P/'runner-prepared.py');assert {x['output_sha256']for x in report['iterations']}=={n['output_sha256']}
 for x in n['control_reports']:
  d=x['report'];assert all(e['native_shape_checked']for e in d['fft_adapters']);assert {r['output_sha256']for r in d['warmups']+d['iterations']}=={n['output_sha256']}
 out[key]=n|{'hardware':read(P/('native-repeat-hardware.json'if key=='native_A100'else'native-validation-hardware.json'))}
with tempfile.TemporaryDirectory(prefix='kokoro-patch-')as td:
 root=Path(td);shutil.copytree(P/'source',root/'source',ignore=shutil.ignore_patterns('.git','__pycache__'))
 subprocess.run(['git','apply',str(P/'prepared-inference.patch')],cwd=root/'source',check=True)
 for rel in ['kokoro/model.py','kokoro/modules.py']:assert (root/'source'/rel).read_bytes()==(P/'source-prepared'/rel).read_bytes()
out['patch_application_checked']=True
shutil.copyfile(P/'runner-prepared.py',E/'kokoro_runner.py');shutil.copyfile(P/'prepared-inference.patch',E/'cpu_patches/kokoro_prepared_inference.patch')
files=['pins.json','runner.py','runner-prepared.py','runner-calibration.py','metadata.patch','prepared-inference.patch','prepare_candidate.py','prepare_weights.py','model-manifest.json','download_model.py','controls.json','controls-optimized.json','controls.npz','removed-controls.json','load2.json','load_probe.py','emu.json','emu-shape.json','emu-fft.json','cpu.json','partial.json','optimized.json','prepared-before.json','prepared-after.json','sync-before.json','sync-after.json','audit.py','run_timing.py','run_cpu.py','profile.sh','run_native_profile.py','stage_native.py','kernel-calibration.json','cpu-calibration.json','omissions.json','native-calibration-identities.json','native-validation-identities.json','native-repeat-identities.json','native-profile-hardware.json','native-validation-hardware.json','native-repeat-hardware.json','run_native_validation.py','validate-native.sh','run_native_repeat.py','validate-repeat.sh','metadata_oracle.py','metadata_oracle.json','weights_oracle.py','weights-oracle.json','package_results.py']
bundle=E/'evidence/kokoro-reproduce.tar.gz'
with tarfile.open(bundle,'w:gz')as t:
 for name in files:t.add(P/name,arcname=name)
with tarfile.open(bundle,'r:gz')as t:
 assert sorted(t.getnames())==sorted(files)
 for name in files:assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==sha(P/name)
out['reproduction']={'file':bundle.name,'sha256':sha(bundle),'files':files,'note':'Install pinned source/dependencies and adjust host/file paths. Original native calibration uses archived runner-calibration.py and native-calibration-identities.json; final candidate uses runner-prepared.py with --prepare-inference. Separate filtered metadata tape retains array keys. Native plain timing requires no tape.'}
dbdir=E/'evidence/kernel-databases';manifest=read(dbdir/'manifest.json');artifacts={}
for key,name,target in [('native_database','gpu.sqlite','kokoro.sqlite.gz'),('native_report','kernel-profile.json','kokoro.report.json.gz'),('cpu_instruction_calibration','cpu.db','kokoro.cpu.db.gz')]:
 raw=(P/name).read_bytes();dst=dbdir/target;dst.write_bytes(gzip.compress(raw,compresslevel=9,mtime=0));assert gzip.decompress(dst.read_bytes())==raw;artifacts[key]={'file':target,'uncompressed_bytes':len(raw),'uncompressed_sha256':sha(P/name),'gzip_sha256':sha(dst)}
manifest['artifacts']['kokoro']=artifacts;(dbdir/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');out['calibration']=artifacts
allpins=read(E/'pins.json');allpins['Kokoro']=pins;(E/'pins.json').write_text(json.dumps(allpins,indent=2)+'\n');(E/'evidence/kokoro-cpu.json').write_text(json.dumps(out,indent=2)+'\n')
print('KOKORO_PACKAGE_PASS',json.dumps({'gx':{m:x['request_reduction_percent']for m,x in out['gx'].items()},'native_median':out['native_A100']['median_reduction_percent'],'native_mean':out['native_A100']['mean_reduction_percent']}),flush=True)
