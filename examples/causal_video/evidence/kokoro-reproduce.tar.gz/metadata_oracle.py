"""Check shape-derived masks and the single-element packed-RNN specialization."""
import json,torch
from pathlib import Path
torch.set_num_threads(1);torch.manual_seed(42)
mask_cases=[];rnn_cases=[]
for batch in (1,2,5):
 for length in (2,7,46,511,512):
  lengths=torch.full((batch,),length,dtype=torch.long)
  old=torch.arange(lengths.max()).unsqueeze(0).expand(batch,-1).type_as(lengths)
  old=torch.gt(old+1,lengths.unsqueeze(1))
  new=torch.zeros((batch,length),dtype=torch.bool)
  assert torch.equal(old,new)
  mask_cases.append([batch,length])
for length in (2,7,46,123):
 for bidi in (False,True):
  x=torch.randn(1,length,16);lengths=torch.tensor([length]);rnn=torch.nn.LSTM(16,8,batch_first=True,bidirectional=bidi).eval()
  outputs=[]
  for sorted_ in (False,True):
   packed=torch.nn.utils.rnn.pack_padded_sequence(x,lengths,batch_first=True,enforce_sorted=sorted_)
   y,h=rnn(packed);y,lens=torch.nn.utils.rnn.pad_packed_sequence(y,batch_first=True);outputs.append((y,*h,lens))
  assert all(torch.equal(a,b)for a,b in zip(*outputs))
  rnn_cases.append([length,bidi])
report={'torch':torch.__version__,'mask_cases':mask_cases,'single_batch_rnn_cases':rnn_cases,'exact':True,'scope':'CPU primitive checks only; native whole-model validation remains necessary.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
