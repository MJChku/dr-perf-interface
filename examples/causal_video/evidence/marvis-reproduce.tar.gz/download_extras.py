import hashlib,json,shutil,urllib.request
from pathlib import Path
P=Path(__file__).resolve().parent;f=P/'model-manifest.json';manifest=json.loads(f.read_text());root=Path(manifest['root']);extra=[]
for repo in ('kyutai/moshiko-pytorch-bf16','HuggingFaceTB/SmolLM2-135M'):
 with urllib.request.urlopen('https://huggingface.co/api/models/'+repo+'?blobs=true',timeout=120)as inp:d=json.load(inp)
 rev=d['sha'];wanted=('tokenizer-e351c8d8-checkpoint125.safetensors',)if repo.startswith('kyutai/')else('tokenizer.json','tokenizer_config.json','special_tokens_map.json','vocab.json','merges.txt','config.json')
 for x in d['siblings']:
  if x['rfilename']not in wanted:continue
  name=x['rfilename'];dest=root/('mimi'if repo.startswith('kyutai/')else'smollm-tokenizer')/name;dest.parent.mkdir(parents=True,exist_ok=True)
  if not dest.exists():
   tmp=dest.with_suffix(dest.suffix+'.download')
   with urllib.request.urlopen(f'https://huggingface.co/{repo}/resolve/{rev}/{name}',timeout=180)as inp,tmp.open('wb')as out:shutil.copyfileobj(inp,out,4*1024*1024)
   assert tmp.stat().st_size==x['size'];tmp.replace(dest)
  with dest.open('rb')as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
  if 'lfs'in x:assert digest==x['lfs']['sha256']
  row=dict(repository=repo,revision=rev,path=str(dest.relative_to(root)),bytes=dest.stat().st_size,sha256=digest,lfs_sha_verified='lfs'in x);extra.append(row);print('VERIFIED',row,flush=True)
manifest['files']=[x for x in manifest['files']if not x['path'].startswith(('mimi/','smollm-tokenizer/'))]+extra;f.write_text(json.dumps(manifest,indent=2)+'\n')
