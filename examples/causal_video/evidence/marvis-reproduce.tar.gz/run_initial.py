"""Gate native calibration on mode0 load, then verify the first complete GX request."""
import hashlib,json,os,re,sqlite3,subprocess,time
from pathlib import Path
P=Path(__file__).resolve().parent;GX=Path('/home/ubuntu/GX/NEX')
for _ in range(600):
 if (P/'native-identities.json').exists():
  paths=re.findall(r'(?:result|logs)=(/[^\s]+)',(P/'load4.log').read_text())
  if paths:
   run=Path(paths[-1]);run=run.parent if run.name=='result.json'else run
   if (run/'result.json').exists():
    d=json.loads((run/'result.json').read_text());assert d['passed']and not d['cleanup_errors'];break
 time.sleep(2)
else:raise RuntimeError('Initial staging/load timeout')
with (P/'native-profile.log').open('w')as f:subprocess.run(['python3',str(P/'run_native_profile.py')],stdout=f,stderr=subprocess.STDOUT,check=True)
c=sqlite3.connect(P/'gpu.sqlite');report=json.loads((P/'kernel-profile.json').read_text());assert report['phase']=='completed';hashes={x['output_sha256']for x in report['warmups']+report['iterations']};assert len(hashes)==1
# Keep the actual calibration runner and identities immutable.
(P/'runner-calibration.py').write_bytes((P/'runner.py').read_bytes());(P/'native-calibration-identities.json').write_bytes((P/'native-identities.json').read_bytes())
cols=[x[1]for x in c.execute('pragma table_info(kernel_samples)')];print('MARVIS_CALIBRATED',hashes,'sample_columns',cols,flush=True)
with (P/'emu.log').open('w')as f:r=subprocess.run(['python3',str(P.parent/'inferix-kv-14b-timing/run_on_worker.py'),str(P/'emu.json')],cwd=GX,env=os.environ|{'SSH_BASE_PORT':'2282'},stdout=f,stderr=subprocess.STDOUT)
paths=re.findall(r'(?:result|logs)=(/[^\s]+)',(P/'emu.log').read_text());assert paths;run=Path(paths[-1]);run=run.parent if run.name=='result.json'else run;d=json.loads((run/'result.json').read_text());assert r.returncode==0 and d['passed']and not d['cleanup_errors'],d
subprocess.run(['python3',str(P/'run_cpu.py')],check=True)
