import json,subprocess,time
from pathlib import Path
P=Path(__file__).resolve().parent
for _ in range(1800):
 if (P/'cat-after-run.json').exists():break
 time.sleep(2)
else:raise RuntimeError('Cat screen timeout')
a=json.loads((P/'cat-after-audit.json').read_text());assert a['result']['passed']and not a['result']['cleanup_errors']
for name in ('sync-before','sync-after'):
 for script in ('compress_completed.py','compress_workspace.py'):subprocess.run(['python3',str(P/script)],check=True)
 subprocess.run(['python3',str(P/'run_timing.py'),name],check=True)
