import hashlib,json,statistics,subprocess,time
from pathlib import Path
P=Path(__file__).resolve().parent
for _ in range(1800):
 if (P/'partial-audit.json').exists():break
 time.sleep(2)
else:raise RuntimeError('Baseline timeout')
b=json.loads((P/'partial-audit.json').read_text());assert b['result']['passed']and not b['result']['cleanup_errors'];print('MARVIS_BASELINE',statistics.mean(x['virtual_seconds']for x in b['iterations']),flush=True)
assert json.loads((P/'host-position-oracle.json').read_text())['passed']
# Hash differences from adding an opt-in flag/load-time metadata are kept
# separate; require an exactly matched final harness for the selected pair.
name='partial'
if b['model']['runner_sha256']!=hashlib.sha256((P/'runner.py').read_bytes()).hexdigest():
 subprocess.run(['python3',str(P/'run_timing.py'),'host-before'],check=True);name='host-before'
for script in ('compress_completed.py','compress_workspace.py'):subprocess.run(['python3',str(P/script)],check=True)
(P/'baseline-selection.json').write_text(json.dumps({'audit':name},indent=2)+'\n')
subprocess.run(['python3',str(P/'run_timing.py'),'host-after'],check=True)
