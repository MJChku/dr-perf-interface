import hashlib,importlib.util,json,os
from pathlib import Path
import torch
P=Path(__file__).resolve().parent
classes=[]
for name,folder in [('before','deps'),('after','deps-host')]:
 spec=importlib.util.spec_from_file_location(name,P/folder/'torchtune/modules/kv_cache.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);classes.append(m.KVCache)
torch.manual_seed(42);torch.set_num_threads(1);cases=0;updates=0
for dtype in (torch.float32,torch.bfloat16):
 for batch in (1,2):
  for heads in (1,3):
   for capacity in (1,8,17):
    for enabled in (False,True):
     a,b=[cls(batch,capacity,heads,4,dtype)for cls in classes]
     if enabled:b.enable_host_position_tracking(initial_size=0)
     for cycle in range(3):
      position=0
      while position<capacity:
       n=min(1+position%4,capacity-position);k=torch.randn(batch,heads,n,4).to(dtype);v=torch.randn_like(k)
       aa=a.update(k,v);bb=b.update(k,v);assert all(torch.equal(x,y)for x,y in zip(aa,bb));position+=n;updates+=1
       assert a.size==b.size==position;assert torch.equal(a.cache_pos,b.cache_pos)
      for obj in (a,b):
       k=torch.zeros(batch,heads,1,4,dtype=dtype)
       try:obj.update(k,k)
       except AssertionError:pass
       else:raise AssertionError('overflow accepted')
       assert obj.size==capacity
      a.reset();b.reset();assert a.size==b.size==0;assert torch.equal(a.k_cache,b.k_cache)and torch.equal(a.v_cache,b.v_cache)and torch.equal(a.cache_pos,b.cache_pos)
     cases+=1
# Enable at a valid nonzero known position; update/reset invariants still hold.
a,b=[cls(1,8,2,4,torch.float32)for cls in classes];x=torch.randn(1,2,3,4);a.update(x,x);b.update(x,x);b.enable_host_position_tracking(initial_size=3);y=torch.randn(1,2,2,4);a.update(y,y);b.update(y,y);assert a.size==b.size==5 and torch.equal(a.k_cache,b.k_cache);a.reset();b.reset();assert a.size==b.size==0;cases+=1
for cls in classes:
 obj=cls(1,8,1,4,torch.float32);x=torch.zeros(2,1,1,4)
 try:obj.update(x,x)
 except ValueError:pass
 else:raise AssertionError('oversized batch accepted')
 cases+=1
# Empty updates and a smaller batch preserve the original broadcasting behavior.
for batch,filled in ((2,0),(2,3),(1,8)):
 a,b=[cls(batch,8,2,4,torch.float32)for cls in classes];b.enable_host_position_tracking(initial_size=0)
 if filled:
  x=torch.randn(1,2,filled,4);a.update(x,x);b.update(x,x)
 empty=torch.empty(1,2,0,4);a.update(empty,empty);b.update(empty,empty)
 assert a.size==b.size==filled and torch.equal(a.k_cache,b.k_cache)and torch.equal(a.cache_pos,b.cache_pos);cases+=1
out={'passed':True,'cases':cases,'updates':updates,'scope':'Actual original/patched KVCache modules on CPU; varied shapes,dtypes,cycles,overflow,batch errors,activation at a known nonzero position. K/V tensors, GPU-position equivalent buffers and size agree exactly. Eager-only, exclusively owned state contract. Full-model A100 validation required.','patch_sha256':hashlib.sha256((P/'host-positions.patch').read_bytes()).hexdigest()};Path(os.environ.get('ORACLE_OUTPUT',str(P/'host-position-oracle.json'))).write_text(json.dumps(out,indent=2)+'\n');print('MARVIS_HOST_POSITION_ORACLE_PASS',json.dumps(out),flush=True)
