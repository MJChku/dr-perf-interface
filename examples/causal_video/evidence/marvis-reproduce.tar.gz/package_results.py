"""Keep GX predictions, initial calibration and final A100 validation distinct."""
import gzip,hashlib,json,shutil,statistics,subprocess,sys,tarfile,tempfile
from pathlib import Path
P=Path(__file__).resolve().parent;E=P.parents[2]/'examples/causal_video';sys.path.insert(0,str(E))
from compact_gx_trace import compact
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins={'source':{'remote':'https://github.com/Marvis-Labs/marvis-tts.git','commit':subprocess.check_output(['git','-C',str(P/'source'),'rev-parse','HEAD'],text=True).strip()},'model':read(P/'model-manifest.json'),'dependencies':read(P/'kernel-profile.json')['versions'],'workload':read(P/'kernel-profile.json')['request'],'scope':read(P/'kernel-profile.json')['scope']};(P/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
limits=[
 'One bounded original Generator.generate request: Hello.,speaker0,temperature0.9,topk50,seed42,32audioframes/2560ms cap. It reaches the cap; not a full-utterance quality or throughput study. Text processing, original semantic-codebook print, all sampling, Mimi decode and D2H included; no file encoding.',
 '568866816BF16 native TorchTune model parameters and79308609FP32 originalMimi parameters, strict original checkpoint loading. BF16 is the supported create_model default; the repository CLI explicitly uses FP32. Torch2.11cu128 retained although Moshi declares Torch<2.10; unquantized workload validated here, not general compatibility.',
 'Optional eager-only host position tracking requires exclusive cache ownership and update/reset as the only mutation paths. Caller supplies known initial position0 for ten newly allocated caches. Direct cache_pos mutations and torch.compile are unsupported when enabled. GPU K/V and position updates, resets and bounds enforcement remain.',
 'GX skips arithmetic; scalar/list/CPU-array controls replay after original transfers and waits. Native plain latency restores all tensor/arange hooks; separate guarded native requests validate controls. GX output hashes are not numerical validation.',
 'Baseline64native-only launches/request are FP32SGEMM and split-K reductions; isolated median sum1.114096ms is not an end-to-end correction. Zero prediction misses does not imply complete coverage. Candidate removes8320metadata kernels and4298device reads/request.',
 'CPU calibration1193unresolved of25596instruction samples(4.66%),41unresolved task samples. Initial CPU calibration precedes adding an opt-in flag and load-time report metadata; timed generate body unchanged, selected before/after GX and A100 use the same final runner. GX and A100 CPU hosts differ.',
 'Mode3 uses10us epochs. GPU spans include epoch placement effects; outside-GPU fractions are screening heuristics rather than hardware utilization or universal speedup bounds.',
 'Native unprofiled ABBA3warmups7measured requests/process,14pervariant,all28retained. Guarded controls excluded from latency statistics.',
]
out={'system':'Marvis','pins':pins,'change':'Track known cache length on the CPU in opt-in eager inference, replacing per-layer GPU scalar bounds/size reads while retaining all cache data and position updates.','gx':{},'traces':{},'limitations':limits,'native_kernel_calibration':read(P/'kernel-profile.json'),'kernel_calibration':read(P/'kernel-calibration.json'),'cpu_calibration':read(P/'cpu-calibration.json'),'omissions':read(P/'omissions.json'),'cpu_oracles':read(P/'host-position-oracle.json'),'selection':read(P/'selected.json')}
for mode,names in [('mode2',('host-before','host-after')),('mode3',('sync-before','sync-after'))]:
 pair={}
 for side,name in zip(('before','after'),names):
  a=read(P/(name+'-audit.json'));assert a['result']['passed']and not a['result']['cleanup_errors'];assert a['model']['runner_sha256']==sha(P/'runner.py');assert a['gpu_db_sha256']==sha(P/'gpu.sqlite')and a['cpu_db_sha256']==sha(P/'cpu.db')
  pair[side]=a|{'runtime':read(Path(a['run'])/'runtime.json'),'controller_wall_seconds':read(P/(name+'-run.json'))['controller_wall_seconds']};pair[side]['means']={k:statistics.mean(x[k]for x in a['iterations'])for k in ('virtual_seconds','cpu_seconds','gpu_span_seconds','outside_gpu_spans_seconds')}
  dst=E/f'evidence/marvis-{mode}-{side}.chrome.json.gz';src=Path(a['run'])/'timeline-report/trace.json.gz';out['traces'][mode+'_'+side]={'file':dst.name,'full_trace':str(src),**compact(src,dst,bin_ms=1)}
 assert pair['before']['runtime']['dynamorio']==pair['after']['runtime']['dynamorio']
 assert pair['before']['model']['iterations'][0]['control_count']==4332 and pair['after']['model']['iterations'][0]['control_count']==34
 assert not pair['before']['misses'] and not pair['after']['misses']
 assert sum(x['count']for x in pair['before']['launches'])-sum(x['count']for x in pair['after']['launches'])==16640
 pair['request_reduction_percent']=100*(1-pair['after']['means']['virtual_seconds']/pair['before']['means']['virtual_seconds']);out['gx'][mode]=pair
n=read(P/'native-summary.json');assert n['measured_output_checks']==28
for block in n['reports']:
 report=block['report'];g=out['gx']['mode2'][block['side']]['model'];assert report['versions']==g['versions']and report['source_sha256']==g['source_sha256']and report['kv_cache_source_sha256']==g['kv_cache_source_sha256'];assert report['plain']and report['runner_sha256']==sha(P/'runner.py');assert {x['output_sha256']for x in report['iterations']}=={n['output_sha256']}
for x in n['control_reports']:
 d=x['report'];assert {r['output_sha256']for r in d['warmups']+d['iterations']}=={n['output_sha256']}
out['native_A100']=n|{'hardware':read(P/'native-validation-hardware.json')}
with tempfile.TemporaryDirectory(prefix='marvis-patch-')as td:
 root=Path(td);shutil.copytree(P/'deps/torchtune',root/'torchtune',ignore=shutil.ignore_patterns('__pycache__'));subprocess.run(['git','apply',str(P/'host-positions.patch')],cwd=root,check=True);assert (root/'torchtune/modules/kv_cache.py').read_bytes()==(P/'deps-host/torchtune/modules/kv_cache.py').read_bytes()
out['patch_application_checked']=True
shutil.copyfile(P/'runner.py',E/'marvis_runner.py');shutil.copyfile(P/'host-positions.patch',E/'cpu_patches/marvis_host_positions.patch')
cat=read(P/'cat-after-audit.json');base=read(P/'host-before-audit.json');out['additional_screen']={'change':'Accumulate codebook sample tensors and concatenate once per frame, instead of each codebook iteration. Independent of selected host-counter candidate.','gx_audit':cat,'mean_seconds':statistics.mean(x['virtual_seconds']for x in cat['iterations']),'cpu_oracle':read(P/'deferred-cat-oracle.json'),'native_validation':False,'mode3_validation':False,'limitation':'64 prediction misses in the independent cat screen; no useful predicted gain, so not selected.'};out['additional_screen']['mode2_reduction_percent']=100*(1-out['additional_screen']['mean_seconds']/statistics.mean(x['virtual_seconds']for x in base['iterations']))
files=['pins.json','runner.py','runner-calibration.py','host-positions.patch','prepare_host_positions.py','selected.json','model-manifest.json','model-metadata.json','download_model.py','download_extras.py','controls.json','controls.npz','controls-host.json','removed-host-controls.json','emu.json','cpu.json','partial.json','host-before.json','host-after.json','sync-before.json','sync-after.json','audit.py','run_timing.py','run_initial.py','profile.sh','run_native_profile.py','stage_native.py','kernel-calibration.json','cpu-calibration.json','omissions.json','record_omissions.py','native-calibration-identities.json','native-validation-identities.json','native-profile-hardware.json','native-validation-hardware.json','run_native_validation.py','validate-native.sh','host_position_oracle.py','host-position-oracle.json','deferred-cat.patch','prepare_deferred_cat.py','deferred_cat_oracle.py','deferred-cat-oracle.json','cat-after.json','run_cat_screen.py','run_candidates.py','run_sync_pair.py','baseline-selection.json','native-model-release.json','package_results.py']
bundle=E/'evidence/marvis-reproduce.tar.gz'
with tarfile.open(bundle,'w:gz')as t:
 for name in files:t.add(P/name,arcname=name)
with tarfile.open(bundle,'r:gz')as t:
 assert sorted(t.getnames())==sorted(files)
 for name in files:assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==sha(P/name)
out['reproduction']={'file':bundle.name,'sha256':sha(bundle),'files':files,'note':'Install pinned source/dependencies, adjust paths, and apply host-positions.patch to a separate TorchTune0.6.1 copy. Enable tracking only after fresh cache allocation. Original kernel/CPU calibration runner retained; final runner adds opt-in flag/report metadata. Native plain timing restores tensor-control hooks.'}
dbdir=E/'evidence/kernel-databases';manifest=read(dbdir/'manifest.json');artifacts={}
for key,name,target in [('native_database','gpu.sqlite','marvis.sqlite.gz'),('native_report','kernel-profile.json','marvis.report.json.gz'),('cpu_instruction_calibration','cpu.db','marvis.cpu.db.gz')]:
 raw=(P/name).read_bytes();dst=dbdir/target;dst.write_bytes(gzip.compress(raw,compresslevel=9,mtime=0));assert gzip.decompress(dst.read_bytes())==raw;artifacts[key]={'file':target,'uncompressed_bytes':len(raw),'uncompressed_sha256':sha(P/name),'gzip_sha256':sha(dst)}
manifest['artifacts']['marvis']=artifacts;(dbdir/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');out['calibration']=artifacts
allpins=read(E/'pins.json');allpins['Marvis']=pins;(E/'pins.json').write_text(json.dumps(allpins,indent=2)+'\n');(E/'evidence/marvis-cpu.json').write_text(json.dumps(out,indent=2)+'\n')
print('MARVIS_PACKAGE_PASS',json.dumps({'gx':{m:x['request_reduction_percent']for m,x in out['gx'].items()},'native_median':out['native_A100']['median_reduction_percent'],'native_mean':out['native_A100']['mean_reduction_percent']}),flush=True)
