"""Quantify unmatched native launch medians; not an end-to-end correction."""
import collections,json,sqlite3,statistics
from pathlib import Path
P=Path(__file__).resolve().parent;d=json.loads((P/'partial-audit.json').read_text());count=len(d['iterations']);c=sqlite3.connect(f'file:{P}/gpu.sqlite?mode=ro',uri=True);c.row_factory=sqlite3.Row
samples=collections.defaultdict(list)
for r in c.execute('SELECT kernel_id,duration_ns FROM kernel_samples WHERE warmup=0 AND gate_timed_out=0'):samples[r['kernel_id']].append(r['duration_ns'])
medians={}
for r in c.execute('SELECT * FROM kernel_signatures'):
 k=(r['name'],*(r[f'{axis}_{dim}']for axis in ('grid','block')for dim in 'xyz'));medians.setdefault(k,[]).extend(samples[r['id']])
rows=[]
for r in d['kernel_inventory']['native_only']:
 k=(r['name'],*r['grid'],*r['block']);rows.append(r|{'count_per_request':r['count']/count,'isolated_median_ns':statistics.median(medians[k]),'isolated_seconds_per_request':statistics.median(medians[k])*r['count']/count/1e9})
out={'native_only':rows,'sum_isolated_medians_seconds_per_request':sum(r['isolated_seconds_per_request']for r in rows),'scope':'Measured baseline native-minus-GX launch inventory. Summed isolated kernel medians are not an end-to-end correction; host dispatch and synchronization omissions remain unquantified. Contains FP32 SGEMM and split-K reduction launches.'}
(P/'omissions.json').write_text(json.dumps(out,indent=2)+'\n');print('MARVIS_OMISSIONS',sum(x['count_per_request']for x in rows),out['sum_isolated_medians_seconds_per_request'])
