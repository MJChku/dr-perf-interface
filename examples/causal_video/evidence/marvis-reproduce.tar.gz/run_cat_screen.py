import json,subprocess,time
from pathlib import Path
P=Path(__file__).resolve().parent
for _ in range(1200):
 if (P/'host-after-audit.json').exists()and(P/'host-after-run.json').exists():break
 time.sleep(2)
else:raise RuntimeError('Host-position candidate timeout')
a=json.loads((P/'host-after-audit.json').read_text());assert a['result']['passed']and not a['result']['cleanup_errors'];assert json.loads((P/'deferred-cat-oracle.json').read_text())['passed']
for s in ('compress_completed.py','compress_workspace.py'):subprocess.run(['python3',str(P/s)],check=True)
subprocess.run(['python3',str(P/'run_timing.py'),'cat-after'],check=True)
