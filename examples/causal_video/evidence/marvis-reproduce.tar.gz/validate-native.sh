#!/usr/bin/env bash
set -euo pipefail
ulimit -c 0
marvis_selected=$1
marvis_selected_controls=$2
marvis_selected_arrays=$3
export LD_LIBRARY_PATH=/workspace/causal/f5-tts/deps/ffmpeg/lib:/workspace/causal/sglang/cuda13_libs:/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cudnn/lib
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONHASHSEED=0 TOKENIZERS_PARALLELISM=false HF_HUB_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1
export HF_HOME=/workspace/causal/hf-cache LOCAL_FILES_ONLY=true
export FLASHINFER_DISABLE_VERSION_CHECK=1 VLLM_USE_V1=1 VLLM_WORKER_MULTIPROC_METHOD=spawn VLLM_ATTENTION_BACKEND=FLASH_ATTN
export TORCHINDUCTOR_CACHE_DIR=/workspace/causal/marvis/cache-native/inductor
export TRITON_CACHE_DIR=/workspace/causal/marvis/cache-native/triton
export TORCHINDUCTOR_COMPILE_THREADS=2
unset LD_PRELOAD GX_PREDICT_DB GX_PROFILE_SO GX_PROFILE_START_FILE GX_PROFILE_STOP_FILE
marvis_index=0
for marvis_side in before after after before; do
 marvis_index=$((marvis_index+1))
 marvis_source=source
 [[ $marvis_side == before ]] || marvis_source=$marvis_selected
 marvis_extra=""
 marvis_flags=()
 if [[ $marvis_side == after ]]; then
  marvis_extra=/workspace/causal/marvis/deps-host:
  marvis_flags+=(--host-cache-positions)
 fi
 export PYTHONPATH=${marvis_extra}/workspace/causal/marvis/$marvis_source:/workspace/causal/marvis/deps:/workspace/causal/zipvoice/deps:/workspace/causal/soprano/deps:/workspace/causal/f5-tts/deps:/workspace/causal/qwen-tts/deps:/workspace/causal/qwen-tts/source:/workspace/causal/fastgen/deps:/workspace/causal/fastgen/source:/workspace/causal/omni/source:/workspace/causal/omni/extras:/workspace/causal/omni/deps:/workspace/causal/wan2gp/deps:/workspace/causal/wanwrapper/deps:/workspace/causal/sglang/cutlass:/workspace/causal/sglang/cutlass/nvidia_cutlass_dsl/dsl_packages:/workspace/causal/sglang/deps:/workspace/causal/sglang/kernel:/workspace/causal/sglang/source/python:/workspace/causal/deps:/workspace/causal/scope-deps:/workspace/causal/flashdreams-deps:/workspace/deps
 marvis_out=/workspace/causal/runs/marvis-plain-$marvis_index-$marvis_side
 [[ ! -e $marvis_out ]]
 timeout -k 20 900 python3 -u /workspace/causal/marvis/runner.py --model /workspace/causal/models/Marvis --output "$marvis_out" --role native --plain --warmup 3 --repetitions 7 "${marvis_flags[@]}" > "$marvis_out.log" 2>&1
 printf 'MARVIS_NATIVE_PROCESS_PASS %s %s\n' "$marvis_index" "$marvis_side"
done
for marvis_side in before after; do
 marvis_source=source
 marvis_controls=controls.json
 marvis_arrays=controls.npz
 if [[ $marvis_side == after ]]; then
  marvis_source=$marvis_selected
  marvis_controls=$marvis_selected_controls
  marvis_arrays=$marvis_selected_arrays
 fi
 marvis_extra=""
 marvis_flags=()
 if [[ $marvis_side == after ]]; then
  marvis_extra=/workspace/causal/marvis/deps-host:
  marvis_flags+=(--host-cache-positions)
 fi
 export PYTHONPATH=${marvis_extra}/workspace/causal/marvis/$marvis_source:/workspace/causal/marvis/deps:/workspace/causal/zipvoice/deps:/workspace/causal/soprano/deps:/workspace/causal/f5-tts/deps:/workspace/causal/qwen-tts/deps:/workspace/causal/qwen-tts/source:/workspace/causal/fastgen/deps:/workspace/causal/fastgen/source:/workspace/causal/omni/source:/workspace/causal/omni/extras:/workspace/causal/omni/deps:/workspace/causal/wan2gp/deps:/workspace/causal/wanwrapper/deps:/workspace/causal/sglang/cutlass:/workspace/causal/sglang/cutlass/nvidia_cutlass_dsl/dsl_packages:/workspace/causal/sglang/deps:/workspace/causal/sglang/kernel:/workspace/causal/sglang/source/python:/workspace/causal/deps:/workspace/causal/scope-deps:/workspace/causal/flashdreams-deps:/workspace/deps
 marvis_out=/workspace/causal/runs/marvis-control-$marvis_side
 [[ ! -e $marvis_out ]]
 timeout -k 20 900 python3 -u /workspace/causal/marvis/runner.py --model /workspace/causal/models/Marvis --output "$marvis_out" --role native --controls /workspace/causal/marvis/"$marvis_controls" --control-arrays /workspace/causal/marvis/"$marvis_arrays" --warmup 1 --repetitions 1 "${marvis_flags[@]}" > "$marvis_out.log" 2>&1
 printf 'MARVIS_NATIVE_CONTROL_PASS %s\n' "$marvis_side"
done
