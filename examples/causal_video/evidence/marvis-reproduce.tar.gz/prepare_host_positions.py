"""Optional eager-only CPU mirror for a cache's sequential position metadata."""
import difflib,json,shutil
from pathlib import Path
P=Path(__file__).resolve().parent;src=P/'deps/torchtune';dst=P/'deps-host/torchtune'
if not dst.exists():shutil.copytree(src,dst,ignore=shutil.ignore_patterns('__pycache__'))
f='modules/kv_cache.py';a=(src/f).read_text();b=a.replace('        self.batch_size = batch_size\n','''        self.batch_size = batch_size
        self._host_size = None

    def enable_host_position_tracking(self, *, initial_size: int) -> None:
        """Opt in for eager inference with exclusively owned cache state.

        The caller supplies a known current position (zero for a fresh cache).
        All subsequent mutations must use update/reset; direct cache_pos writes
        and torch.compile are unsupported while this mode is enabled. K/V data,
        GPU positions and reset behavior are retained.
        """
        if not isinstance(initial_size, int) or not 0 <= initial_size <= self.k_cache.shape[2]:
            raise ValueError("initial_size must be a known valid cache position")
        self._host_size = initial_size
''')
b=b.replace('        self.cache_pos -= self.size\n','''        self.cache_pos -= self.size
        if self._host_size is not None:
            self._host_size = 0
''').replace('        return self.cache_pos[0].item()\n','''        if self._host_size is not None:
            if torch.compiler.is_compiling():
                raise RuntimeError("host position tracking supports eager inference only")
            return self._host_size
        return self.cache_pos[0].item()
''').replace('        assert (self.cache_pos[0] + seq_len) <= self.k_cache.shape[2]\n','''        if self._host_size is not None:
            if torch.compiler.is_compiling():
                raise RuntimeError("host position tracking supports eager inference only")
            assert self._host_size + seq_len <= self.k_cache.shape[2]
        else:
            assert (self.cache_pos[0] + seq_len) <= self.k_cache.shape[2]
''').replace('        self.cache_pos.add_(seq_len)\n','''        self.cache_pos.add_(seq_len)
        if self._host_size is not None:
            self._host_size += seq_len
''')
assert b!=a;(dst/f).write_text(b);(P/'host-positions.patch').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/torchtune/'+f,tofile='b/torchtune/'+f)))
# Original calibrated control outcomes remain checked by the native guarded pair.
d=json.loads((P/'controls.json').read_text());removed=[]
for i,events in enumerate(d['requests']):
 skip=[x for x in events if x['tag'][1:3]in (['kv_cache.py','update'],['kv_cache.py','size'])];assert len(skip)==4298;assert all(x['value']is True for x in skip if x['tag'][0]=='__bool__');d['requests'][i]=[x for x in events if x not in skip];removed.append({'request':i,'removed':len(skip),'remaining':len(d['requests'][i])})
(P/'controls-host.json').write_text(json.dumps(d,indent=2)+'\n');(P/'removed-host-controls.json').write_text(json.dumps(removed,indent=2)+'\n')
