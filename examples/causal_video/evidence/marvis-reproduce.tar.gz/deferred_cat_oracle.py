import ast,copy,hashlib,json,os,types
from pathlib import Path
import torch
from torch import nn
P=Path(__file__).resolve().parent;methods=[]
for folder in ('source','source-cat'):
 tree=ast.parse((P/folder/'marvis_tts/models.py').read_text());cls=next(x for x in tree.body if isinstance(x,ast.ClassDef)and x.name=='Model');nodes=[x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name in ('_index_causal_mask','_multinomial_sample_one_no_sync','sample_topk')]+[x for x in cls.body if isinstance(x,ast.FunctionDef)and x.name in ('_embed_audio','_embed_tokens','generate_frame')]
 for n in nodes:n.decorator_list=[]
 ns={'torch':torch,'nn':nn};exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),folder,'exec'),ns);methods.append(ns)
class Transformer(nn.Module):
 def __init__(self):super().__init__();self.calls=[];self.resets=0
 def caches_are_enabled(self):return True
 def reset_caches(self):self.resets+=1
 def forward(self,x,**kw):self.calls.append((x.detach().clone(),{k:v.clone()for k,v in kw.items()}));return x.tanh()
class Toy(nn.Module):
 def __init__(self,codebooks):
  super().__init__();h,v=8,11;self.args=types.SimpleNamespace(audio_num_codebooks=codebooks,audio_vocab_size=v);self.audio_head=nn.Parameter(torch.randn(codebooks-1,h,v));self.backbone=Transformer();self.decoder=Transformer();self.text_embeddings=nn.Embedding(v,h);self.audio_embeddings=nn.Embedding(v*codebooks,h);self.projection=nn.Linear(h,h);self.codebook0_head=nn.Linear(h,v);self.backbone_causal_mask=torch.tril(torch.ones(64,64,dtype=torch.bool));self.decoder_causal_mask=torch.tril(torch.ones(codebooks,codebooks,dtype=torch.bool))
count=0;calls=0;torch.set_num_threads(1)
with torch.inference_mode():
 for dtype in (torch.float32,torch.bfloat16):
  for batch in (1,2):
   for length in (1,5):
    for codebooks in (2,8,32):
     for seed in (0,42,123):
      torch.manual_seed(seed);original=Toy(codebooks).to(dtype=dtype);models=[original,copy.deepcopy(original)];tokens=torch.randint(0,11,(batch,length,codebooks+1));mask=torch.rand(batch,length,codebooks+1)>.3;positions=torch.arange(length)[None].repeat(batch,1);out=[]
      for model,ns in zip(models,methods):
       model._embed_audio=types.MethodType(ns['_embed_audio'],model);model._embed_tokens=types.MethodType(ns['_embed_tokens'],model);torch.manual_seed(seed);out.append(ns['generate_frame'](model,tokens,mask,positions,.9,5))
      assert torch.equal(*out)and out[0].shape==(batch,codebooks)
      for name in ('backbone','decoder'):
       a,b=[getattr(m,name)for m in models];assert a.resets==b.resets and len(a.calls)==len(b.calls)
       for (x,kw),(y,kv)in zip(a.calls,b.calls):assert torch.equal(x,y)and all(torch.equal(kw[k],kv[k])for k in kw);calls+=1
      count+=1
out={'passed':True,'cases':count,'identical_model_calls':calls,'scope':'Actual original/patched generate_frame and embedding/sampling helpers with deterministic toy transformer modules. Same seeded tokens and every transformer input/mask/position agree across varied batches,prefill lengths,codebook counts andfloat32/bfloat16. Not full-model validation.','patch_sha256':hashlib.sha256((P/'deferred-cat.patch').read_bytes()).hexdigest()};Path(os.environ.get('ORACLE_OUTPUT',str(P/'deferred-cat-oracle.json'))).write_text(json.dumps(out,indent=2)+'\n');print('MARVIS_CAT_ORACLE_PASS',json.dumps(out),flush=True)
