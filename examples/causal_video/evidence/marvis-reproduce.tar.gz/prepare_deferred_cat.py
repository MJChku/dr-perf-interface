import difflib,shutil,json
from pathlib import Path
P=Path(__file__).resolve().parent;src=P/'source';dst=P/'source-cat'
if not dst.exists():shutil.copytree(src,dst,ignore=shutil.ignore_patterns('.git','__pycache__'))
f='marvis_tts/models.py';a=(src/f).read_text();b=a.replace('        curr_sample = c0_sample.clone()\n','        codebook_samples = [c0_sample]\n').replace('            curr_sample = torch.cat([curr_sample, ci_sample], dim=1)\n','            codebook_samples.append(ci_sample)\n').replace('        return curr_sample\n','        return torch.cat(codebook_samples, dim=1)\n');assert b!=a;assert a.count('        return curr_sample\n')==1;(dst/f).write_text(b);(P/'deferred-cat.patch').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+f,tofile='b/'+f)))
c=json.loads((P/'partial.json').read_text());c['name']='marvis-cat';c['files']['source']=str(dst);(P/'cat-after.json').write_text(json.dumps(c,indent=2)+'\n')
