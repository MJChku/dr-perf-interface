"""Collect one continuous steady CPU window, then run the mode2 baseline."""
import hashlib,json,os,re,subprocess,time
from pathlib import Path
P=Path(__file__).resolve().parent;GX=Path('/home/ubuntu/GX/NEX')
start=time.monotonic()
with (P/'cpu.log').open('w')as log:
 done=subprocess.run(['python3',str(P.parent/'inferix-kv-14b-timing/run_on_worker.py'),str(P/'cpu.json')],cwd=GX,env=os.environ|{'SSH_BASE_PORT':'2282'},stdout=log,stderr=subprocess.STDOUT)
paths=re.findall(r'(?:result|logs)=(/[^\s]+)',(P/'cpu.log').read_text());assert paths
run=Path(paths[-1]);run=run.parent if run.name=='result.json'else run
result=json.loads((run/'result.json').read_text());assert done.returncode==0 and result['passed'] and not result['cleanup_errors'],result
model=json.loads((run/'host-0/model/report.json').read_text());native=json.loads((P/'kernel-profile.json').read_text());assert model['versions']==native['versions'] and model['source_sha256']==native['source_sha256'];assert len(model['warmups'])==3 and len(model['iterations'])==6
files=list((run/'host-0/d0').glob('profile-*.db'));assert len(files)==1,files
raw=files[0].read_bytes();assert raw.startswith(b'GXVM_NATIVE_IPS_V1');(P/'cpu.db').write_bytes(raw)
record={'run':str(run),'result':result,'model':model,'header':raw.decode().splitlines()[0],'sha256':hashlib.sha256(raw).hexdigest(),'controller_wall_seconds':time.monotonic()-start,'scope':'Three warmups, six requests in one continuous instruction-profile window. Original F5-TTS public API with fixed STFT shape adapters with calibrated GPU predictions enabled; recorded scalar controls, original scalar transfers retained.'}
(P/'cpu-calibration.json').write_text(json.dumps(record,indent=2)+'\n');print('F5_CPU_PROFILE_PASS',record['header'],flush=True)
subprocess.run(['python3',str(P/'run_timing.py'),'partial'],check=True)
