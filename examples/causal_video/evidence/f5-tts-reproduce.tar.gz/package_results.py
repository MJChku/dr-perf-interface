"""Record simulation and native measurements separately, with compact traces."""
import gzip,hashlib,json,shutil,statistics,subprocess,sys,tarfile,tempfile
from pathlib import Path
P=Path(__file__).resolve().parent;E=P.parents[2]/'examples/causal_video';sys.path.insert(0,str(E))
from compact_gx_trace import compact
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins={'source':{'remote':'https://github.com/SWivid/F5-TTS.git','commit':subprocess.check_output(['git','-C',str(P/'source'),'rev-parse','HEAD'],text=True).strip()},'model':read(P/'model-manifest.json'),'dependencies':read(P/'kernel-profile.json')['versions'],'workload':read(P/'kernel-profile.json')['request'],'scope':read(P/'kernel-profile.json')['scope']};(P/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
limitations=[
 'One short English request, supplied reference transcript, seed42, resident FP16 F5TTS_v1_Base and FP32 Vocos;32 Euler steps. Not a throughput or all-prompt study.',
 'GX omits GPU arithmetic. Recorded scalar and CPU-array values follow original transfers. F.pad and randn shape adapters use recorded concrete sizes after original GPU scalar reads; native guarded runs verify actual shapes. Native unhooked timing restores all adapters.',
 'GX-only STFT/ISTFT shape adapters were introduced based on prior cuFFT runtime failures in other systems; original FFT was not separately tested under GX for F5-TTS. FFT-related work and host dispatch are omitted. Baseline native-only21launches have isolated median sum0.175605ms/request, not an end-to-end correction. No selected GPU prediction misses.',
 'CPU calibration188unresolved of6058instruction samples(3.103%),11unresolved task samples. GX and native CPU hosts differ; GX absolute times overpredict native. This is not a matched-host accuracy study.',
 'Mode2 primary comparison uses one measured request per capture because the original API creates a fresh worker each request and partial per-thread clocks do not directly synchronize. The initial two-request diagnostic is retained. Mode3 uses caller request intervals across two requests with10us epochs. Worker/caller intervals must not be averaged together.',
 'Native ABBA has3warmups and7measured requests per process;14samples/variant,all retained. Candidate process medians differ (roughly0.572 and0.594s); report pooled mean and median plus all samples.',
 'Solver-only ablation had0.302%mode2 gain and no independent native validation. Selected comparison combines that specialization with request-scoped rotary trigonometric reuse. Gains include reduced GPU work as well as CPU dispatch.',
]
out={'system':'F5-TTS','pins':pins,'change':'Specialize fixed-grid linear interpolation when requested times are the integration grid, and reuse rotary frequencies/sin/cos within an inference request using the existing thread-local cache.','gx':{},'traces':{},'limitations':limitations,'native_kernel_calibration':read(P/'kernel-profile.json'),'kernel_calibration':read(P/'kernel-calibration.json'),'cpu_calibration':read(P/'cpu-calibration.json'),'omissions':read(P/'omissions.json'),'cpu_oracles':{'solver':read(P/'solver-oracle.json'),'rotary':read(P/'rotary-oracle.json')},'additional_screen':{'change':'Solver-only','before':read(P/'single-before-audit.json'),'after':read(P/'single-after-audit.json'),'scope':'GXmode2only,0.302%modeled gain. No standalone native validation.'},'partial_thread_clock_diagnostic':read(P/'partial-audit.json')}
for mode,names in [('mode2',('single-before','rotary-after')),('mode3',('sync-before','sync-after'))]:
 pair={}
 for side,name in zip(('before','after'),names):
  a=read(P/(name+'-audit.json'));assert a['result']['passed']and not a['result']['cleanup_errors'];assert a['model']['runner_sha256']==sha(P/'runner.py');assert a['gpu_db_sha256']==sha(P/'gpu.sqlite')and a['cpu_db_sha256']==sha(P/'cpu.db')
  pair[side]=a|{'runtime':read(Path(a['run'])/'runtime.json'),'controller_wall_seconds':read(P/(name+'-run.json'))['controller_wall_seconds']};selected=[x for x in a['iterations'] if (x['iteration']<1000 if mode=='mode2' else x['iteration']>=1000)];pair[side]['request_interval_selection']='worker' if mode=='mode2' else 'caller';pair[side]['means']={k:statistics.mean(x[k]for x in selected)for k in ('virtual_seconds','cpu_seconds','gpu_span_seconds','outside_gpu_spans_seconds')};pair[side]['worker_cpu_seconds']=statistics.mean(x['cpu_seconds']for x in a['iterations']if x['iteration']<1000)
  dst=E/f'evidence/f5-tts-{mode}-{side}.chrome.json.gz';src=Path(a['run'])/'timeline-report/trace.json.gz';out['traces'][mode+'_'+side]={'file':dst.name,'full_trace':str(src),**compact(src,dst,bin_ms=1)}
 assert pair['before']['runtime']['dynamorio']==pair['after']['runtime']['dynamorio']
 assert pair['before']['model']['iterations'][0]['control_count']==140 and pair['after']['model']['iterations'][0]['control_count']==13
 pair['request_reduction_percent']=100*(1-pair['after']['means']['virtual_seconds']/pair['before']['means']['virtual_seconds']);out['gx'][mode]=pair
for key,name,nexpected in [('native_A100','native-summary.json',28)]:
 n=read(P/name);assert n['measured_output_checks']==nexpected
 for block in n['reports']:
  report=block['report'];g=out['gx']['mode2'][block['side']]['model'];assert report['versions']==g['versions']and report['source_sha256']==g['source_sha256']and report['solver_source_sha256']==g['solver_source_sha256'];assert report['plain']and report['runner_sha256']==sha(P/'runner.py');assert {x['output_sha256']for x in report['iterations']}=={n['output_sha256']}
 for x in n['control_reports']:
  d=x['report'];assert all(e['native_shape_checked']for e in d['fft_adapters']+d['shape_adapters']);assert {r['output_sha256']for r in d['warmups']+d['iterations']}=={n['output_sha256']}
 out[key]=n|{'hardware':read(P/'native-validation-hardware.json')}
with tempfile.TemporaryDirectory(prefix='f5-patch-')as td:
 root=Path(td);shutil.copytree(P/'source',root/'source',ignore=shutil.ignore_patterns('.git','__pycache__'))
 subprocess.run(['git','apply',str(P/'rotary-cache.patch')],cwd=root/'source',check=True)
 for rel in ['src/f5_tts/model/modules.py','src/f5_tts/model/backbones/dit.py']:assert (root/'source'/rel).read_bytes()==(P/'source-rope'/rel).read_bytes()
 shutil.copytree(P/'deps/torchdiffeq',root/'torchdiffeq',ignore=shutil.ignore_patterns('__pycache__'))
 subprocess.run(['git','apply',str(P/'fixed-grid.patch')],cwd=root,check=True)
 assert (root/'torchdiffeq/_impl/solvers.py').read_bytes()==(P/'solver-optimized/torchdiffeq/_impl/solvers.py').read_bytes()
out['patch_application_checked']=True
shutil.copyfile(P/'runner.py',E/'f5_tts_runner.py')
for src,dst in [('rotary-cache.patch','f5_tts_rotary_cache.patch'),('fixed-grid.patch','torchdiffeq_fixed_grid.patch')]:shutil.copyfile(P/src,E/'cpu_patches'/dst)
files=['pins.json','runner.py','runner-calibration.py','runner-controls.py','rotary-cache.patch','fixed-grid.patch','prepare_rotary.py','prepare_solver.py','model-manifest.json','model-metadata.json','download_model.py','controls.json','controls-calibration.json','controls-calibration.npz','controls-optimized.json','controls.npz','removed-controls.json','emu-shape.json','cpu.json','partial.json','single-before.json','single-after.json','rotary-after.json','sync-before.json','sync-after.json','audit.py','run_timing.py','run_cpu.py','profile.sh','profile-control.sh','run_native_profile.py','run_control_calibration.py','stage_native.py','kernel-calibration.json','cpu-calibration.json','control-calibration.json','omissions.json','native-calibration-identities.json','native-control-identities.json','native-validation-identities.json','native-profile-hardware.json','native-control-hardware.json','native-validation-hardware.json','run_native_validation.py','validate-native.sh','solver_oracle.py','solver-oracle.json','rotary_oracle.py','rotary-oracle.json','build_ffmpeg.py','ffmpeg-build.json','package_results.py']
bundle=E/'evidence/f5-tts-reproduce.tar.gz'
with tarfile.open(bundle,'w:gz')as t:
 for name in files:t.add(P/name,arcname=name)
with tarfile.open(bundle,'r:gz')as t:
 assert sorted(t.getnames())==sorted(files)
 for name in files:assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==sha(P/name)
out['reproduction']={'file':bundle.name,'sha256':sha(bundle),'files':files,'note':'Install pinned source/dependencies and adjust host/file paths. Original native calibration uses runner-calibration.py; additional initial shape/control calibration uses runner-controls.py. Final selected runner.py prioritizes source-rope/src and solver-optimized for after; both patches apply independently. Filtered solver tape retains original array keys. Native plain timing requires no tape.'}
dbdir=E/'evidence/kernel-databases';manifest=read(dbdir/'manifest.json');artifacts={}
for key,name,target in [('native_database','gpu.sqlite','f5-tts.sqlite.gz'),('native_report','kernel-profile.json','f5-tts.report.json.gz'),('cpu_instruction_calibration','cpu.db','f5-tts.cpu.db.gz')]:
 raw=(P/name).read_bytes();dst=dbdir/target;dst.write_bytes(gzip.compress(raw,compresslevel=9,mtime=0));assert gzip.decompress(dst.read_bytes())==raw;artifacts[key]={'file':target,'uncompressed_bytes':len(raw),'uncompressed_sha256':sha(P/name),'gzip_sha256':sha(dst)}
manifest['artifacts']['f5-tts']=artifacts;(dbdir/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');out['calibration']=artifacts
allpins=read(E/'pins.json');allpins['F5-TTS']=pins;(E/'pins.json').write_text(json.dumps(allpins,indent=2)+'\n');(E/'evidence/f5-tts-cpu.json').write_text(json.dumps(out,indent=2)+'\n')
print('F5_PACKAGE_PASS',json.dumps({'gx':{m:x['request_reduction_percent']for m,x in out['gx'].items()},'native_median':out['native_A100']['median_reduction_percent'],'native_mean':out['native_A100']['mean_reduction_percent']}),flush=True)
