"""Exercise the exact patched helper across dtypes, sequence slicing and XPos scales."""
import ast,hashlib,json,sys
from pathlib import Path
import torch
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P/'deps'))
from x_transformers.x_transformers import apply_rotary_pos_emb as original,rotate_half
source=(P/'source-rope/src/f5_tts/model/modules.py').read_text();node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)and n.name=='apply_rotary_pos_emb');scope={'torch':torch,'_apply_rotary_pos_emb':original,'rotate_half':rotate_half};exec(compile(ast.Module(body=[node],type_ignores=[]),'<exact-patched-rotary-helper>','exec'),scope);patched=scope['apply_rotary_pos_emb']
torch.set_num_threads(1);torch.manual_seed(42);rows=[]
for dtype in (torch.float32,torch.float16,torch.bfloat16):
 for rank in (3,4):
  for seq in (1,7,23):
   for rot_dim in (8,16):
    for tensor_scale in (False,True):
     shape=(2,seq,16)if rank==3 else(2,3,seq,16)
     x=torch.randn(shape,dtype=dtype);freqs=torch.randn(1,29,rot_dim,dtype=dtype);scale=torch.rand(1,29,rot_dim,dtype=dtype)+.5 if tensor_scale else 1.0
     ref=original(x,freqs,scale);got=patched(x,freqs,scale,(freqs.cos(),freqs.sin()));fallback=patched(x,freqs,scale)
     assert torch.equal(ref,got)and torch.equal(ref,fallback),(dtype,rank,seq,rot_dim,tensor_scale)
     rows.append([str(dtype),rank,seq,rot_dim,tensor_scale])
# Gradient path remains exactly the original function when precomputed=None.
x=torch.randn(2,3,7,16,requires_grad=True);freq=torch.randn(1,7,16,requires_grad=True)
a=original(x,freq);ga=torch.autograd.grad(a.square().sum(),(x,freq));b=patched(x,freq);gb=torch.autograd.grad(b.square().sum(),(x,freq));assert torch.equal(a,b)and all(torch.equal(u,v)for u,v in zip(ga,gb))
(P/'rotary-oracle.json').write_text(json.dumps({'torch':torch.__version__,'exact':True,'cases':rows,'gradient_fallback_exact':True,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'scope':'Exact patched helper CPU equivalence only; native full-model outputs and request cache lifecycle still need validation.'},indent=2)+'\n');print('F5_ROTARY_ORACLE_PASS',len(rows),flush=True)
