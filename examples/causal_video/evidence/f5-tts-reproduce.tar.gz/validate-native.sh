#!/usr/bin/env bash
set -euo pipefail
ulimit -c 0
export LD_LIBRARY_PATH=/workspace/causal/f5-tts/deps/ffmpeg/lib:/workspace/causal/sglang/cuda13_libs:/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cudnn/lib
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONHASHSEED=0 TOKENIZERS_PARALLELISM=false HF_HUB_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1
export HF_HOME=/workspace/causal/hf-cache LOCAL_FILES_ONLY=true
export FLASHINFER_DISABLE_VERSION_CHECK=1
unset LD_PRELOAD GX_PREDICT_DB GX_PROFILE_SO GX_PROFILE_START_FILE GX_PROFILE_STOP_FILE
f5_index=0
for f5_side in before after after before; do
 f5_index=$((f5_index+1))
 f5_source=source
 [[ $f5_side == before ]] || f5_source=source-rope
 f5_solver=/workspace/causal/f5-tts/deps
 [[ $f5_side == before ]] || f5_solver=/workspace/causal/f5-tts/solver-optimized
 export PYTHONPATH=$f5_solver:/workspace/causal/f5-tts/$f5_source/src:/workspace/causal/f5-tts/deps:/workspace/causal/qwen-tts/deps:/workspace/causal/fastgen/deps:/workspace/causal/omni/extras:/workspace/causal/omni/deps:/workspace/causal/wan2gp/deps:/workspace/causal/wanwrapper/deps:/workspace/causal/sglang/deps:/workspace/causal/deps:/workspace/causal/scope-deps:/workspace/causal/flashdreams-deps:/workspace/deps
 f5_out=/workspace/causal/runs/f5-tts-plain-$f5_index-$f5_side
 [[ ! -e $f5_out ]]
 timeout -k 20 900 python3 -u /workspace/causal/f5-tts/runner.py --model /workspace/causal/models/F5-TTS --output "$f5_out" --role native --plain --warmup 3 --repetitions 7 > "$f5_out.log" 2>&1
 printf 'F5_NATIVE_PROCESS_PASS %s %s\n' "$f5_index" "$f5_side"
done
# One additional pair checks original native scalar/CPU-array controls and
# STFT shape formulas. These guarded runs do not enter latency statistics.
for f5_side in before after; do
 f5_controls=controls.json
 [[ $f5_side == before ]] || f5_controls=controls-optimized.json
 f5_source=source
 [[ $f5_side == before ]] || f5_source=source-rope
 f5_solver=/workspace/causal/f5-tts/deps
 [[ $f5_side == before ]] || f5_solver=/workspace/causal/f5-tts/solver-optimized
 export PYTHONPATH=$f5_solver:/workspace/causal/f5-tts/$f5_source/src:/workspace/causal/f5-tts/deps:/workspace/causal/qwen-tts/deps:/workspace/causal/fastgen/deps:/workspace/causal/omni/extras:/workspace/causal/omni/deps:/workspace/causal/wan2gp/deps:/workspace/causal/wanwrapper/deps:/workspace/causal/sglang/deps:/workspace/causal/deps:/workspace/causal/scope-deps:/workspace/causal/flashdreams-deps:/workspace/deps
 f5_out=/workspace/causal/runs/f5-tts-control-$f5_side
 [[ ! -e $f5_out ]]
 timeout -k 20 900 python3 -u /workspace/causal/f5-tts/runner.py --model /workspace/causal/models/F5-TTS --output "$f5_out" --role native --controls /workspace/causal/f5-tts/"$f5_controls" --control-arrays /workspace/causal/f5-tts/controls.npz --warmup 1 --repetitions 1 > "$f5_out.log" 2>&1
 printf 'F5_NATIVE_CONTROL_PASS %s\n' "$f5_side"
done
