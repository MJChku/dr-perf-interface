"""Check trajectories, gradients, callback behavior and fallback modes on CPU."""
import json,os,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent
code='''import hashlib,json,torch
from torchdiffeq import odeint
torch.set_num_threads(1);torch.manual_seed(42)
def digest(x):return hashlib.sha256(x.detach().numpy().tobytes()).hexdigest()
rows=[]
for dtype in (torch.float32,torch.float64):
 for method in ('euler','midpoint','rk4'):
  for count in (1,3,9):
   for reverse in (False,True):
    for mode in ('default','step','cubic'):
     class Func(torch.nn.Module):
      def __init__(self):super().__init__();self.a=torch.nn.Parameter(torch.tensor(.05,dtype=dtype));self.calls=0;self.callbacks=[]
      def forward(self,t,y):self.calls+=1;return self.a*y+torch.sin(t)
      def callback_step(self,t,y,dt):self.callbacks.append([float(t),float(dt)])
     f=Func();y=torch.tensor([[.1,.2],[.3,.4]],dtype=dtype,requires_grad=True);t=torch.linspace(0,1,count,dtype=dtype)
     if reverse:t=t.flip(0)
     options={}if mode=='default'else {'step_size':.125}if mode=='step'else {'interp':'cubic'}
     out=odeint(f,y,t,method=method,options=options);out.square().sum().backward()
     rows.append({'case':[str(dtype),method,count,reverse,mode],'out':digest(out),'y_grad':digest(y.grad),'a_grad':digest(f.a.grad)if f.a.grad is not None else None,'calls':f.calls,'callbacks':f.callbacks})
print(json.dumps({'torch':torch.__version__,'cases':rows}))
'''
rows={}
for side in ['before','after']:
 paths=([P/'solver-optimized']if side=='after'else[])+[P/'deps']
 r=subprocess.run([sys.executable,'-c',code],env=os.environ|{'PYTHONPATH':':'.join(map(str,paths))},text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert r.returncode==0,r.stderr;rows[side]=json.loads(r.stdout)
assert rows['before']==rows['after']
(P/'solver-oracle.json').write_text(json.dumps({'exact':True,'cases':rows['before'],'scope':'CPU primitive trajectory/gradient/callback equivalence; whole-model native validation remains necessary.'},indent=2)+'\n');print('F5_SOLVER_ORACLE_PASS',len(rows['before']['cases']))
