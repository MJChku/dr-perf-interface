"""Cache request-invariant rotary trigonometric tensors in the existing thread cache."""
from pathlib import Path
import difflib,json,shutil
P=Path(__file__).resolve().parent;src=P/'source';dst=P/'source-rope';assert not dst.exists();shutil.copytree(src,dst,ignore=shutil.ignore_patterns('.git','__pycache__','build','*.egg-info'))
f=dst/'src/f5_tts/model/modules.py';old=f.read_text();new=old.replace('from x_transformers.x_transformers import apply_rotary_pos_emb','from x_transformers.x_transformers import apply_rotary_pos_emb as _apply_rotary_pos_emb, rotate_half')
needle='# raw wav to mel spec\n';helper='''def apply_rotary_pos_emb(t, freqs, scale=1, precomputed=None):
    if precomputed is None:
        return _apply_rotary_pos_emb(t, freqs, scale)
    # Match x-transformers' operation order and dtype, reusing only sin/cos.
    with torch.autocast(device_type="cuda", enabled=False):
        cos, sin = precomputed
        rot_dim, seq_len, orig_dtype = freqs.shape[-1], t.shape[-2], t.dtype
        cos, sin = cos[:, -seq_len:, :], sin[:, -seq_len:, :]
        scale = scale[:, -seq_len:, :] if isinstance(scale, torch.Tensor) else scale
        if t.ndim == 4 and cos.ndim == 3:
            cos, sin = cos.unsqueeze(1), sin.unsqueeze(1)
        t, t_unrotated = t[..., :rot_dim], t[..., rot_dim:]
        t = (t * cos * scale) + (rotate_half(t) * sin * scale)
        return torch.cat((t, t_unrotated), dim=-1).type(orig_dtype)


''';assert needle in new;new=new.replace(needle,helper+needle)
start=new.index('class AttnProcessor:');end=new.index('class JointAttnProcessor:',start);block=new[start:end]
assert block.count('freqs, xpos_scale = rope')==1
block=block.replace('freqs, xpos_scale = rope','freqs, xpos_scale = rope[:2]\n            precomputed = rope[2] if len(rope) == 3 else None')
for ending in ['freqs, q_xpos_scale)','freqs, k_xpos_scale)']:block=block.replace(ending,ending[:-1]+', precomputed)')
new=new[:start]+block+new[end:];f.write_text(new)
f=dst/'src/f5_tts/model/backbones/dit.py';old=f.read_text();new=old.replace('        self.text_cond, self.text_uncond = None, None','        self.text_cond, self.text_uncond = None, None\n        self._get_cache_local().rotary = None')
needle='        rope = self.rotary_embed.forward_from_seq_len(seq_len)';replacement='''        if cache and not torch.is_grad_enabled():
            # Sequence geometry is fixed within a sampling request. Keep this
            # beside the existing per-thread text cache, cleared by clear_cache.
            local = self._get_cache_local()
            inv_freq = self.rotary_embed.inv_freq
            key = (seq_len, inv_freq.device, inv_freq.dtype)
            cached = getattr(local, "rotary", None)
            if cached is None or cached[0] != key:
                freqs, scale = self.rotary_embed.forward_from_seq_len(seq_len)
                with torch.autocast(device_type="cuda", enabled=False):
                    rope = (freqs, scale, (freqs.cos(), freqs.sin()))
                local.rotary = (key, rope)
            else:
                rope = cached[1]
        else:
            rope = self.rotary_embed.forward_from_seq_len(seq_len)''';assert new.count(needle)==1;f.write_text(new.replace(needle,replacement))
patch=[]
for rel in ['src/f5_tts/model/modules.py','src/f5_tts/model/backbones/dit.py']:
 old=(src/rel).read_text();new=(dst/rel).read_text();patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(P/'rotary-cache.patch').write_text(''.join(patch));x=json.loads((P/'single-after.json').read_text());x['name']='f5-rotary';x['files']['source']=str(dst);(P/'rotary-after.json').write_text(json.dumps(x,indent=2)+'\n');print('F5_ROTARY_CANDIDATE_PREPARED')
