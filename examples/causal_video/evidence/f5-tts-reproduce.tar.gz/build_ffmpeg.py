"""Minimal shared FFmpeg for TorchCodec PCM-WAV input; no Torch changes."""
import hashlib,json,shutil,subprocess,tarfile,tempfile,urllib.request
from pathlib import Path
P=Path(__file__).resolve().parent;prefix=P/'deps/ffmpeg';url='https://ffmpeg.org/releases/ffmpeg-7.1.1.tar.xz'
with tempfile.TemporaryDirectory(prefix='f5-ffmpeg-')as td:
 root=Path(td);archive=root/'source.tar.xz'
 with urllib.request.urlopen(url,timeout=120)as inp,archive.open('wb')as out:shutil.copyfileobj(inp,out)
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 with tarfile.open(archive)as t:t.extractall(root,filter='data')
 src=root/'ffmpeg-7.1.1';args=['./configure','--prefix='+str(prefix),'--disable-programs','--disable-doc','--disable-debug','--disable-autodetect','--enable-shared','--disable-static','--disable-everything','--enable-protocol=file','--enable-demuxer=wav','--enable-decoder=pcm_s16le,pcm_s24le,pcm_s32le,pcm_f32le,pcm_f64le','--enable-muxer=wav','--enable-encoder=pcm_s16le','--enable-filter=aresample','--disable-x86asm']
 subprocess.run(args,cwd=src,check=True);subprocess.run(['nice','-n','10','make','-j12'],cwd=src,check=True);subprocess.run(['make','install'],cwd=src,check=True)
 rows={str(f.relative_to(prefix)):hashlib.sha256(f.read_bytes()).hexdigest()for f in prefix.rglob('*')if f.is_file()}
(P/'ffmpeg-build.json').write_text(json.dumps({'url':url,'archive_sha256':digest,'configure':args,'files_sha256':rows,'scope':'Minimal original FFmpeg7.1.1 shared libraries supporting PCM WAV decode. No GPU/video codec support requested.'},indent=2)+'\n')
print('F5_FFMPEG_BUILD_PASS',flush=True)
