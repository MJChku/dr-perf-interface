"""Initial kernel and GPU-dependent control calibration; GPU1 only, if idle."""
import hashlib,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[2]
load=Path('/home/ubuntu/GX/NEX/build/experiments/f5-load4-1789832477105627508')
result=json.loads((load/'result.json').read_text());assert result['passed'] and not result['cleanup_errors']
assert any('F5_LOAD_PASS' in f.read_text()for f in (load/'host-0').glob('*.log'))
ssh=['ssh','-o','ConnectTimeout=10','-o','ConnectionAttempts=3','jcm@A100']
import shlex
checks=json.loads((P/'native-calibration-identities.json').read_text());base='/home/jcm/drperf-wan-a100-20260916/causal/f5-tts'
for name in ('runner.py','profile-control.sh'):
 subprocess.run(['rsync','-az',str(P/name),'jcm@A100:'+base+'/'+name],check=True);checks[base+'/'+name]=hashlib.sha256((P/name).read_bytes()).hexdigest()
script="import hashlib,json\nfor name,expected in json.loads(%r).items():\n with open(name,'rb')as f:assert hashlib.file_digest(f,'sha256').hexdigest()==expected,name\nprint('F5_CONTROL_IDENTITIES_PASS')\n"%json.dumps(checks)
subprocess.run(ssh+['python3 -'],input=script,text=True,check=True);(P/'native-control-identities.json').write_text(json.dumps(checks,indent=2)+'\n')
active=subprocess.check_output(ssh+['nvidia-smi --query-compute-apps=gpu_uuid,pid --format=csv,noheader'],text=True)
assert 'GPU-521def15-8599-2c15-65ee-6dac40f31a64' not in active,active
hardware={'gpu_inventory':subprocess.check_output(ssh+['nvidia-smi --query-gpu=index,name,uuid,driver_version,memory.total --format=csv'],text=True),'active_compute_processes':active,'device_requests':json.loads(subprocess.check_output(ssh+['docker inspect --format "{{json .HostConfig.DeviceRequests}}" drperf-wan-native-0'],text=True))}
assert hardware['device_requests'][0]['DeviceIDs']==['1'];(P/'native-control-hardware.json').write_text(json.dumps(hardware,indent=2)+'\n')
helper=R/'examples/wan_gx/native_container.py'
try:
 subprocess.run(['python3',str(helper),'resume'],check=True)
 subprocess.run(ssh+['docker exec -u jma drperf-wan-native-0 bash /workspace/causal/f5-tts/profile-control.sh'],check=True)
 rsync=['rsync','-az','-e','ssh -o ConnectTimeout=10 -o ConnectionAttempts=3']
 remote='jcm@A100:/home/jcm/drperf-wan-a100-20260916/causal/runs/f5-tts-controls'
 for filename,target in [('report.json','control-calibration.json'),('controls.json','controls.json'),('controls.npz','controls.npz')]:
  subprocess.run(rsync+[remote+'/'+filename,str(P/target)],check=True)
 d=json.loads((P/'control-calibration.json').read_text());n=json.loads((P/'kernel-profile.json').read_text());assert d['versions']==n['versions']and d['source_sha256']==n['source_sha256'];assert {x['output_sha256']for x in d['warmups']+d['iterations']}=={n['iterations'][0]['output_sha256']};assert all(x['native_shape_checked']for x in d['shape_adapters'])
 print('F5_NATIVE_PROFILE_PASS',flush=True)
finally:subprocess.run(['python3',str(helper),'stop'],check=True)
