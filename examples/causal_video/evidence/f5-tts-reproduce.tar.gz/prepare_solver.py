"""Avoid interpolation queries when requested output times are the integration grid."""
from pathlib import Path
import difflib,json,shutil
P=Path(__file__).resolve().parent;src=P/'deps/torchdiffeq';dst=P/'solver-optimized/torchdiffeq';assert not dst.exists();shutil.copytree(src,dst,ignore=shutil.ignore_patterns('__pycache__'))
f=dst/'_impl/solvers.py';old=f.read_text();start=old.index('            while j < len(t) and t1 >= t[j]:');end=old.index('            y0 = y1',start);block=old[start:end]
replacement='''            # The default fixed grid is exactly the requested output times.
            # With linear interpolation each step already produces that output.
            # Preserve endpoint validation, step callbacks, and other grids/modes.
            if time_grid is t and self.interp == "linear":
                solution[j] = y1
                j += 1
            else:
'''+''.join('    '+line if line.strip()else line for line in block.splitlines(True))
new=old[:start]+replacement+old[end:];f.write_text(new);(P/'fixed-grid.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/torchdiffeq/_impl/solvers.py',tofile='b/torchdiffeq/_impl/solvers.py')))
x=json.loads((P/'controls.json').read_text());removed=[]
for events in x['requests']:
 seen=0;keep=[];gone=[]
 for e in events:
  tag=e['tag'];drop=False
  if tag[:3]==['__bool__','solvers.py','integrate']:
   seen+=1;drop=seen>2
  elif tag[:3]==['__bool__','solvers.py','_linear_interp']:drop=True
  (gone if drop else keep).append(e)
 assert len(gone)==127 and seen==65 and len(keep)==13,(len(gone),seen,len(keep));removed.append(gone);events[:]=keep
(P/'controls-optimized.json').write_text(json.dumps(x,indent=2)+'\n');(P/'removed-controls.json').write_text(json.dumps(removed,indent=2)+'\n')
x=json.loads((P/'partial.json').read_text());x['name']='f5-fixed-grid';x['files']['solver']=str(dst.parent);x['files']['controls']=str(P/'controls-optimized.json');env=x['application']['environment'];env['PYTHONPATH']='{file:solver}:'+env['PYTHONPATH'];(P/'optimized.json').write_text(json.dumps(x,indent=2)+'\n')
print('F5_SOLVER_CANDIDATE_PREPARED')
