"""Download only pinned inference checkpoints; verify sizes and LFS digests."""
import concurrent.futures,hashlib,json,shutil,urllib.request
from pathlib import Path
P=Path(__file__).resolve().parent;root=Path('/home/ubuntu/gx-ix14/causal/models/F5-TTS');meta=json.loads((P/'model-metadata.json').read_text());need=sum(x['size']for m in meta.values()for x in m['files']);assert shutil.disk_usage(root.parent).free>need+3000000000
jobs=[(repo,m['revision'],x)for repo,m in meta.items()for x in m['files']]
def fetch(job):
 repo,rev,x=job;f=root/repo.split('/')[-1]/x['path'];f.parent.mkdir(parents=True,exist_ok=True)
 if not f.exists():
  tmp=f.with_suffix(f.suffix+'.download')
  with urllib.request.urlopen(f'https://huggingface.co/{repo}/resolve/{rev}/{x["path"]}',timeout=180)as inp,tmp.open('wb')as out:shutil.copyfileobj(inp,out,4*1024*1024)
  assert tmp.stat().st_size==x['size'];tmp.replace(f)
 assert f.stat().st_size==x['size']
 with f.open('rb')as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
 if 'lfs'in x:assert digest==x['lfs']['oid']
 print('VERIFIED',repo,x['path'],x['size'],flush=True);return {'repository':repo,'revision':rev,'path':str(f.relative_to(root)),'bytes':x['size'],'sha256':digest,'lfs_sha_verified':'lfs'in x}
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as ex:rows=list(ex.map(fetch,jobs))
(P/'model-manifest.json').write_text(json.dumps({'root':str(root),'files':rows},indent=2)+'\n')
