#!/usr/bin/env bash
set -euo pipefail
# GX's launcher puts gx_cuda.so first. Insert the shim after that launcher has
# executed this script, so internal prediction calls resolve to the shim.
if [[ "$1" == --post-gx ]]; then
 capture_shim=$2
 shift 2
 export LD_PRELOAD="$capture_shim${LD_PRELOAD:+:$LD_PRELOAD}"
 exec "$@"
fi
run_dir=$1
capture_shim=$2
shift 2
exec bash /workspace/causal/code/entry.sh "$run_dir" bash "$0" --post-gx "$capture_shim" "$@"
