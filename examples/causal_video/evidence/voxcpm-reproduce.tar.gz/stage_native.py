"""Stage pinned VoxCPM2 assets and verify reused dependencies; no GPU use."""
import hashlib,json,shlex,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;host='/home/jcm/drperf-wan-a100-20260916/causal'
base=host+'/voxcpm';ssh=['ssh','-o','ConnectTimeout=10','-o','ConnectionAttempts=3','jcm@A100']
manifest=json.loads((P/'model-manifest.json').read_text());model=Path(manifest['path']);native_model=host+'/models/'+model.name
def digest(f):
 with f.open('rb')as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
need=sum(x['bytes']for x in manifest['files'])+sum(f.stat().st_size for f in (P/'deps').rglob('*')if f.is_file())
subprocess.run(ssh+['python3 -'],input='import shutil; f=shutil.disk_usage(%r).free;assert f>%d+2000000000,(f,%d)'%(host,need,need),text=True,check=True)
subprocess.run(ssh+['mkdir -p '+shlex.quote(base+'/cache-native')+' && chmod 0777 '+shlex.quote(base+'/cache-native')],check=True)
checks={}
for other in ('qwen-tts','fastgen'):
 inherited=json.loads((P.parent/other/'native-identities.json').read_text());checks.update({k:v for k,v in inherited.items()if '/causal/'+other+'/deps/' in k})
for folder,dest in [(P/'source',base+'/source'),(model,native_model)]:
 subprocess.run(ssh+['mkdir -p '+shlex.quote(dest)],check=True)
 sender=subprocess.Popen(['tar','--exclude=.git','--exclude=__pycache__','-C',str(folder),'-cf','-','.'],stdout=subprocess.PIPE)
 try:subprocess.run(ssh+['tar --no-same-owner -C '+shlex.quote(dest)+' -xf -'],stdin=sender.stdout,check=True)
 finally:sender.stdout.close()
 assert sender.wait()==0
 for f in folder.rglob('*'):
  if f.is_file() and '.git' not in f.parts and '__pycache__' not in f.parts:checks[dest+'/'+str(f.relative_to(folder))]=digest(f)
 print('VOXCPM_NATIVE_STAGED',dest,flush=True)
for name in ('runner.py','profile.sh'):
 subprocess.run(['rsync','-az','-e','ssh -o ConnectTimeout=10 -o ConnectionAttempts=3',str(P/name),'jcm@A100:'+base+'/'+name],check=True)
 checks[base+'/'+name]=digest(P/name)
script='''import hashlib,json
checks=json.loads(%r)
for name,expected in checks.items():
 with open(name,'rb')as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==expected,name
print('VOXCPM_NATIVE_IDENTITIES_PASS',len(checks))
'''%json.dumps(checks)
subprocess.run(ssh+['python3 -'],input=script,text=True,check=True)
(P/'native-identities.json').write_text(json.dumps(checks,indent=2)+'\n')
