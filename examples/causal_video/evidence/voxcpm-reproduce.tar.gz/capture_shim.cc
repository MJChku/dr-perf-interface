// Preserve predicted compute during CUDA graph capture. The pinned runtime
// exports this recorder, but Predict_kernel_fn never invokes it.
#include <cuda.h>
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <dlfcn.h>
#include "gx_launch_abi.h"
using Predict=int(*)(cuLaunchConfig*);
using Record=bool(*)(const CUlaunchConfig*,void*,const void*,size_t);
static std::atomic<unsigned long long> captured{0},submitted{0};
extern "C" int Predict_kernel_fn(cuLaunchConfig* config) {
 static auto next=reinterpret_cast<Predict>(dlsym(RTLD_NEXT,"Predict_kernel_fn"));
 static auto record=reinterpret_cast<Record>(dlsym(RTLD_NEXT,"Emu_cudaGraphRecordPredictKernelLaunch"));
 if (!next || !record) { std::fprintf(stderr,"GX_CAPTURE_SHIM_MISSING_ABI\n");std::abort(); }
 if (!config)return next(config);
 CUlaunchConfig c{};
 c.gridDimX=config->gridDimX;c.gridDimY=config->gridDimY;c.gridDimZ=config->gridDimZ;
 c.blockDimX=config->blockDimX;c.blockDimY=config->blockDimY;c.blockDimZ=config->blockDimZ;
 c.sharedMemBytes=config->sharedMemBytes;c.hStream=static_cast<CUstream>(config->stream);
 if(record(&c,config->kernelFn,config->kernelParams,config->kernelParamsSize)) {
  ++captured;
  std::free(config->kernelParams);std::free(config);
  return 0;
 }
 ++submitted;return next(config);
}
__attribute__((destructor)) static void report_capture_fix() {
 if(captured.load() || submitted.load())std::fprintf(stderr,"GX_CAPTURE_SHIM captured=%llu submitted=%llu\n",captured.load(),submitted.load());
}

// cuBLAS predictions use a separate path. Use an internal host-command slot
// as a tagged captured record, then submit the cuBLAS operation INLINE during
// graph replay. It must not run as a queued host callback, which would reorder
// the operation after later graph nodes. The marker aborts if that invariant
// is violated. A production GX repair should add an owned CublasPredict task.
#include <string>
using HostFn=void(*)(void*);
using RecordHost=bool(*)(CUstream,HostFn,void*);
using HostLaunch=int(*)(void*,HostFn,void*);
using Blas=int(*)(const char*,unsigned,unsigned,unsigned,unsigned,unsigned,unsigned,uint64_t,void*);
struct CapturedBlas {
 std::string name;
 unsigned gx,gy,gz,bx,by,bz;
 uint64_t hash;
};
static std::atomic<unsigned long long> blas_captured{0},blas_submitted{0},blas_replayed{0};
static void captured_blas_marker(void*) {std::fprintf(stderr,"GX_CAPTURE_SHIM_ORDER_VIOLATION\n");std::abort();}
extern "C" int Emu_cublas_predict_async(const char* name,unsigned gx,unsigned gy,unsigned gz,unsigned bx,unsigned by,unsigned bz,uint64_t hash,void* stream) {
 static auto next=reinterpret_cast<Blas>(dlsym(RTLD_NEXT,"Emu_cublas_predict_async"));
 static auto record=reinterpret_cast<RecordHost>(dlsym(RTLD_NEXT,"Emu_cudaGraphRecordHostFunc"));
 if(!next || !record){std::fprintf(stderr,"GX_CAPTURE_SHIM_MISSING_BLAS_ABI\n");std::abort();}
 auto* data=new CapturedBlas{name?name:"cublasLtMatmul",gx,gy,gz,bx,by,bz,hash};
 if(record(static_cast<CUstream>(stream),captured_blas_marker,data)) {
  // Retain until process exit: GX's HostFunc records provide no ownership or
  // graph-clone destruction callback. This bounded experiment captures a
  // finite set of graphs; lifetime retention is disclosed in its provenance.
  ++blas_captured;return 0;
 }
 delete data;++blas_submitted;return next(name,gx,gy,gz,bx,by,bz,hash,stream);
}
extern "C" int Emu_launch_host_func(void* stream,HostFn fn,void* data) {
 static auto next=reinterpret_cast<HostLaunch>(dlsym(RTLD_NEXT,"Emu_launch_host_func"));
 if(!next){std::fprintf(stderr,"GX_CAPTURE_SHIM_MISSING_HOST_ABI\n");std::abort();}
 if(fn==captured_blas_marker) {
  auto* b=static_cast<CapturedBlas*>(data);++blas_replayed;
  return Emu_cublas_predict_async(b->name.c_str(),b->gx,b->gy,b->gz,b->bx,b->by,b->bz,b->hash,stream);
 }
 return next(stream,fn,data);
}
__attribute__((destructor)) static void report_blas_fix() {
 if(blas_captured.load() || blas_submitted.load())std::fprintf(stderr,"GX_CAPTURE_SHIM_BLAS captured=%llu submitted=%llu replayed=%llu retained_payload_bytes_at_least=%llu\n",blas_captured.load(),blas_submitted.load(),blas_replayed.load(),blas_captured.load()*sizeof(CapturedBlas));
}
