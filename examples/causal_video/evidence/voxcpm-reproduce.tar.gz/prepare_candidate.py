"""Prepare sampler buffer reuse outside compiled model functions; no timing claim."""
import difflib,shutil
from pathlib import Path
P=Path(__file__).resolve().parent;src=P/'source';dest=P/'source-buffers'
shutil.copytree(src,dest,ignore=shutil.ignore_patterns('.git','__pycache__'),dirs_exist_ok=True)
rel='src/voxcpm/modules/locdit/unified_cfm.py';before=(src/rel).read_text()
a='''        zero_init_steps = max(1, int(len(t_span) * 0.04))
        for step in range(1, len(t_span)):
'''
b='''        zero_init_steps = max(1, int(len(t_span) * 0.04))
        # The estimator reads these inputs without modifying them. Allocate
        # scratch storage once per solve; conditioning is constant over steps.
        if not use_cfg_zero_star or zero_init_steps < len(t_span) - 1:
            b = x.size(0)
            x_in = torch.empty([2 * b, self.in_channels, x.size(2)], device=x.device, dtype=x.dtype)
            mu_in = torch.zeros([2 * b, mu.size(1)], device=x.device, dtype=x.dtype)
            mu_in[:b] = mu
            t_in = torch.empty([2 * b], device=x.device, dtype=x.dtype)
            dt_in = torch.zeros([2 * b], device=x.device, dtype=x.dtype)
            cond_in = torch.empty([2 * b, self.in_channels, cond.size(2)], device=x.device, dtype=x.dtype)
            cond_in[:b], cond_in[b:] = cond, cond
        for step in range(1, len(t_span)):
'''
assert before.count(a)==1;after=before.replace(a,b)
a='''                b = x.size(0)
                x_in = torch.zeros([2 * b, self.in_channels, x.size(2)], device=x.device, dtype=x.dtype)
                mu_in = torch.zeros([2 * b, mu.size(1)], device=x.device, dtype=x.dtype)
                t_in = torch.zeros([2 * b], device=x.device, dtype=x.dtype)
                dt_in = torch.zeros([2 * b], device=x.device, dtype=x.dtype)
                cond_in = torch.zeros([2 * b, self.in_channels, cond.size(2)], device=x.device, dtype=x.dtype)
                x_in[:b], x_in[b:] = x, x
                mu_in[:b] = mu
                t_in[:b], t_in[b:] = t.unsqueeze(0), t.unsqueeze(0)
                dt_in[:b], dt_in[b:] = dt.unsqueeze(0), dt.unsqueeze(0)
                # not used now
                if not self.mean_mode:
                    dt_in = torch.zeros_like(dt_in)
                cond_in[:b], cond_in[b:] = cond, cond
'''
b='''                x_in[:b], x_in[b:] = x, x
                t_in[:b], t_in[b:] = t.unsqueeze(0), t.unsqueeze(0)
                if self.mean_mode:
                    dt_in[:b], dt_in[b:] = dt.unsqueeze(0), dt.unsqueeze(0)
'''
assert after.count(a)==1;after=after.replace(a,b);(dest/rel).write_text(after)
(P/'sampler-buffers.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
print('VOXCPM_CANDIDATE_PREPARED')
