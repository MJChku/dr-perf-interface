"""Compare every estimator input and final Euler output using source methods."""
import ast,json
from pathlib import Path
import torch
P=Path(__file__).resolve().parent;torch.set_num_threads(1)
def load(path):
 tree=ast.parse(path.read_text());cls=next(x for x in tree.body if isinstance(x,ast.ClassDef)and x.name=='UnifiedCFM');ns={'torch':torch};code=ast.Module(body=[x for x in cls.body if isinstance(x,ast.FunctionDef)and x.name in ('solve_euler','optimized_scale')],type_ignores=[]);exec(compile(code,str(path),'exec'),ns);return ns
rel='src/voxcpm/modules/locdit/unified_cfm.py';before=load(P/'source'/rel);after=load(P/'source-buffers'/rel)
class Context:
 def __init__(self,ns,channels,mean):
  self.in_channels=channels;self.mean_mode=mean;self.seen=[];self.solve_euler=ns['solve_euler'].__get__(self);self.optimized_scale=ns['optimized_scale'].__get__(self)
 def estimator(self,x,mu,t,cond,dt):
  self.seen.append(tuple(v.clone()for v in (x,mu,t,cond,dt)))
  return x*.25+mu[:,:self.in_channels,None]*.01+cond*.2+(t+dt)[:,None,None]*.3
count=0;calls=0
torch.manual_seed(42)
for dtype in (torch.float32,torch.bfloat16):
 for batch in (1,3):
  for steps in (1,2,10,30):
   for mean in (False,True):
    for zero in (False,True):
     channels=4;length=3
     x=torch.randn(batch,channels,length,dtype=dtype);mu=torch.randn(batch,channels+2,dtype=dtype);cond=torch.randn(batch,channels,length,dtype=dtype)
     t=torch.linspace(1,0,steps+1,dtype=dtype);t=t+(torch.cos(torch.pi/2*t)-1+t)
     a=Context(before,channels,mean);b=Context(after,channels,mean)
     ra=a.solve_euler(x.clone(),t.clone(),mu.clone(),cond.clone(),cfg_value=2.,use_cfg_zero_star=zero);rb=b.solve_euler(x.clone(),t.clone(),mu.clone(),cond.clone(),cfg_value=2.,use_cfg_zero_star=zero)
     assert torch.equal(ra,rb),(dtype,batch,steps,mean,zero)
     assert len(a.seen)==len(b.seen)
     for av,bv in zip(a.seen,b.seen):
      for v,w in zip(av,bv):assert torch.equal(v,w),(dtype,batch,steps,mean,zero)
     count+=1;calls+=len(a.seen)
result={'passed':True,'cases':count,'estimator_calls_checked':calls,'torch':torch.__version__,'device':'CPU','scope':'FP32/BF16, batch1/3,1/2/10/30Eulersteps, mean_mode on/off, zero-star on/off. Check every estimator input and final output exactly. Uses a deterministic read-only estimator; real compiled model/native waveform validation still required.'}
(P/'buffers-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
