// Exact cuLaunchConfig declaration extracted from GX device_femu.h.
#pragma once
#include <stdint.h>
typedef struct cuLaunchConfig {
  int gridDimX;
  int gridDimY;
  int gridDimZ;
  int blockDimX;
  int blockDimY;
  int blockDimZ;
  int sharedMemBytes;
  void* stream;
  int device;
  void** kernelParams;
  uint64_t kernelParamsSize;
  void* kernelFn;
  void* kernelParamsSrc;
  const char* api_type;
} cuLaunchConfig;
