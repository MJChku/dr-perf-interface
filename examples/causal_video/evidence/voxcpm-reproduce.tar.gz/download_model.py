"""Download pinned public model once into GX workspace; verify LFS hashes."""
import concurrent.futures,hashlib,json,shutil,urllib.request
from pathlib import Path
P=Path(__file__).resolve().parent
repo='openbmb/VoxCPM2';revision='32279effe8c19989596f05d353d1447f51d9e915'
dest=Path('/home/ubuntu/gx-ix14/causal/models/VoxCPM2')
items=json.load(urllib.request.urlopen(f'https://huggingface.co/api/models/{repo}/tree/{revision}?recursive=true&expand=false'))
items=[x for x in items if x['type']=='file']
need=sum(x['size']for x in items)
assert shutil.disk_usage(dest.parent).free>need+3000000000
dest.mkdir(exist_ok=True)
def fetch(item):
 f=dest/item['path'];f.parent.mkdir(parents=True,exist_ok=True);tmp=f.with_suffix(f.suffix+'.download')
 if not f.exists():
  with urllib.request.urlopen(f'https://huggingface.co/{repo}/resolve/{revision}/{item["path"]}',timeout=180) as inp,tmp.open('wb')as out:
   shutil.copyfileobj(inp,out,4*1024*1024)
  assert tmp.stat().st_size==item['size'],f
  tmp.replace(f)
 assert f.stat().st_size==item['size']
 with f.open('rb')as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
 if 'lfs' in item:assert digest==item['lfs']['oid'],f
 print('VERIFIED',item['path'],item['size'],flush=True)
 return {'path':item['path'],'bytes':item['size'],'sha256':digest,'lfs_sha_verified':'lfs'in item}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:verified=list(ex.map(fetch,items))
(P/'model-manifest.json').write_text(json.dumps({'repository':repo,'revision':revision,'path':str(dest),'files':verified},indent=2)+'\n')
print('VOXCPM_MODEL_VERIFIED',sum(x['bytes']for x in verified),flush=True)
