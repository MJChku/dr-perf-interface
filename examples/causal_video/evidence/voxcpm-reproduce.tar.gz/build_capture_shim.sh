#!/usr/bin/env bash
set -euo pipefail
case_dir=$(cd "$(dirname "$0")" && pwd)
cuda_include=${1:?pass the directory containing CUDA driver cuda.h}
g++ -std=c++17 -O2 -shared -fPIC -I "$cuda_include" "$case_dir/capture_shim.cc" -ldl -o "$case_dir/capture_shim.so"
