"""Original VoxCPM2 API; fixed-request scalar-control calibration/replay for GX."""
import argparse,ctypes,hashlib,json,os,resource,sys,time
from importlib.metadata import version
from pathlib import Path
import numpy as np
import torch
p=argparse.ArgumentParser();p.add_argument('--model',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--role',choices=['gpu-profile','native','emu','cpu-profile','partial_sync'],required=True);p.add_argument('--controls',type=Path);p.add_argument('--warmup',type=int,default=2);p.add_argument('--repetitions',type=int,default=1);a=p.parse_args()
a.output.mkdir(parents=True,exist_ok=False);os.chdir(a.output)
physical=a.role in ('gpu-profile','native');assert physical or a.controls
spec={'text':'Hello. This is a test of speech generation.','cfg_value':2.0,'inference_timesteps':10,'min_len':2,'max_len':256,'normalize':False,'denoise':False,'retry_badcase':True,'seed':42}
reference=json.loads(a.controls.read_text())if a.controls else None
if reference:assert reference['request']==spec
# The kernel profiler cannot time captured launches. Keep Torch compilation,
# disabling graph capture only in the initial native kernel calibration.
if a.role=='gpu-profile':
 import torch._inductor.config as inductor_config
 inductor_config.triton.cudagraphs=False
# reduce-overhead normally overrides the global flag; remove only that option
# from the compile mode during kernel profiling. Native/GX default runs retain it.
original_compile=torch.compile
compile_calls=[]
def compile_model(model=None,**kwargs):
 original_kwargs=dict(kwargs)
 if a.role=='gpu-profile':
  assert kwargs.get('mode')=='reduce-overhead',kwargs
  kwargs.pop('mode');kwargs['options']={'triton.cudagraphs':False}
 compile_calls.append({'original':original_kwargs,'effective':kwargs})
 return original_compile(model,**kwargs)
torch.compile=compile_model
torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.manual_seed(42);torch.cuda.manual_seed_all(42)

class Tape:
 def __init__(self):self.active=False;self.records={'load':[],'requests':[]}
 def start(self,phase,index=0):
  self.phase=phase;self.events=[];self.cursor=0;self.selected=None
  if reference:self.selected=reference['load']if phase=='load' else reference['requests'][min(index,len(reference['requests'])-1)]
  self.active=True
 def finish(self):
  self.active=False
  if self.selected is not None:assert self.cursor==len(self.selected),(self.phase,self.cursor,len(self.selected))
  if self.phase=='load':self.records['load']=self.events
  else:self.records['requests'].append(self.events)
 def read(self,tag,observed):
  if self.selected is not None:
   assert self.cursor<len(self.selected),('extra control',tag,self.cursor)
   expected=self.selected[self.cursor];assert tag==expected['tag'],('control path',tag,expected['tag'])
   if physical:assert observed==expected['value'],('native control',tag,observed,expected['value'])
   value=expected['value']
  else:
   assert physical;value=observed
  self.events.append({'tag':tag,'value':value});self.cursor+=1;return value

tape=Tape();original_item=torch.Tensor.item;original_cpu=torch.Tensor.cpu
# Restrict hooks to the two explicit inference scalar controls; compiled model
# operations and large waveform/latent transfers keep their original methods.
def relevant(tensor,frame):
 return tape.active and tensor.device.type=='cuda' and tensor.numel()==1 and Path(frame.f_code.co_filename).name=='voxcpm2.py' and frame.f_code.co_name=='_inference'
def item(tensor,*args,**kwargs):
 frame=sys._getframe(1)
 if not relevant(tensor,frame):return original_item(tensor,*args,**kwargs)
 observed=original_item(tensor,*args,**kwargs)
 return tape.read(['item',frame.f_code.co_name,list(tensor.shape),str(tensor.dtype)],observed if physical else None)
def cpu(tensor,*args,**kwargs):
 frame=sys._getframe(1)
 if not relevant(tensor,frame):return original_cpu(tensor,*args,**kwargs)
 result=original_cpu(tensor,*args,**kwargs)
 value=tape.read(['cpu',frame.f_code.co_name,list(tensor.shape),str(tensor.dtype)],original_item(result)if physical else None)
 return result if physical else torch.tensor(value,dtype=result.dtype,device='cpu').reshape(result.shape)
torch.Tensor.item=item;torch.Tensor.cpu=cpu

from voxcpm import VoxCPM
import voxcpm.model.voxcpm2 as model_module
original_seed=model_module.materialize_generation_seed
def bootstrap_seed(seed):
 if tape.active and tape.phase=='load' and seed is None:return 42
 return original_seed(seed)
model_module.materialize_generation_seed=bootstrap_seed
import voxcpm
root=Path(voxcpm.__file__).parent
report={'phase':'loading','role':a.role,'bootstrap_seed':42,'request':spec,'scope':'Public VoxCPM.from_pretrained/load_denoiser=False/optimize=True then generate. No reference audio, normalization or file encoding; original retries, compiled model, CPU waveform return.','runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':{str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest()for f in root.rglob('*.py')},'versions':{n:version(n)for n in ('torch','torchaudio','transformers','pydantic','numpy','librosa','triton')},'control_reference_sha256':hashlib.sha256(a.controls.read_bytes()).hexdigest()if a.controls else None,'warmups':[],'iterations':[]}
def save():(a.output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
save();tape.start('load');start=time.perf_counter()
model=VoxCPM.from_pretrained(str(a.model),load_denoiser=False,optimize=True,device='cuda',local_files_only=True)
tape.finish();report.update(phase='loaded',load_host_seconds=time.perf_counter()-start,load_control_count=len(tape.records['load']),compile_calls=compile_calls,parameters=sum(p.numel()for p in model.tts_model.parameters()));save();print('VOXCPM_LOADED',report['load_host_seconds'],flush=True)
def generate(index):
 tape.start('request',index);output=model.generate(**spec);torch.cuda.synchronize();return output
def check(output):
 w=np.asarray(output);assert w.ndim==1 and len(w)>0
 row={'sample_rate':model.tts_model.sample_rate,'samples':len(w),'dtype':str(w.dtype),'control_count':tape.cursor,'generation_seed':model.tts_model.last_successful_seed}
 if physical:
  assert np.isfinite(w).all();row.update(finite=True,output_sha256=hashlib.sha256(w.tobytes()).hexdigest(),minimum=float(w.min()),maximum=float(w.max()))
 return row
for i in range(a.warmup):
 output=generate(i);tape.finish();report['warmups'].append(check(output))
print('VOXCPM_WARMUP_DONE',flush=True)
rt=ctypes.CDLL(None)
if a.role=='partial_sync':rt.gxvm_adopt_now();rt.gxvm_timeline_mark.argtypes=[ctypes.c_uint,ctypes.c_int]
if a.role=='cpu-profile':rt.gxvm_ipc_profile_start()
if a.role=='gpu-profile':Path(os.environ['GX_PROFILE_START_FILE']).touch(exist_ok=False)
for i in range(a.repetitions):
 if a.role=='partial_sync':rt.gxvm_timeline_mark(i+1,0)
 start=time.perf_counter();output=generate(a.warmup+i);seconds=time.perf_counter()-start
 if a.role=='partial_sync':rt.gxvm_timeline_mark(i+1,1)
 tape.finish();report['iterations'].append(check(output)|{'iteration':i+1,'application_clock_seconds':seconds})
if a.role=='cpu-profile':assert rt.gxvm_ipc_profile_stop()==0
if a.role=='gpu-profile':Path(os.environ['GX_PROFILE_STOP_FILE']).touch(exist_ok=False)
if reference is None:(a.output/'controls.json').write_text(json.dumps({'request':spec,**tape.records},indent=2)+'\n')
report.update(phase='completed',peak_gpu_bytes=torch.cuda.max_memory_allocated(),peak_reserved_gpu_bytes=torch.cuda.max_memory_reserved(),peak_host_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,compile_calls=compile_calls)
save();print('VOXCPM_COMPLETE',json.dumps({k:v for k,v in report.items()if k!='source_sha256'}),flush=True)
