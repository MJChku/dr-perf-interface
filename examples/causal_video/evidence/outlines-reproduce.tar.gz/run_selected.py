import json,statistics,subprocess,time
from pathlib import Path
P=Path(__file__).resolve().parent
for _ in range(600):
 if (P/'inference-after-run.json').exists()and(P/'inference-oracle.json').exists():break
 time.sleep(2)
else:raise RuntimeError('Inference screen timeout')
a=json.loads((P/'inference-after-audit.json').read_text());b=json.loads((P/'partial-audit.json').read_text());assert a['result']['passed']and not a['result']['cleanup_errors'];assert json.loads((P/'inference-oracle.json').read_text())['passed']
gain=100*(1-statistics.mean(x['virtual_seconds']for x in a['iterations'])/statistics.mean(x['virtual_seconds']for x in b['iterations']));print('OUTLINES_INFERENCE_GAIN',gain,flush=True);assert gain>1.0,gain
assert a['launches']==b['launches'],'Inspect changed GPU work before selection'
(P/'selected.json').write_text(json.dumps({'source':'source-inference','audit':'inference-after','controls':'controls.json','control_arrays':'controls.npz','reason':'Opt-in inference context for pure Torch generation; timed runner body identical,load-time keyword differs. Mask roundtrip remains a separate low-gain screen.'},indent=2)+'\n')
# Independent real-GPU final validation and simulated mode3 can proceed together.
with (P/'native-controller.log').open('w')as f:
 proc=subprocess.Popen(['python3',str(P/'run_native_validation.py')],stdout=f,stderr=subprocess.STDOUT)
 try:
  for name in ('sync-before','sync-after'):
   for script in ('compress_completed.py','compress_workspace.py'):subprocess.run(['python3',str(P/script)],check=True)
   subprocess.run(['python3',str(P/'run_timing.py'),name],check=True)
 finally:code=proc.wait()
 assert code==0,'Native final validation failed; inspect retained reports'
