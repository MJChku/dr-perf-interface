import hashlib,importlib.util,json,os
from pathlib import Path
import torch
from outlines_core import Index,Vocabulary
from outlines.backends.outlines_core import OutlinesCoreLogitsProcessor as Original
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('candidate_backend',P/'source-mask/src/outlines/backends/outlines_core.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);Candidate=mod.OutlinesCoreLogitsProcessor
torch.set_num_threads(1);torch.manual_seed(9)
vocab=Vocabulary(0,{c:[i+1]for i,c in enumerate('0123456789abcd')});cases=0;steps=0;transfers=[0,0]
for regex in ('[0-9]{4}','(ab|cd){2}','a?b[0-9]'):
 for batch in (1,2,4):
  for dtype in (torch.float32,torch.bfloat16):
   a,b=[cls(Index(regex,vocab),'torch')for cls in (Original,Candidate)]
   for j,proc in enumerate((a,b)):
    old=proc.tensor_adapter.to_device
    def track(t,device,_old=old,_j=j):transfers[_j]+=1;return _old(t,device)
    proc.tensor_adapter.to_device=track
   for cycle in range(2):
    a.reset();b.reset();ids=torch.zeros((batch,1),dtype=torch.long)
    for step in range(10):
     logits=torch.randn(batch,16,dtype=dtype);y=a(ids,logits.clone());z=b(ids,logits.clone());assert torch.equal(y,z),(regex,batch,dtype,cycle,step)
     assert all(torch.equal(x,y)for x,y in zip(a._bitmasks,b._bitmasks));assert all(x.device.type=='cpu'for x in b._bitmasks)
     chosen=y.argmax(-1,keepdim=True);ids=torch.cat((ids,chosen),dim=1);steps+=1
    cases+=1
assert transfers[0]==2*transfers[1]
out={'passed':True,'cases':cases,'steps':steps,'adapter_to_device_calls':transfers,'scope':'Actual original/candidate OutlinesCoreLogitsProcessor and Rust Guide/Index on CPU,three grammars,batch1/2/4,FP32/BF16,reset cycles,completed states. Exact logits and CPU bitmasks. Torch compile disabled for this helper oracle only; selected full-model GX and native workloads retain compiled mask kernel. This verifies CPU semantics, not CUDA lifetime/order or full-model output.','patch_sha256':hashlib.sha256((P/'retain-cpu-mask.patch').read_bytes()).hexdigest()}
Path(os.environ.get('ORACLE_OUTPUT',str(P/'mask-oracle.json'))).write_text(json.dumps(out,indent=2)+'\n');print('OUTLINES_MASK_ORACLE_PASS',json.dumps(out),flush=True)
