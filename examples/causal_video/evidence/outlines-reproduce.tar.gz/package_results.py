"""Keep GX predictions, initial calibration and final A100 validation distinct."""
import gzip,hashlib,json,shutil,statistics,subprocess,sys,tarfile,tempfile
from pathlib import Path
P=Path(__file__).resolve().parent;E=P.parents[2]/'examples/causal_video';sys.path.insert(0,str(E))
from compact_gx_trace import compact
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins={'source':{'remote':'https://github.com/dottxt-ai/outlines.git','commit':subprocess.check_output(['git','-C',str(P/'source'),'rev-parse','HEAD'],text=True).strip()},'model':read(P/'model-manifest.json'),'dependencies':read(P/'kernel-profile.json')['versions'],'workload':read(P/'kernel-profile.json')['request'],'scope':read(P/'kernel-profile.json')['scope']};(P/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
limits=[
 'One structured-generation batch:4identical Return a 64 digit integer: prompts,regex[0-9]{64},greedy,max96newtokens,seed42,pretrained SmolLM2-135M BF16 SDPA. Each generated output has64digits; actual decode65steps includingEOS. Prompt tokenization,CPU grammar/masks,model generation and output decoding included; model/grammar compilation and file I/O excluded.',
 'New inference_mode flag defaultsFalse. Opt in only when model/logits-processor callbacks do not need autograd or create tensors for subsequent autograd use. Other backends retain the original path. All arithmetic,mask copies,compiled masking and cache policy retained in the selected comparison.',
 'Baseline runner and opt-in runner differ only in a load-time factory keyword; timed generate/check ASTs are identical and checked. Original CPU calibration and kernel database reused. The independent mask-retention candidate uses the original runner and is not combined with this change.',
 'GX skips arithmetic and replays native scalar/list/CPU-array controls after original transfers/waits. Native plain timings restore all tensor/arange hooks. No Boolean-index shape adapter in this workload. A cold compilation-only read of negative infinity is recorded in the first native warmup; all native generated outputs are identical.',
 'Native compiled masking grid192blocks differs from GX96blocks,with128threads/block and the same kernel name. This creates520prediction misses across2requests. Baseline native-only inventory325launches/request includes260mask launches and65FP32BLAS launches; GX adds260mask launches with its other grid. Isolated omitted medians sum2.397120ms/request,not an end-to-end correction. No unsupported timing correction or new hardware profiling was added during optimization.',
 'CPU calibration400unresolved of7999instruction samples(5.00%),12unresolved task samples. GX and A100 CPU hosts differ. Mode3 uses10us epochs; GPU spans include epoch placement effects and are not hardware utilization. Predictions must be read alongside native validation.',
 'Initial guarded native baseline reused a compiler cache and skipped a compilation-only negative-infinity read present in the cold tape. Only guarded checks were repeated with isolated cold compiler caches; all unhooked ABBA timings were retained unchanged.',
 'Native unprofiled ABBA3warmups7measured batches/process,14pervariant,all28retained. Four sequences perbatch; guarded requests excluded from latency statistics. Scope is this model,grammar,batch and backend,not arbitrary structured generation.',
]
out={'system':'Outlines','pins':pins,'change':'Opt in to scoped Torch inference mode during model generation, avoiding autograd bookkeeping while preserving the default and other tensor backends.','gx':{},'traces':{},'limitations':limits,'native_kernel_calibration':read(P/'kernel-profile.json'),'kernel_calibration':read(P/'kernel-calibration.json'),'cpu_calibration':read(P/'cpu-calibration.json'),'omissions':read(P/'omissions.json'),'cpu_oracles':read(P/'inference-oracle.json'),'selection':read(P/'selected.json')}
for mode,names in [('mode2',('partial','inference-after')),('mode3',('sync-before','sync-after'))]:
 pair={}
 for side,name in zip(('before','after'),names):
  a=read(P/(name+'-audit.json'));assert a['result']['passed']and not a['result']['cleanup_errors'];assert a['model']['runner_sha256']==sha(P/('runner.py'if side=='before'else'runner-inference.py'));assert a['gpu_db_sha256']==sha(P/'gpu.sqlite')and a['cpu_db_sha256']==sha(P/'cpu.db')
  pair[side]=a|{'runtime':read(Path(a['run'])/'runtime.json'),'controller_wall_seconds':read(P/(name+'-run.json'))['controller_wall_seconds']};pair[side]['means']={k:statistics.mean(x[k]for x in a['iterations'])for k in ('virtual_seconds','cpu_seconds','gpu_span_seconds','outside_gpu_spans_seconds')}
  dst=E/f'evidence/outlines-{mode}-{side}.chrome.json.gz';src=Path(a['run'])/'timeline-report/trace.json.gz';out['traces'][mode+'_'+side]={'file':dst.name,'full_trace':str(src),**compact(src,dst,bin_ms=1)}
 assert pair['before']['runtime']['dynamorio']==pair['after']['runtime']['dynamorio'];assert pair['before']['launches']==pair['after']['launches'];assert all(x['iterations'][0]['copy_bytes']==pair['before']['iterations'][0]['copy_bytes']for x in pair.values());assert all(x['model']['iterations'][0]['control_count']==718 for x in pair.values())
 pair['request_reduction_percent']=100*(1-pair['after']['means']['virtual_seconds']/pair['before']['means']['virtual_seconds']);out['gx'][mode]=pair
n=read(P/'native-summary.json');assert n['measured_output_checks']==28
for block in n['reports']:
 report=block['report'];g=out['gx']['mode2'][block['side']]['model'];assert report['versions']==g['versions']and report['source_sha256']==g['source_sha256'];assert report['plain']and report['runner_sha256']==sha(P/('runner.py'if block['side']=='before'else'runner-inference.py'));assert {x['output_sha256']for x in report['iterations']}=={n['output_sha256']}
for x in n['control_reports']:
 d=x['report'];assert {r['output_sha256']for r in d['warmups']+d['iterations']}=={n['output_sha256']}
out['native_A100']=n|{'hardware':read(P/'native-validation-hardware.json'),'guard_cache_recovery':read(P/'control-cache-recovery.json')}
with tempfile.TemporaryDirectory(prefix='outlines-patch-')as td:
 root=Path(td);shutil.copytree(P/'source',root/'source',ignore=shutil.ignore_patterns('.git','__pycache__'));subprocess.run(['git','apply',str(P/'inference-mode.patch')],cwd=root/'source',check=True);assert (root/'source/src/outlines/models/transformers.py').read_bytes()==(P/'source-inference/src/outlines/models/transformers.py').read_bytes()
out['patch_application_checked']=True
shutil.copyfile(P/'runner.py',E/'outlines_runner.py');shutil.copyfile(P/'inference-mode.patch',E/'cpu_patches/outlines_inference_mode.patch')
a=read(P/'mask-after-audit.json');out['additional_screen']={'change':'RetainCPUtoken mask instead of copying read-only GPU copy back.','gx_audit':a,'mean_seconds':statistics.mean(x['virtual_seconds']for x in a['iterations']),'reduction_percent':100*(1-statistics.mean(x['virtual_seconds']for x in a['iterations'])/out['gx']['mode2']['before']['means']['virtual_seconds']),'cpu_oracle':read(P/'mask-oracle.json'),'native_validation':False,'mode3_validation':False,'selection':'Not selected; only0.43%mode2 gain.'}
files=['pins.json','runner.py','runner-calibration.py','runner-inference.py','runner-inference.patch','inference-mode.patch','selected.json','model-manifest.json','model-metadata.json','download_model.py','controls.json','controls.npz','controls-mask.json','removed-mask-controls.json','emu.json','cpu.json','partial.json','inference-after.json','mask-after.json','sync-before.json','sync-after.json','audit.py','run_timing.py','run_cpu.py','profile.sh','run_native_profile.py','stage_native.py','kernel-calibration.json','cpu-calibration.json','omissions.json','record_omissions.py','native-calibration-identities.json','native-profile-checked-identities.json','native-validation-identities.json','native-profile-hardware.json','native-validation-hardware.json','run_native_validation.py','validate-native.sh','inference_oracle.py','inference-oracle.json','mask_oracle.py','mask-oracle.json','retain-cpu-mask.patch','run_selected.py','recover_native_controls.py','validate-controls-cold.sh','control-cache-recovery.json','package_results.py']
bundle=E/'evidence/outlines-reproduce.tar.gz'
with tarfile.open(bundle,'w:gz')as t:
 for name in files:t.add(P/name,arcname=name)
with tarfile.open(bundle,'r:gz')as t:
 assert sorted(t.getnames())==sorted(files)
 for name in files:assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==sha(P/name)
out['reproduction']={'file':bundle.name,'sha256':sha(bundle),'files':files,'note':'Install pinned source/dependencies and adjust paths. Apply inference-mode.patch to candidate Outlines source. runner-inference.py differs from baseline only by the load-time opt-in keyword; runner-inference.patch and AST oracle capture that distinction. Timed request bodies are identical. Native plain timing restores tensor-control hooks.'}
dbdir=E/'evidence/kernel-databases';manifest=read(dbdir/'manifest.json');artifacts={}
for key,name,target in [('native_database','gpu.sqlite','outlines.sqlite.gz'),('native_report','kernel-profile.json','outlines.report.json.gz'),('cpu_instruction_calibration','cpu.db','outlines.cpu.db.gz')]:
 raw=(P/name).read_bytes();dst=dbdir/target;dst.write_bytes(gzip.compress(raw,compresslevel=9,mtime=0));assert gzip.decompress(dst.read_bytes())==raw;artifacts[key]={'file':target,'uncompressed_bytes':len(raw),'uncompressed_sha256':sha(P/name),'gzip_sha256':sha(dst)}
manifest['artifacts']['outlines']=artifacts;(dbdir/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');out['calibration']=artifacts
allpins=read(E/'pins.json');allpins['Outlines']=pins;(E/'pins.json').write_text(json.dumps(allpins,indent=2)+'\n');(E/'evidence/outlines-cpu.json').write_text(json.dumps(out,indent=2)+'\n')
print('OUTLINES_PACKAGE_PASS',json.dumps({'gx':{m:x['request_reduction_percent']for m,x in out['gx'].items()},'native_median':out['native_A100']['median_reduction_percent'],'native_mean':out['native_A100']['mean_reduction_percent']}),flush=True)
