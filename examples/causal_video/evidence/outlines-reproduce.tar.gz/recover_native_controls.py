import hashlib,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;helper=P.parents[2]/'examples/wan_gx/native_container.py';ssh=['ssh','-o','ControlPath=none','-o','ConnectTimeout=10','jcm@A100'];base='/home/jcm/drperf-wan-a100-20260916/causal/outlines'
# Preserve the failed warm-cache control attempt; no latency samples are rerun.
subprocess.run(['rsync','-az','-e','ssh -o ControlPath=none', 'jcm@A100:/home/jcm/drperf-wan-a100-20260916/causal/runs/outlines-control-before.log',str(P/'native-control-before-cache-hit.log')],check=True)
subprocess.run(['rsync','-az','-e','ssh -o ControlPath=none',str(P/'validate-controls-cold.sh'),'jcm@A100:'+base+'/validate-controls-cold.sh'],check=True)
active=subprocess.check_output(ssh+['nvidia-smi --query-compute-apps=gpu_uuid,pid --format=csv,noheader'],text=True);assert 'GPU-521def15-8599-2c15-65ee-6dac40f31a64'not in active
try:
 subprocess.run(['python3',str(helper),'resume'],check=True)
 subprocess.run(ssh+['docker exec -u jma drperf-wan-native-0 bash /workspace/causal/outlines/validate-controls-cold.sh source-inference controls.json controls.npz'],check=True)
finally:subprocess.run(['python3',str(helper),'stop'],check=True)
(P/'control-cache-recovery.json').write_text(json.dumps({'reason':'Initial guarded baseline reused the native compiler cache and omitted a compilation-only joint_graph negative-infinity scalar read present in the cold calibration tape. All four unhooked ABBA processes had already completed. Only guarded controls rerun with isolated cold compiler caches so the original tape and unmodified runners remain applicable. No latency samples discarded or repeated.','guard_shell_sha256':hashlib.sha256((P/'validate-controls-cold.sh').read_bytes()).hexdigest(),'hardware_gpu':'physicalGPU1'},indent=2)+'\n')
subprocess.run(['python3',str(P/'run_native_validation.py'),'--collect-only'],check=True)
