#!/usr/bin/env bash
set -euo pipefail
ulimit -c 0
outlines_selected=$1
outlines_selected_controls=$2
outlines_selected_arrays=$3
export LD_LIBRARY_PATH=/workspace/causal/f5-tts/deps/ffmpeg/lib:/workspace/causal/sglang/cuda13_libs:/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cudnn/lib
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONHASHSEED=0 TOKENIZERS_PARALLELISM=false HF_HUB_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1
export HF_HOME=/workspace/causal/hf-cache LOCAL_FILES_ONLY=true
export FLASHINFER_DISABLE_VERSION_CHECK=1 VLLM_USE_V1=1 VLLM_WORKER_MULTIPROC_METHOD=spawn VLLM_ATTENTION_BACKEND=FLASH_ATTN
export TORCHINDUCTOR_CACHE_DIR=/workspace/causal/outlines/cache-native/inductor
export TRITON_CACHE_DIR=/workspace/causal/outlines/cache-native/triton
export TORCHINDUCTOR_COMPILE_THREADS=2
unset LD_PRELOAD GX_PREDICT_DB GX_PROFILE_SO GX_PROFILE_START_FILE GX_PROFILE_STOP_FILE
for outlines_side in before after; do
 outlines_source=source
 outlines_controls=controls.json
 outlines_arrays=controls.npz
 if [[ $outlines_side == after ]]; then
  outlines_source=$outlines_selected
  outlines_controls=$outlines_selected_controls
  outlines_arrays=$outlines_selected_arrays
 fi
 export PYTHONPATH=/workspace/causal/outlines/$outlines_source/src:/workspace/causal/outlines/deps:/workspace/causal/zipvoice/deps:/workspace/causal/soprano/deps:/workspace/causal/f5-tts/deps:/workspace/causal/qwen-tts/deps:/workspace/causal/qwen-tts/source:/workspace/causal/fastgen/deps:/workspace/causal/fastgen/source:/workspace/causal/omni/source:/workspace/causal/omni/extras:/workspace/causal/omni/deps:/workspace/causal/wan2gp/deps:/workspace/causal/wanwrapper/deps:/workspace/causal/sglang/cutlass:/workspace/causal/sglang/cutlass/nvidia_cutlass_dsl/dsl_packages:/workspace/causal/sglang/deps:/workspace/causal/sglang/kernel:/workspace/causal/sglang/source/python:/workspace/causal/deps:/workspace/causal/scope-deps:/workspace/causal/flashdreams-deps:/workspace/deps
 outlines_runner=runner.py
 [[ $outlines_side == before ]] || outlines_runner=runner-inference.py
 export TORCHINDUCTOR_CACHE_DIR=/workspace/causal/outlines/cache-native/guard-$outlines_side/inductor
 export TRITON_CACHE_DIR=/workspace/causal/outlines/cache-native/guard-$outlines_side/triton
 outlines_out=/workspace/causal/runs/outlines-control-$outlines_side-cold
 [[ ! -e $outlines_out ]]
 timeout -k 20 900 python3 -u /workspace/causal/outlines/$outlines_runner --model /workspace/causal/models/Outlines-SmolLM2 --output "$outlines_out" --role native --controls /workspace/causal/outlines/"$outlines_controls" --control-arrays /workspace/causal/outlines/"$outlines_arrays" --warmup 1 --repetitions 1 > "$outlines_out.log" 2>&1
 printf 'OUTLINES_NATIVE_CONTROL_PASS %s\n' "$outlines_side"
done
