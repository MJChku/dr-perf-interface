import hashlib,json,urllib.request,shutil
from pathlib import Path
P=Path(__file__).resolve().parent;repo='HuggingFaceTB/SmolLM2-135M';rev='93efa2f097d58c2a74874c7e644dbc9b0cee75a2';root=Path('/home/ubuntu/gx-ix14/causal/models/Outlines-SmolLM2');root.mkdir(parents=True,exist_ok=True)
with urllib.request.urlopen(f'https://huggingface.co/api/models/{repo}/revision/{rev}?blobs=true')as inp:meta=json.load(inp)
(P/'model-metadata.json').write_text(json.dumps(meta,indent=2)+'\n');files=[]
for x in meta['siblings']:
 n=x['rfilename']
 if n not in ('model.safetensors','config.json','generation_config.json','tokenizer.json','tokenizer_config.json','special_tokens_map.json','merges.txt','vocab.json'):continue
 f=root/n
 if not f.exists():
  with urllib.request.urlopen(f'https://huggingface.co/{repo}/resolve/{rev}/{n}',timeout=180)as inp,f.with_suffix('.download').open('wb')as out:shutil.copyfileobj(inp,out,4*1024*1024)
  f.with_suffix('.download').replace(f)
 with f.open('rb')as inp:h=hashlib.file_digest(inp,'sha256').hexdigest()
 assert f.stat().st_size==x['size']
 if 'lfs'in x:assert h==x['lfs']['sha256']
 files.append({'repository':repo,'revision':rev,'path':n,'bytes':f.stat().st_size,'sha256':h});print('OUTLINES_MODEL_VERIFIED',n,f.stat().st_size,flush=True)
(P/'model-manifest.json').write_text(json.dumps({'root':str(root),'files':files},indent=2)+'\n')
