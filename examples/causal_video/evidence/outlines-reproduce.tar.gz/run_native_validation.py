"""Selected final native ABBA validation, GPU1 only if idle; retain all samples."""
import hashlib,json,shlex,statistics,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[2];base='/home/jcm/drperf-wan-a100-20260916/causal/outlines';ssh=['ssh','-o','ControlPath=none','-o','ConnectTimeout=10','-o','ConnectionAttempts=3','jcm@A100'];rsync=['rsync','-az','-e','ssh -o ControlPath=none -o ConnectTimeout=10 -o ConnectionAttempts=3']
selected=json.loads((P/'selected.json').read_text());assert selected['source'] in ('source-inference',);a=json.loads((P/(selected['audit']+'-audit.json')).read_text());assert a['result']['passed'] and not a['result']['cleanup_errors']
checks={k:v for k,v in json.loads((P/'native-identities.json').read_text()).items()if '/causal/outlines/'in k or '/models/Outlines-SmolLM2/'in k}
for folder in (selected['source'],):
 dest=base+'/'+folder;subprocess.run(ssh+['mkdir -p '+shlex.quote(dest)],check=True)
 sender=subprocess.Popen(['tar','--exclude=__pycache__','-C',str(P/folder),'-cf','-','.'],stdout=subprocess.PIPE)
 try:subprocess.run(ssh+['tar --no-same-owner -C '+shlex.quote(dest)+' -xf -'],stdin=sender.stdout,check=True)
 finally:sender.stdout.close()
 assert sender.wait()==0
 for f in (P/folder).rglob('*'):
  if f.is_file()and'__pycache__'not in f.parts:checks[dest+'/'+str(f.relative_to(P/folder))]=hashlib.sha256(f.read_bytes()).hexdigest()
for name in set(('runner.py','runner-inference.py','validate-native.sh','controls.json','controls.npz',selected['controls'],selected['control_arrays'])):
 subprocess.run(rsync+[str(P/name),'jcm@A100:'+base+'/'+name],check=True);checks[base+'/'+name]=hashlib.sha256((P/name).read_bytes()).hexdigest()
script='''import hashlib,json
for name,expected in json.loads(%r).items():
 with open(name,'rb')as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==expected,name
print('OUTLINES_NATIVE_IDENTITIES_PASS')
'''%json.dumps(checks)
(P/'verify-native-identities.py').write_text(script)
subprocess.run(rsync+[str(P/'verify-native-identities.py'),'jcm@A100:'+base+'/verify-native-identities.py'],check=True)
subprocess.run(ssh+['python3 '+base+'/verify-native-identities.py'],check=True,timeout=90);(P/'native-validation-identities.json').write_text(json.dumps(checks,indent=2)+'\n')
active=subprocess.check_output(ssh+['nvidia-smi --query-compute-apps=gpu_uuid,pid --format=csv,noheader'],text=True);assert 'GPU-521def15-8599-2c15-65ee-6dac40f31a64'not in active,active
hardware={'gpu_inventory':subprocess.check_output(ssh+['nvidia-smi --query-gpu=index,name,uuid,driver_version,memory.total --format=csv'],text=True),'active_compute_processes':active,'device_requests':json.loads(subprocess.check_output(ssh+['docker inspect --format "{{json .HostConfig.DeviceRequests}}" drperf-wan-native-0'],text=True))};hardware['cpu']=json.loads(subprocess.check_output(ssh+['lscpu -J'],text=True));assert hardware['device_requests'][0]['DeviceIDs']==['1'];(P/'native-validation-hardware.json').write_text(json.dumps(hardware,indent=2)+'\n')
helper=R/'examples/wan_gx/native_container.py';reports=[];collect='--collect-only'in sys.argv
try:
 if not collect:
  subprocess.run(['python3',str(helper),'resume'],check=True)
  subprocess.run(ssh+['docker exec -u jma drperf-wan-native-0 bash /workspace/causal/outlines/validate-native.sh '+ ' '.join(shlex.quote(selected[k]) for k in ('source','controls','control_arrays'))],check=True)
 for i,side in enumerate(('before','after','after','before'),1):
  target=P/f'native-plain-{i}-{side}.json';subprocess.run(rsync+[f'jcm@A100:/home/jcm/drperf-wan-a100-20260916/causal/runs/outlines-plain-{i}-{side}/report.json',str(target)],check=True);d=json.loads(target.read_text());assert d['phase']=='completed'and d['plain'];reports.append({'side':side,'report':d})
 controls=[]
 for side in ('before','after'):
  target=P/f'native-control-{side}.json';subprocess.run(rsync+[f'jcm@A100:/home/jcm/drperf-wan-a100-20260916/causal/runs/outlines-control-{side}-cold/report.json',str(target)],check=True);d=json.loads(target.read_text());assert d['phase']=='completed'and not d['plain']and all(x['native_shape_checked']for x in d['fft_adapters']);controls.append({'side':side,'report':d})
 measured=[r for x in reports for r in x['report']['iterations']];warmups=[{'side':x['side'],'process_index':i,**r}for i,x in enumerate(reports,1)for r in x['report']['warmups']];expected=json.loads((P/'kernel-profile.json').read_text())['iterations'][0]['output_sha256'];hashes={r['output_sha256']for r in measured};assert hashes=={expected}and all(r['finite']for r in measured),hashes
 summary={}
 for side in ('before','after'):
  vals=[r['application_clock_seconds']for x in reports if x['side']==side for r in x['report']['iterations']];assert len(vals)==14;summary[side]={'samples':vals,'median':statistics.median(vals),'mean':statistics.mean(vals),'min':min(vals),'max':max(vals)}
 summary.update(reports=reports,control_reports=controls,output_sha256=expected,measured_output_checks=len(measured),warmup_checks=warmups,warmup_hash_differences=[r for r in warmups if r['output_sha256']!=expected],scope='Unprofiled native original API with no tensor/FFT hooks. ABBA3warmups7measured/process,all28measured samples retained. Separate guarded pair checks scalar/CPU-array controls and actual native FFT shapes; guarded timing excluded.')
 for stat in ('median','mean'):summary[stat+'_reduction_percent']=100*(1-summary['after'][stat]/summary['before'][stat])
 (P/'native-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('OUTLINES_NATIVE_PASS',summary['median_reduction_percent'],flush=True)
finally:
 if not collect:subprocess.run(['python3',str(helper),'stop'],check=True)
