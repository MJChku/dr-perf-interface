import ast,hashlib,importlib.util,json,os,types
from pathlib import Path
import torch
from outlines.models.transformers import Transformers as Original
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('candidate_transformers',P/'source-inference/src/outlines/models/transformers.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);Candidate=mod.Transformers
cases=0
for library in ('torch','jax'):
 for encoder_decoder in (False,True):
  for enabled in (False,True):
   observations=[]
   class Model:
    config=types.SimpleNamespace(is_encoder_decoder=encoder_decoder)
    @torch.no_grad()
    def generate(self,**kwargs):
     observations.append((torch.is_grad_enabled(),torch.is_inference_mode_enabled()));return torch.arange(14).reshape(2,7)
   a=Original.__new__(Original);a.model=Model();b=Candidate.__new__(Candidate);b.model=Model();b.tensor_library_name=library;b.inference_mode=enabled
   inputs={'input_ids':torch.zeros(2,3,dtype=torch.long)};x=a._generate_output_seq(None,inputs);y=b._generate_output_seq(None,inputs);assert torch.equal(x,y);assert observations==[(False,False),(False,library=='torch'and enabled)];assert not torch.is_inference_mode_enabled()and torch.is_grad_enabled();cases+=1
class BadModel:
 config=types.SimpleNamespace(is_encoder_decoder=False)
 def generate(self,**kwargs):assert torch.is_inference_mode_enabled();raise ValueError('expected')
b=Candidate.__new__(Candidate);b.model=BadModel();b.tensor_library_name='torch';b.inference_mode=True
try:b._generate_output_seq(None,{'input_ids':torch.zeros(1,1,dtype=torch.long)})
except ValueError:pass
else:raise AssertionError('exception lost')
assert not torch.is_inference_mode_enabled()and torch.is_grad_enabled();cases+=1
# The two benchmark harnesses differ only in the opt-in load-time keyword.
left=(P/'runner.py').read_text();right=(P/'runner-inference.py').read_text();assert right==left.replace('wrapper=outlines.from_transformers(network,tokenizer);','wrapper=outlines.from_transformers(network,tokenizer,inference_mode=True);')
for function in ('generate','check'):
 def node(text):return next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef)and n.name==function)
 assert ast.dump(node(left))==ast.dump(node(right))
out={'passed':True,'cases':cases,'scope':'Actual wrapper methods with deterministic toy generation: encoder/decoder-only outputs,default/opt-in flags,other-backend guard and exception context restoration. Identical timed generate/check ASTs; runner-inference differs only in load-time opt-in argument. Full pretrained model A100 output validation remains required.','patch_sha256':hashlib.sha256((P/'inference-mode.patch').read_bytes()).hexdigest()}
Path(os.environ.get('ORACLE_OUTPUT',str(P/'inference-oracle.json'))).write_text(json.dumps(out,indent=2)+'\n');print('OUTLINES_INFERENCE_ORACLE_PASS',json.dumps(out),flush=True)
