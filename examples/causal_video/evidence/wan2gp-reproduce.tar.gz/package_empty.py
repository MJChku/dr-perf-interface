"""Record matched GX/native measurements, retaining every validation sample."""
import gzip, hashlib, json, shutil, statistics, sys, tarfile
from collections import Counter
from pathlib import Path
P=Path(__file__).resolve().parent; E=P.parents[2]/'examples/causal_video'
sys.path.insert(0,str(E))
from compact_gx_trace import compact
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def reduced(r): return {k:v for k,v in r.items() if k!='source_sha256'}
def inventory(rows): return Counter({(r['name'],tuple(r['grid']),tuple(r['block'])):r['count'] for r in rows})
pins=read(P/'pins.json');pins['runner_sha256']=sha(P/'runner.py');pins['mmgp_candidate_sha256']=sha(P/'mmgp-empty/mmgp/offload.py');(P/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
out={
 'system':'Wan2GP with MMGP 3.8.0','pins':pins,
 'workload':pins['configuration'],
 'change':'Opt-in guard in MMGP ensure_model_loaded skips unload_all when active_models_ids is empty. Existing active incompatible models are still unloaded; ordinary garbage collection and request-boundary cleanup remain enabled.',
 'flag':'MMGP_SKIP_EMPTY_UNLOAD=0 versus 1; identical patched package in both variants.',
 'gx':{},'native_A100':{},'traces':{},'gc_diagnostic':read(P/'narrow-cpu.json'),
 'limitations':[
  'GX functional emulation does not compute model outputs; native validation compares returned uint8 videos. Equality after quantization does not establish prequantization finiteness or exact intermediate equality.',
  'Repeated fixed prompt after warmup; public generation including sampling, VAE decode and CPU uint8 output. No UI, queue, previews, or file encoding. Quantization, adapters, alternative attention, concurrent requests and arbitrary model transitions are not validated.',
  'Skipping redundant empty unload also skips allocator-cache clearing and resets of the memory-check clock at that call. Other cleanups remain. This workload has unchanged measured memory peaks; this is not a proof for memory pressure from unrelated allocations.',
  'GX CPU calibration: 10829 resolved and 225 unresolved samples (2.04% unresolved). GX host EPYC 7702P differs from native A100 host EPYC 9554.',
  'cuDNN plans and/or malformed launch dimensions differ between runs. Misses receive zero modeled compute cost; launch-count coverage is not time coverage.',
  'Known-control adapters retain original GPU operations, then substitute tokenizer-derived lengths and CPU-derived sequential Euler indices for emulation. Native execution asserts agreement. No CFG-star or self-refinement is used.',
  'Physical GPU1 was idle before validation; unrelated GPU0 work can share host resources.',
 ]}
for mode,prefix in [('mode2','empty'),('mode3','empty-sync')]:
 records={};audits={}
 for side in ('before','after'):
  a=read(P/f'{prefix}-{side}-audit.json');audits[side]=a
  assert a['result']['passed'] and not a['result']['cleanup_errors']
  assert a['model']['runner_sha256']==pins['runner_sha256']
  assert a['model']['mmgp_offload_sha256']==pins['mmgp_candidate_sha256']
  assert a['model']['skip_empty_unload']==(side=='after')
  if 'source_sha256' not in out:out['source_sha256']=a['model']['source_sha256']
  assert out['source_sha256']==a['model']['source_sha256']
  records[side]={k:a[k] for k in ('run','result','summary','iterations','misses','gpu_db_sha256','cpu_db_sha256')}
  records[side]['model']=reduced(a['model']);records[side]['mean_seconds']=statistics.mean(i['virtual_seconds'] for i in a['iterations'])
  src=Path(a['run'])/'timeline-report/trace.json.gz';dst=E/f'evidence/wan2gp-{mode}-{side}.chrome.json.gz'
  out['traces'][side if mode=='mode2' else mode+'_'+side]={'file':dst.name,'full_trace':str(src),**compact(src,dst,bin_ms=10)}
 assert records['before']['summary']['copies']==records['after']['summary']['copies']
 records['reduction_percent']=100*(1-records['after']['mean_seconds']/records['before']['mean_seconds'])
 records['full_compute_inventories_match']=audits['before']['launches']==audits['after']['launches']
 records['predicted_compute_inventories_match']=(inventory(audits['before']['launches'])-inventory(audits['before']['misses'])==inventory(audits['after']['launches'])-inventory(audits['after']['misses']))
 out['gx'][mode]=records
reports=[]
for i,side in enumerate(('before','after','after','before'),1):
 r=read(P/f'native-empty-{i}-{side}.json');assert r['phase']=='completed' and len(r['iterations'])==5
 assert r['source_sha256']==out['source_sha256'] and r['runner_sha256']==pins['runner_sha256']
 assert r['mmgp_offload_sha256']==pins['mmgp_candidate_sha256'] and r['skip_empty_unload']==(side=='after')
 assert all(c['native_checked'] for c in r['control_checks'] if c['kind']=='euler_index')
 reports.append(reduced(r)|{'variant':side})
assert {i['output_sha256'] for r in reports for i in r['iterations']}=={'2ef215e1f7218c765debfcbd5fd28bf1ce2876aac67bee3fa154281bf8aef7a2'}
n={'status':'complete','process_order':['before','after','after','before'],'warmup_per_process':2,'repetitions_per_process':5,'reports':reports,'all_20_output_hashes_identical':True,'hardware':read(P/'native-empty-hardware.json')}
for side in ('before','after'):
 rs=[r for r in reports if r['variant']==side];times=[i['application_clock_seconds'] for r in rs for i in r['iterations']]
 n[side]={'seconds':times,'mean_seconds':statistics.mean(times),'median_seconds':statistics.median(times)}
 for key in ('peak_host_rss_bytes','peak_gpu_bytes','peak_reserved_gpu_bytes'):n[side][key]=[r[key] for r in rs]
for stat in ('mean','median'):n[stat+'_reduction_percent']=100*(1-n['after'][stat+'_seconds']/n['before'][stat+'_seconds'])
out['native_A100']=n
out['additional_screen']=read(P/'seqlens-screen.json')
shutil.copyfile(P/'mmgp-empty-unload.patch',E/'cpu_patches/wan2gp_empty_unload.patch');shutil.copyfile(P/'runner.py',E/'wan2gp_runner.py')
out['patch']={'file':'../cpu_patches/wan2gp_empty_unload.patch','sha256':sha(P/'mmgp-empty-unload.patch')}
names=['runner.py','runner-calibration.py','runner_narrow.py','mmgp-empty-unload.patch','run_empty_pair.py','run_empty_sync_pair.py','run_native_empty.py','validate-empty-native.sh','empty-before.json','empty-after.json','empty-sync-before.json','empty-sync-after.json','partial.json','cpu.json','narrow.json','pins.json','cpu-calibration.json','native-empty-hardware.json','native-control.json','rejected-controls.json','audit.py','package_empty.py','runner_seqlens.py','flash-seqlens.patch','seqlens-before.json','seqlens-after.json','run_seqlens_pair.py','seqlens-screen.json']
bundle=E/'evidence/wan2gp-reproduce.tar.gz'
with tarfile.open(bundle,'w:gz') as tar:
 for name in names:tar.add(P/name,arcname=name)
out['reproduction']={'file':bundle.name,'sha256':sha(bundle),'files':names,'note':'Install pinned dependencies and apply patch to MMGP 3.8.0. Adjust asset/host paths. Reuses original native kernel database; shared launcher and audit utilities remain in this repository.'}
dbdir=E/'evidence/kernel-databases';m=read(dbdir/'manifest.json');calibration={}
for key,src,dest in [('database','gpu.sqlite','wan2gp-wan.sqlite.gz'),('native_report','kernel-profile.json','wan2gp-wan.report.json.gz'),('cpu_instruction_calibration','cpu.db','wan2gp-wan.cpu.db.gz')]:
 raw=(P/src).read_bytes();target=dbdir/dest;target.write_bytes(gzip.compress(raw,compresslevel=9,mtime=0));assert gzip.decompress(target.read_bytes())==raw
 calibration[key]={'file':dest,'source':str(P/src),'uncompressed_bytes':len(raw),'uncompressed_sha256':sha(P/src),'gzip_sha256':sha(target)}
calibration['scope']=out['workload'];out['calibration']=calibration;m['artifacts']['wan2gp-wan']=calibration
(dbdir/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');(E/'evidence/wan2gp-cpu.json').write_text(json.dumps(out,indent=2)+'\n')
print('WAN2GP_PACKAGE_PASS',{mode:r['reduction_percent'] for mode,r in out['gx'].items()},{stat:n[stat+'_reduction_percent'] for stat in ('mean','median')})
