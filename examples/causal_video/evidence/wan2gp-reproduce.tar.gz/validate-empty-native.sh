#!/usr/bin/env bash
set -euo pipefail
ulimit -c 0
export PYTHONPATH=/workspace/causal/wan2gp/mmgp-empty:/workspace/causal/wan2gp/deps:/workspace/causal/wanwrapper/deps:/workspace/causal/sglang/cutlass:/workspace/causal/sglang/cutlass/nvidia_cutlass_dsl/dsl_packages:/workspace/causal/sglang/deps:/workspace/causal/sglang/kernel:/workspace/causal/wanwrapper/deps:/workspace/causal/deps:/workspace/causal/scope-deps:/workspace/causal/flashdreams-deps:/workspace/deps
export LD_LIBRARY_PATH=/workspace/causal/sglang/cuda13_libs:/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cudnn/lib
export LD_PRELOAD=/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cublas/lib/libcublas.so.12:/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cublas/lib/libcublasLt.so.12
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONHASHSEED=0 TOKENIZERS_PARALLELISM=false HF_HUB_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1
export FLASHINFER_DISABLE_VERSION_CHECK=1
index=0
for side in before after after before; do
  index=$((index+1))
  busy=$(nvidia-smi -i GPU-521def15-8599-2c15-65ee-6dac40f31a64 --query-compute-apps=pid --format=csv,noheader)
  [[ -z "$busy" ]] || { echo "GPU1 busy at boundary"; exit 1; }
  result=/workspace/causal/runs/wan2gp-empty-${index}-${side}
  [[ ! -e "$result" ]]
  export MMGP_SKIP_EMPTY_UNLOAD=0
  if [[ "$side" == after ]]; then export MMGP_SKIP_EMPTY_UNLOAD=1; fi
  timeout -k 20 1200 python3 -u /workspace/causal/wan2gp/runner.py \
    --source /workspace/causal/wan2gp/source --model /workspace/checkpoint \
    --output "$result" --role native --warmup 2 --repetitions 5 \
    --frames 17 --steps 8 > "${result}.log" 2>&1
  echo "NATIVE_GROUP_PASS ${index} ${side}"
done
