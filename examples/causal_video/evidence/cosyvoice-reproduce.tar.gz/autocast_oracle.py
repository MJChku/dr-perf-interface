import ast,hashlib,json
from pathlib import Path
import torch
P=Path(__file__).resolve().parent;torch.set_num_threads(1);torch.manual_seed(42)
# Confirm the only program edit is its gradient-mode decorator.
a=ast.parse((P/'source/cosyvoice/llm/llm.py').read_text());b=ast.parse((P/'source-autocast/cosyvoice/llm/llm.py').read_text());cls=lambda t:next(x for x in t.body if isinstance(x,ast.ClassDef)and x.name=='Qwen2LM');fn=lambda t:next(x for x in cls(t).body if isinstance(x,ast.FunctionDef)and x.name=='inference_bistream');fn(b).decorator_list=fn(a).decorator_list;assert ast.dump(a)==ast.dump(b)
model=torch.nn.Sequential(torch.nn.Linear(32,64),torch.nn.SiLU(),torch.nn.Linear(64,32)).eval();x=torch.randn(2,32);rows={};outputs={}
for name,context in [('inference_mode',torch.inference_mode),('no_grad',torch.no_grad)]:
 with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU])as prof:
  with torch.autocast('cpu',dtype=torch.bfloat16):
   for _ in range(12):
    with context():
     value=model(x);assert not value.requires_grad
     outputs.setdefault(name,[]).append(value.clone())
 rows[name]={e.key:e.count for e in prof.key_averages()if e.key=='aten::_to_copy'}
assert all(torch.equal(a,b)for a,b in zip(outputs['inference_mode'],outputs['no_grad']))
assert rows['no_grad']['aten::_to_copy']<rows['inference_mode']['aten::_to_copy']
r={'passed':True,'torch':torch.__version__,'only_decorator_changed':True,'exact_forward_comparisons':12,'cast_counts':rows,'patch_sha256':hashlib.sha256((P/'autocast-cache.patch').read_bytes()).hexdigest(),'scope':'CPU BF16 autocast mechanism probe with FP32 linear weights and the same generator-style context boundaries. No output gradients; exact values across12forwards. Full CosyVoice GPU correctness and GX performance still require evaluation.','upstream_source':'https://github.com/pytorch/pytorch/blob/v2.11.0/aten/src/ATen/autocast_mode.cpp'}
(P/'autocast-oracle.json').write_text(json.dumps(r,indent=2)+'\n');print('COSYVOICE_AUTOCAST_ORACLE_PASS',json.dumps(r))
