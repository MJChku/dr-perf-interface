#!/usr/bin/env bash
set -euo pipefail
ulimit -c 0
base=/workspace/causal/runs/cosyvoice-kernels2
[[ ! -e "$base" && ! -e "$base.start" && ! -e "$base.stop" ]]
export PYTHONPATH=/workspace/causal/cosyvoice/source:/workspace/causal/cosyvoice/deps:/workspace/causal/diffsynth/deps:/workspace/causal/cosyvoice/source:/workspace/causal/cosyvoice/deps:/workspace/causal/zipvoice/deps:/workspace/causal/soprano/deps:/workspace/causal/f5-tts/deps:/workspace/causal/qwen-tts/deps:/workspace/causal/qwen-tts/source:/workspace/causal/fastgen/deps:/workspace/causal/fastgen/source:/workspace/causal/omni/source:/workspace/causal/omni/extras:/workspace/causal/omni/deps:/workspace/causal/wan2gp/deps:/workspace/causal/wanwrapper/deps:/workspace/causal/sglang/cutlass:/workspace/causal/sglang/cutlass/nvidia_cutlass_dsl/dsl_packages:/workspace/causal/sglang/deps:/workspace/causal/sglang/kernel:/workspace/causal/sglang/source/python:/workspace/causal/deps:/workspace/causal/scope-deps:/workspace/causal/flashdreams-deps:/workspace/deps
export LD_LIBRARY_PATH=/workspace/causal/f5-tts/deps/ffmpeg/lib:/workspace/causal/sglang/cuda13_libs:/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cudnn/lib
export LD_PRELOAD=/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cublas/lib/libcublas.so.12:/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cublas/lib/libcublasLt.so.12
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONHASHSEED=0 TOKENIZERS_PARALLELISM=false HF_HUB_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1
export HF_HUB_DISABLE_PROGRESS_BARS=1 TQDM_DISABLE=1
export HF_HOME=/workspace/causal/hf-cache LOCAL_FILES_ONLY=true
export FLASHINFER_DISABLE_VERSION_CHECK=1 VLLM_USE_V1=1 VLLM_WORKER_MULTIPROC_METHOD=spawn VLLM_ATTENTION_BACKEND=FLASH_ATTN
export TORCHINDUCTOR_CACHE_DIR=/workspace/causal/cosyvoice/cache-native/inductor
export TRITON_CACHE_DIR=/workspace/causal/cosyvoice/cache-native/triton
export TORCHINDUCTOR_COMPILE_THREADS=2
export GX_PROFILE_SO=/workspace/causal/sglang/gx_profile.so
export GX_PROFILE_DB=${base}.sqlite
export GX_PROFILE_START_FILE=${base}.start GX_PROFILE_STOP_FILE=${base}.stop
export GX_PROFILE_MODE=isolated GX_PROFILE_WARMUP=0 GX_PROFILE_SAMPLES=3
exec timeout -k 20 1800 bash /workspace/causal/runtime/gx_profile_run.sh \
 python3 -u /workspace/causal/cosyvoice/runner.py \
 --model /workspace/causal/models/CosyVoice2 \
 --output "$base" --role gpu-profile --warmup 2 > "$base.log" 2>&1
