import json,statistics,subprocess,time
from pathlib import Path
P=Path(__file__).resolve().parent
oracle=json.loads((P/'mask-none-oracle.json').read_text())
assert oracle['passed'] and oracle['torch']=='2.11.0+cu128' and oracle['transformers']=='4.57.3'
for _ in range(1800):
    if 'COSYVOICE_SELECTED_GX_PASS' in (P/'selected-controller.log').read_text():break
    time.sleep(2)
else:raise RuntimeError('Selected comparison did not complete')
subprocess.run(['python3',str(P/'run_timing.py'),'mask-none-after'],check=True)
read=lambda n:json.loads((P/(n+'-audit.json')).read_text())
b=read('partial');a=read('mask-none-after');screen={}
for key,field in [('client_iterations','virtual_seconds'),('gpu_worker_iterations','cpu_seconds')]:
    before=statistics.mean(x[field] for x in b[key]);after=statistics.mean(x[field] for x in a[key])
    screen[key]={'before':before,'after':after,'reduction_percent':100*(1-after/before)}
screen['native_validation']=False;screen['mode3_validation']=False
(P/'mask-none-after-screen.json').write_text(json.dumps(screen,indent=2)+'\n')
print('MASK_NONE_GX_SCREEN',json.dumps(screen),flush=True)
