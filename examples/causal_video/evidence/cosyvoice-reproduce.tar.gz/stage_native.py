"""Stage pinned CosyVoice2 assets and verify reused dependencies; no GPU use."""
import hashlib,json,shlex,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;host='/home/jcm/drperf-wan-a100-20260916/causal'
base=host+'/cosyvoice';ssh=['ssh','-o','ControlPath=none','-o','ServerAliveInterval=10','-o','ServerAliveCountMax=3','-o','ConnectTimeout=10','-o','ConnectionAttempts=3','jcm@A100']
manifest=json.loads((P/'model-manifest.json').read_text());model=Path(manifest['root']);native_model=host+'/models/'+model.name
def digest(f):
 with f.open('rb')as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
need=(0 if (P/'native-identities.json').exists() else sum(x['bytes']for x in manifest['files']))+sum(f.stat().st_size for f in (P/'deps').rglob('*')if f.is_file())
subprocess.run(ssh+['python3 -'],input='import shutil; f=shutil.disk_usage(%r).free;assert f>%d+2000000000,(f,%d)'%(host,need,need),text=True,check=True)
subprocess.run(ssh+['mkdir -p '+shlex.quote(base+'/cache-native')+' && chmod 0777 '+shlex.quote(base+'/cache-native')],check=True)
checks={}
for other in ('qwen-tts','fastgen','f5-tts','soprano','zipvoice','chatterbox','diffsynth'):
 identity=P.parent/other/('async-native-identities.json'if other=='diffsynth'else'native-identities.json');inherited=json.loads(identity.read_text());checks.update({k:v for k,v in inherited.items()if '/causal/'+other+'/deps/' in k})
for folder,dest in [(P/'source',base+'/source'),(P/'deps',base+'/deps'),(model,native_model)]:
 subprocess.run(ssh+['mkdir -p '+shlex.quote(dest)],check=True)
 subprocess.run(['rsync','-az','--exclude=.git','--exclude=__pycache__','-e','ssh -o ControlPath=none',str(folder)+'/', 'jcm@A100:'+dest+'/'],check=True)
 for f in folder.rglob('*'):
  if f.is_file() and '.git' not in f.parts and '__pycache__' not in f.parts:checks[dest+'/'+str(f.relative_to(folder))]=digest(f)
 print('COSYVOICE_NATIVE_STAGED',dest,flush=True)
for name in ('runner.py','profile.sh'):
 subprocess.run(['rsync','-az','-e','ssh -o ControlPath=none -o ConnectTimeout=10 -o ConnectionAttempts=3',str(P/name),'jcm@A100:'+base+'/'+name],check=True)
 checks[base+'/'+name]=digest(P/name)
script='''import hashlib,json
checks=json.loads(%r)
for name,expected in checks.items():
 with open(name,'rb')as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==expected,name
print('COSYVOICE_NATIVE_IDENTITIES_PASS',len(checks))
'''%json.dumps(checks)
(P/'verify-native-identities.py').write_text(script)
subprocess.run(['rsync','-az','-e','ssh -o ControlPath=none',str(P/'verify-native-identities.py'),'jcm@A100:'+base+'/verify-native-identities.py'],check=True)
subprocess.run(ssh+['python3 '+base+'/verify-native-identities.py'],check=True,timeout=180)
(P/'native-identities.json').write_text(json.dumps(checks,indent=2)+'\n')
