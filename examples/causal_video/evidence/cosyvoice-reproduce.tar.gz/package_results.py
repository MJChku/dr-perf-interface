"""Publish matched GX predictions and independent A100 validation."""
import gzip, hashlib, json, shutil, statistics, subprocess, sys, tarfile, tempfile
from collections import Counter
from pathlib import Path
P=Path(__file__).resolve().parent; E=P.parents[2]/'examples/causal_video'
sys.path.insert(0,str(E))
from compact_gx_trace import compact
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
progress=read(P/'progress.json'); initial=read(P/'kernel-profile.json')
pins={'source':progress['source'],'model':read(P/'model-manifest.json'),
      'dependencies':initial['versions'],'request':initial['request'],'scope':initial['scope']}
(P/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
limits=[
 'One pretrained CosyVoice2-0.5B request: official four-chunk Chinese text generator, cached reference speaker, original RAS sampler, seed42, batched audio output. Output285120samples at24kHz(11.88s). Includes tokenization, native Qwen2 LLM thread, flow, HiFT, output transfer and request-end synchronization/allocator clear; excludes model load, cached reference extraction and file encoding.',
 'Pinned Torch2.11.0+cu128,Transformers4.57.3. FP16 option means autocast over FP32 parameters. Original inference_mode disables Torch2.11 weight-cast caching; replacing it with no_grad permits reuse within the existing outer autocast context. This changes CPU dispatch AND GPU conversion work, and retains additional half-precision weights. It is not a pure CPU-instruction reduction or a general guarantee for other Torch versions, frozen parameters or outer inference_mode callers.',
 'Only Qwen2LM.inference_bistream decorator changes. CosyVoice3 inherits this method but is not evaluated; nonstreaming text and vLLM/compiled backends are not evaluated. no_grad suppresses output gradients while retaining ordinary tensor/version semantics.',
 'GX performs no GPU arithmetic. Native scalar/list/CPU-array controls are replayed after original transfers/waits. Native plain timings restore all tensor/arange/FFT hooks. A separate guarded native pair checks the same control values and real FFT shapes.',
 'Replay-hook Python bookkeeping is included in these GX CPU timings; unhooked native timings remove it. The separate guarded native checks take4.850981/4.799923s(before/after),but are single diagnostic requests,not latency statistics or a correction for GX. Thus GX CPU time is not solely unmodified application work.',
 'GX cuFFT fails with CUFFT_INTERNAL_ERROR in this workload; native-recorded shape substitution omits FFT and associated GPU work. Baseline has330native-only launches/request with1.882822ms sum of isolated medians,not an end-to-end correction. Prediction misses and changed launch inventories are recorded without filling unsupported timing entries.',
 'Mode2 uses separate clocks for caller and newly spawned LLM thread. Report caller-marked request intervals; raw worker spans, especially the second request, are not latencies. Worker CPU execution is reported separately. Mode3 globally synchronizes threads with10us epochs. Timeline occupancy is simulated interval coverage,not hardware utilization.',
 'CPU calibration has1847unresolved of44356instruction samples(4.164%). CPU hosts differ between GX and A100. Predictions require reading alongside hardware validation; no new kernel profiling is used during candidate exploration.',
 'Mode3 baseline has two malformed cuDNN tensorTransformGeneric launches(grid697008384,block544) and a different convolution choice; candidate has four unmatched transform/xmma launches. This pair is coverage-limited,not matched-kernel. Mode2 variants have identical non-cast launch inventories. See cudnn-coverage.json and the existing GX cuDNN issue. No guessed geometry aliases or timing correction.',
 'Mode1 candidate also has two malformed transform launches(grid262422912,block864) and a convolution-choice difference from its baseline. Its device-only comparison is likewise coverage-limited. All statements concern the archived pinned runtime,not untested newer GX revisions.',
 'Native ABBA processes use3warmups and5measured requests each,10pervariant. All20measured samples retained; all warmups and guarded checks retained separately. One input/seed is not general correctness proof.',
]
out={'system':'CosyVoice2','pins':pins,'change':'Allow the existing autocast weight cache to reuse FP16 weight conversions during text-streaming generation by changing one decorator from inference_mode to no_grad.',
     'gx':{},'traces':{},'limitations':limits,'kernel_calibration':read(P/'kernel-calibration.json'),
     'native_kernel_calibration':initial,'cpu_calibration':read(P/'cpu-calibration.json'),
     'baseline_omissions':read(P/'omissions.json'),'cpu_mechanism_oracle':read(P/'autocast-oracle.json'),
     'selection':read(P/'selected.json'),'launch_changes':read(P/'autocast-launch-delta.json'),'cudnn_coverage':read(P/'cudnn-coverage.json')}
for mode,names in [('mode2',('partial','autocast-after')),('mode3',('sync-before','sync-after')),('mode1',('gpu-before','gpu-after'))]:
    pair={}
    for side,name in zip(('before','after'),names):
        a=read(P/(name+'-audit.json'))
        assert a['result']['passed'] and not a['result']['cleanup_errors']
        assert a['model']['runner_sha256']==sha(P/'runner.py')
        assert a['gpu_db_sha256']==sha(P/'gpu.sqlite')
        assert a['cpu_db_sha256']==(None if mode=='mode1' else sha(P/'cpu.db'))
        assert all(x['control_count']==12070 for x in a['model']['iterations'])
        a['runtime']=read(Path(a['run'])/'runtime.json')
        a['controller_wall_seconds']=read(P/(name+'-run.json'))['controller_wall_seconds']
        a['means']={k:statistics.mean(x[k] for x in a['client_iterations'])
                    for k in ('virtual_seconds','cpu_seconds','gpu_span_seconds','outside_gpu_spans_seconds')}
        a['means']['llm_cpu_seconds']=statistics.mean(x['cpu_seconds'] for x in a['gpu_worker_iterations'])
        pair[side]=a
        if mode!='mode1':
            src=Path(a['run'])/'timeline-report/trace.json.gz';dst=E/f'evidence/cosyvoice-{mode}-{side}.chrome.json.gz'
            prepared=read(P/'prepared-traces.json').get(mode+'_'+side) if (P/'prepared-traces.json').exists() else None
            if prepared:
                assert prepared['full_trace']==str(src) and prepared['source_sha256']==sha(src) and prepared['output_sha256']==sha(dst)
                out['traces'][mode+'_'+side]=prepared
            else:out['traces'][mode+'_'+side]={'file':dst.name,'full_trace':str(src),**compact(src,dst,bin_ms=5)}
    assert pair['before']['runtime']['dynamorio']==pair['after']['runtime']['dynamorio']
    assert pair['before']['client_iterations'][0]['copy_bytes']==pair['after']['client_iterations'][0]['copy_bytes']
    assert pair['before']['client_iterations'][0]['copy_counts']==pair['after']['client_iterations'][0]['copy_counts']
    pair['request_reduction_percent']=100*(1-pair['after']['means']['virtual_seconds']/pair['before']['means']['virtual_seconds'])
    out['gx'][mode]=pair
n=read(P/'native-summary.json');assert n['measured_output_checks']==20
for block in n['reports']:
    report=block['report'];g=out['gx']['mode2'][block['side']]['model']
    assert report['versions']==g['versions'] and report['source_sha256']==g['source_sha256']
    assert report['plain'] and report['runner_sha256']==sha(P/'runner.py')
    assert {r['output_sha256'] for r in report['iterations']}=={n['output_sha256']}
for block in n['control_reports']:
    assert {r['output_sha256'] for r in block['report']['warmups']+block['report']['iterations']}=={n['output_sha256']}
out['native_A100']=n|{'hardware':read(P/'native-validation-hardware.json')}
out['memory']={side:{k:sorted({b['report'][k] for b in n['reports'] if b['side']==side})
                    for k in ('peak_gpu_bytes','peak_reserved_gpu_bytes','peak_host_rss_bytes')}
               for side in ('before','after')}
out['additional_screens']={}
for name,oracle in [('sampling-after','sampling-oracle.json'),('mask-after','mask-oracle.json'),('mask-none-after','mask-none-oracle.json')]:
    out['additional_screens'][name]={'mode2':read(P/(name+'-screen.json')),
        'audit':read(P/(name+'-audit.json')),'cpu_oracle':read(P/oracle),
        'mode3_validation':False,'native_validation':False,'selected':False,
        'selection_reason':'Independent mode2 gain below the3%screening gate; no further GPU validation. Sampler additionally creates new prediction misses.'}
with tempfile.TemporaryDirectory(prefix='cosyvoice-patch-')as td:
    root=Path(td);shutil.copytree(P/'source/cosyvoice',root/'cosyvoice',ignore=shutil.ignore_patterns('__pycache__'))
    subprocess.run(['git','apply',str(P/'autocast-cache.patch')],cwd=root,check=True)
    assert (root/'cosyvoice/llm/llm.py').read_bytes()==(P/'source-autocast/cosyvoice/llm/llm.py').read_bytes()
out['patch_application_checked']=True
shutil.copyfile(P/'runner.py',E/'cosyvoice_runner.py')
shutil.copyfile(P/'autocast-cache.patch',E/'cpu_patches/cosyvoice_autocast_cache.patch')
files=['pins.json','runner.py','runner-calibration.py','autocast-cache.patch','autocast_oracle.py','autocast-oracle.json',
 'selected.json','autocast-launch-delta.json','model-manifest.json','CosyVoice2-0.5B-metadata.json','download_model.py','controls.json','controls.npz','speaker.pt',
 'emu.json','cpu.json','partial.json','autocast-after.json','sync-before.json','sync-after.json','gpu-before.json','gpu-after.json',
 'audit.py','run_timing.py','run_selected.py','profile.sh','run_native_profile.py','stage_native.py','kernel-calibration.json',
 'cpu-calibration.json','omissions.json','record_omissions.py','native-calibration-identities.json','native-validation-identities.json',
 'native-validation-hardware.json','run_native_validation.py','validate-native.sh','dependency-metadata.json',
 'sampling-stack.patch','last-row-mask.patch','sampling_oracle.py','sampling-oracle.json','mask-oracle.json','sampling-control-filter.json',
 'sampling-after-screen.json','mask-after-screen.json','prepare_autocast.py','package_results.py','update_document.py',
 'mask-none.patch','mask_none_oracle.py','mask-none-oracle.json','mask-none-oracle-host.json','mask-none-oracle-image.json',
 'mask-none-nonstream-failure.log','mask-none-after.json','controls-mask-none.json','mask-none-control-filter.json',
 'mask-none-after-screen.json','prepare_mask_none.py','run_mask_none.py','prepare_traces.py','prepared-traces.json','cudnn-coverage.json']
bundle=E/'evidence/cosyvoice-reproduce.tar.gz'
with tarfile.open(bundle,'w:gz')as t:
    for name in files:t.add(P/name,arcname=name)
with tarfile.open(bundle,'r:gz')as t:
    assert sorted(t.getnames())==sorted(files)
    for name in files:assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==sha(P/name)
out['reproduction']={'file':bundle.name,'sha256':sha(bundle),'files':files,
    'note':'Install pinned source/model/dependencies and adjust paths. Initial native calibration creates controls and kernel DB; candidate timing reuses both. Apply the decorator patch to a separate source tree. All timings use identical runner bytes.'}
dbdir=E/'evidence/kernel-databases';manifest=read(dbdir/'manifest.json');artifacts={}
for key,name,target in [('native_database','gpu.sqlite','cosyvoice.sqlite.gz'),('native_report','kernel-profile.json','cosyvoice.report.json.gz'),('cpu_instruction_calibration','cpu.db','cosyvoice.cpu.db.gz')]:
    raw=(P/name).read_bytes();dst=dbdir/target;dst.write_bytes(gzip.compress(raw,compresslevel=9,mtime=0));assert gzip.decompress(dst.read_bytes())==raw
    artifacts[key]={'file':target,'uncompressed_bytes':len(raw),'uncompressed_sha256':sha(P/name),'gzip_sha256':sha(dst)}
manifest['artifacts']['cosyvoice']=artifacts;(dbdir/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');out['calibration']=artifacts
allpins=read(E/'pins.json');allpins['CosyVoice']=pins;(E/'pins.json').write_text(json.dumps(allpins,indent=2)+'\n')
(E/'evidence/cosyvoice-cpu.json').write_text(json.dumps(out,indent=2)+'\n')
print('COSYVOICE_PACKAGE_PASS',json.dumps({'gx':{m:x['request_reduction_percent'] for m,x in out['gx'].items()},
    'native_median':n['median_reduction_percent'],'native_mean':n['mean_reduction_percent'],'memory':out['memory']}),flush=True)
