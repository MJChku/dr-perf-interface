import hashlib,json,urllib.request,shutil
from pathlib import Path
P=Path(__file__).resolve().parent;repo='FunAudioLLM/CosyVoice2-0.5B';meta=json.loads((P/'CosyVoice2-0.5B-metadata.json').read_text());rev=meta['sha'];root=Path('/home/ubuntu/gx-ix14/causal/models/CosyVoice2');root.mkdir(parents=True,exist_ok=True)
files=[]
for x in meta['siblings']:
 n=x['rfilename']
 if not(n.startswith('CosyVoice-BlankEN/')or n in ('cosyvoice2.yaml','llm.pt','flow.pt','hift.pt','campplus.onnx','speech_tokenizer_v2.onnx')):continue
 f=root/n;f.parent.mkdir(parents=True,exist_ok=True)
 if not f.exists():
  assert shutil.disk_usage(root).free>x['size']+700000000
  with urllib.request.urlopen(f'https://huggingface.co/{repo}/resolve/{rev}/{n}',timeout=180)as inp,f.with_suffix('.download').open('wb')as out:shutil.copyfileobj(inp,out,4*1024*1024)
  f.with_suffix('.download').replace(f)
 with f.open('rb')as inp:h=hashlib.file_digest(inp,'sha256').hexdigest()
 assert f.stat().st_size==x['size']
 if 'lfs'in x:assert h==x['lfs']['sha256']
 files.append({'repository':repo,'revision':rev,'path':n,'bytes':f.stat().st_size,'sha256':h});print('COSYVOICE_MODEL_VERIFIED',n,f.stat().st_size,flush=True)
(P/'model-manifest.json').write_text(json.dumps({'root':str(root),'files':files},indent=2)+'\n')
