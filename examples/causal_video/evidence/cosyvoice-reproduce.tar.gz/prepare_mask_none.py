import difflib,json,shutil
from pathlib import Path
P=Path(__file__).resolve().parent
old=(P/'source/cosyvoice/llm/llm.py').read_text()
new=(P/'source-mask/cosyvoice/llm/llm.py').read_text()
assert new.count('input_masks = masks[:, -1, :]')==1
new=new.replace('input_masks = masks[:, -1, :]', 'input_masks = None if masks is None else masks[:, -1, :]')
new=new.replace('# Qwen2Encoder consumes only the last row; that row is all true.',
                '# The built-in decoder is unpadded and uses causal attention.')
new=new.replace('return torch.ones((1, 1, length), device=device, dtype=torch.bool)',
                'return None')
assert new.count('masks=_inference_mask(self.llm, lm_input.shape[1], lm_input.device)')==1
new=new.replace('masks=_inference_mask(self.llm, lm_input.shape[1], lm_input.device)',
                'masks=torch.tril(torch.ones((1, lm_input.shape[1], lm_input.shape[1]), device=lm_input.device)).to(torch.bool)')
shutil.copytree(P/'source',P/'source-mask-none',dirs_exist_ok=True)
(P/'source-mask-none/cosyvoice/llm/llm.py').write_text(new)
(P/'mask-none.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/cosyvoice/llm/llm.py',tofile='b/cosyvoice/llm/llm.py')))
tape=json.loads((P/'controls.json').read_text());removed=[]
for events in tape['requests']:
    kept=[];dropped=[]
    for event in events:
        tag=event['tag']
        if tag[:3]==['__bool__','masking_utils.py','_ignore_causal_mask_sdpa']:
            assert event['value'] is True;dropped.append(event)
        else:kept.append(event)
    assert len(dropped)==298,len(dropped)
    events[:]=kept;removed.append(dropped)
(P/'controls-mask-none.json').write_text(json.dumps(tape,separators=(',',':'))+'\n')
(P/'mask-none-control-filter.json').write_text(json.dumps({'removed_per_request':[len(x)for x in removed],'removed':removed,'reason':'Known unpadded causal caller passes attention_mask=None. The original HF all-true check is omitted; remaining controls are identical.'},indent=2)+'\n')
d=json.loads((P/'partial.json').read_text());d['name']='cosyvoice-nomask';d['files']['source']=str(P/'source-mask-none');d['files']['controls']=str(P/'controls-mask-none.json')
(P/'mask-none-after.json').write_text(json.dumps(d,indent=2)+'\n')
