import json,sys
from pathlib import Path
P=Path(__file__).resolve().parent;E=P.parents[2]/'examples/causal_video'
sys.path.insert(0,str(E))
from compact_gx_trace import compact
prepared={}
for mode,names in [('mode2',('partial','autocast-after')),('mode3',('sync-before','sync-after'))]:
    for side,name in zip(('before','after'),names):
        a=json.loads((P/(name+'-audit.json')).read_text())
        src=Path(a['run'])/'timeline-report/trace.json.gz';dst=E/f'evidence/cosyvoice-{mode}-{side}.chrome.json.gz'
        prepared[mode+'_'+side]={'file':dst.name,'full_trace':str(src),**compact(src,dst,bin_ms=5)}
        (P/'prepared-traces.json').write_text(json.dumps(prepared,indent=2)+'\n')
        print('COSYVOICE_TRACE_READY',mode,side,dst.stat().st_size,flush=True)
