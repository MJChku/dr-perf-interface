"""Render prose only from completed, separately audited predictions/measurements."""
import json
from pathlib import Path
P=Path(__file__).resolve().parent;E=P.parents[2]/'examples/causal_video'
d=json.loads((E/'evidence/cosyvoice-cpu.json').read_text());gx=d['gx'];n=d['native_A100']
def values(mode):
    p=gx[mode];return p['before']['means']['virtual_seconds'],p['after']['means']['virtual_seconds'],p['request_reduction_percent']
m1=values('mode1');m2=values('mode2');m3=values('mode3')
mask_none=d['additional_screens']['mask-none-after']['mode2']['client_iterations']['reduction_percent']
memory=(d['memory']['after']['peak_gpu_bytes'][0]-d['memory']['before']['peak_gpu_bytes'][0])/1e6
text=f'''## CosyVoice2: autocast caching, a modest native improvement

GX mode-2 traces of the original CosyVoice2 text-streaming API showed repeated
on-device FP32-to-FP16 weight-conversion kernels during autoregressive decoding.
On the pinned Torch 2.11 stack, the `inference_mode` decorator disables autocast's weight
cache. Replacing that one decorator with `no_grad` permits reuse within the
existing outer autocast context. Model parameters and arithmetic precision
remain unchanged; both CPU dispatch and GPU conversion work change.

This removes 74,115 conversion launches per request. All other kernel-signature
counts and host/device memcpy bytes are unchanged in the mode-2 comparison.
It retains half-precision weights:
native peak allocated GPU memory increases from 2.954 to 3.679 GB
(+{memory:.1f} MB). The change is specific to this Torch version and execution
path; callers already in inference mode or using frozen parameters may not
benefit. The evaluated model is CosyVoice2, not the inheriting CosyVoice3 path.

| Measurement | Before | After | Reduction |
| --- | ---: | ---: | ---: |
| GX mode 1, GPU-only | {m1[0]:.6f} s | {m1[1]:.6f} s | {m1[2]:.2f}% |
| GX mode 2, caller-marked request | {m2[0]:.6f} s | {m2[1]:.6f} s | {m2[2]:.2f}% |
| GX mode 3, synchronized request | {m3[0]:.6f} s | {m3[1]:.6f} s | {m3[2]:.2f}% |
| A100, unhooked median | {n['before']['median']:.6f} s | {n['after']['median']:.6f} s | {n['median_reduction_percent']:.2f}% |
| A100, unhooked mean | {n['before']['mean']:.6f} s | {n['after']['mean']:.6f} s | {n['mean_reduction_percent']:.2f}% |

The native ABBA comparison retains all ten samples per variant. All 20 measured
outputs, 12 warmups and four separate guarded requests produce exactly the
same 285,120-sample waveform (11.88 seconds at 24 kHz). The workload uses the
official four text chunks, a cached reference speaker, the original RAS
sampler, seed 42, and batched audio output. Model loading and cached-speaker
preparation are excluded. No kernel database was updated during optimization.

This is a small improvement with a memory tradeoff. GX overpredicts absolute
latency and the selected gain. It also omits cuFFT/associated work through a
recorded-shape adapter after an actual cuFFT emulation failure; the native
validation retains these operations. Baseline native-only launches have a
1.883 ms sum of isolated medians per request, which is not an end-to-end timing
correction. Mode 2 retains four prediction misses per variant across two requests.
Mode 3 additionally has a cuDNN algorithm/coverage difference: its baseline
records two malformed transform launches (grid.x 697,008,384, block.x 544),
while its candidate has the four unmatched transform/convolution launches
seen in mode 2. This is reported in the existing GX cuDNN issue. The mode-3
pair is coverage-limited; no guessed geometry or duration correction is used.
The mode-1 candidate has the same symptom with a different malformed grid,
so its device-only comparison is also coverage-limited. These observations
refer to the archived runtime, not an untested newer GX revision.
CPU calibration has 4.16% unresolved instruction samples. Mode 2 has separate
caller/worker clocks: raw worker spans are not request latencies. The reported
mode-2 interval is on the caller; mode 3 synchronizes both threads.
The GX CPU model includes Python control-replay bookkeeping; native latency
uses unhooked requests. This is another source of timing distortion, not a
measured application bottleneck or an additive correction to these results.

[GX/A100 results, samples, hashes and limitations](evidence/cosyvoice-cpu.json),
[one-decorator patch](cpu_patches/cosyvoice_autocast_cache.patch),
[runner](cosyvoice_runner.py),
[reproduction bundle](evidence/cosyvoice-reproduce.tar.gz).
The compact Chrome activity views show CPU execution, GPU work and copies:
[mode-2 before](evidence/cosyvoice-mode2-before.chrome.json.gz) /
[after](evidence/cosyvoice-mode2-after.chrome.json.gz), and
[mode-3 before](evidence/cosyvoice-mode3-before.chrome.json.gz) /
[after](evidence/cosyvoice-mode3-after.chrome.json.gz).
They aggregate interval coverage into 5 ms bins; original captures remain
archived and are referenced by hash. These are simulated timelines.

Two other independent screens were not selected: replacing GPU scalar-list
construction with stacking reduced mode-2 latency by 1.61%, with new prediction
misses; constructing only the used causal-mask row changed latency by 0.0025%.
Their CPU equivalence checks and complete GX audits are retained. Neither has
optimized native validation. Omitting the known-unpadded streaming mask reduced
mode-2 latency by {mask_none:.2f}%, so this third screen was also stopped before
native validation. It preserves the nonstreaming path after an oracle found a
cached-mask semantic difference there. The earlier
[mask source/oracle bundle](evidence/cosyvoice-candidate.tar.gz) remains available.

The separate vLLM path copies `token_ids` into a new Python list to read its
last element at each decode step. This remains an unmeasured source lead;
the vLLM backend was not used in the reported workload.

Paper text for this modest result:

> In CosyVoice2, GX exposed repeated weight conversions caused by an interaction
> between inference mode and autocast caching on Torch 2.11. Allowing the existing
> cache to reuse these conversions removed 74,115 GPU launches per request.
> GX mode 2 predicted {m2[0]:.3f} to {m2[1]:.3f} seconds ({m2[2]:.1f}%);
> mode 3 predicted {m3[0]:.3f} to {m3[1]:.3f} seconds ({m3[2]:.1f}%), with a
> recorded cuDNN coverage difference between the two runs.
> Independent A100 validation measured a smaller median reduction from
> {n['before']['median']:.3f} to {n['after']['median']:.3f} seconds
> ({n['median_reduction_percent']:.1f}%), with identical outputs in all 20 measured
> requests. The change increased peak GPU memory by {memory:.0f} MB. This case
> records the distinction between a GX optimization prediction and its measured
> benefit, including the memory tradeoff and simulation coverage limitations.

Follow-on FunASR source inspection is retained in the
[source-screen record](evidence/cpu-screen-negative.json). A redundant reset
of the published SenseVoice configuration costs about 53 microseconds in a
CPU-only scale check, so this lead was deprioritized before GPU calibration.
The other decoding leads remain unmeasured; this is not a pretrained FunASR
timing result.
'''
p=E/'README.md';s=p.read_text();marker='## CosyVoice: next source candidate, no performance result yet'
if marker in s:s=s[:s.index(marker)]+text
else:
    marker='## CosyVoice2: autocast caching, a modest native improvement'
    assert marker in s;s=s[:s.index(marker)]+text
old='CosyVoice currently has a GX mode-2 screen: an autocast-cache change reduces\nthe caller-marked request interval from 7.347 to 6.977 seconds (5.0%).\nMode-3 and A100 validation are in progress; this is not yet a validated speedup.'
s=s.replace(old,'CosyVoice2 adds a modest, validated autocast-cache result with an explicit GPU\nmemory tradeoff; its CPU dispatch and GPU conversion work both change.')
row=f"| [CosyVoice2: autocast cache, CPU dispatch and GPU casts](#cosyvoice2-autocast-caching-a-modest-native-improvement) | {m2[0]:.3f} -> {m2[1]:.3f} s | {m3[0]:.3f} -> {m3[1]:.3f} s | {n['before']['median']:.3f} -> {n['after']['median']:.3f} s |"
needle='| [Outlines:';lines=s.splitlines();index=next(i for i,x in enumerate(lines)if x.startswith(needle))
if not any(x.startswith('| [CosyVoice2:')for x in lines):lines.insert(index+1,row)
p.write_text('\n'.join(lines)+'\n')
print('COSYVOICE_DOCUMENT_PASS',flush=True)
