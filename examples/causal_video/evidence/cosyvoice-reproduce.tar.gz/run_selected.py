"""Advance a material mode-2 result to synchronized and GPU-only comparisons."""
import json, statistics, subprocess, time
from pathlib import Path
P=Path(__file__).resolve().parent
read=lambda n:json.loads((P/n).read_text())
for _ in range(1200):
    if (P/'autocast-after-run.json').exists():
        active=subprocess.check_output(['ps','-eo','args'],text=True)
        if not any(('run_timing.py autocast-after' in l and 'python3' in l)
                   for l in active.splitlines()):
            break
    time.sleep(2)
else:raise RuntimeError('Autocast screen did not finish')
b=read('partial-audit.json');a=read('autocast-after-audit.json')
assert a['result']['passed'] and not a['result']['cleanup_errors']
screen={}
for key,field in [('client_iterations','virtual_seconds'),('gpu_worker_iterations','cpu_seconds')]:
    before=statistics.mean(x[field] for x in b[key])
    after=statistics.mean(x[field] for x in a[key])
    screen[key]={'before':before,'after':after,'reduction_percent':100*(1-after/before)}
(P/'autocast-after-screen.json').write_text(json.dumps(screen,indent=2)+'\n')
print('COSYVOICE_AUTOCAST_SCREEN',json.dumps(screen),flush=True)
assert screen['client_iterations']['reduction_percent']>3, 'Not selected: insufficient measured GX headroom'
selected={'source':'source-autocast','audit':'autocast-after','controls':'controls.json','control_arrays':'controls.npz','patch':'autocast-cache.patch'}
(P/'selected.json').write_text(json.dumps(selected,indent=2)+'\n')
for name in ('sync-before','sync-after','gpu-before','gpu-after'):
    assert not (P/(name+'-run.json')).exists(), name
    subprocess.run(['python3',str(P/'run_timing.py'),name],check=True)
print('COSYVOICE_SELECTED_GX_PASS',flush=True)
