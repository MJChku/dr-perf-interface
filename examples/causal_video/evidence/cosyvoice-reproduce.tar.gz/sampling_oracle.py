import ast,hashlib,json
from pathlib import Path
import torch
P=Path(__file__).resolve().parent
def load(path):
 t=ast.parse(path.read_text());node=next(x for x in t.body if isinstance(x,ast.FunctionDef)and x.name=='nucleus_sampling');ns={'torch':torch};exec(compile(ast.Module(body=[node],type_ignores=[]),str(path),'exec'),ns);return ns[node.name]
a=load(P/'source/cosyvoice/utils/common.py');b=load(P/'source-sampling/cosyvoice/utils/common.py');torch.set_num_threads(1);cases=0
for dtype in (torch.float32,torch.float16,torch.bfloat16,torch.float64):
 for length in (1,4,25,100,6561):
  for top_p in (.1,.8,1.0):
   for top_k in (1,25):
    for strided in (False,True):
     torch.manual_seed(12);x=torch.randn(length*2,dtype=dtype)[::2]if strided else torch.randn(length,dtype=dtype)
     torch.manual_seed(42);left=a(x,top_p,top_k);state=torch.get_rng_state()
     torch.manual_seed(42);right=b(x,top_p,top_k);assert left==right and torch.equal(state,torch.get_rng_state());cases+=1
result={'passed':True,'cpu_cases':cases,'torch':torch.__version__,'patch_sha256':hashlib.sha256((P/'sampling-stack.patch').read_bytes()).hexdigest(),'scope':'Actual original and candidate nucleus_sampling extracted without unrelated imports; exact sampled token and RNG state across FP32/FP16/BF16, vocabulary lengths through6561, top-p/top-k and strided scores. CPU oracle only; includes FP64 dtype inference; CUDA correctness and GX gain remain unvalidated.'}
(P/'sampling-oracle.json').write_text(json.dumps(result,indent=2)+'\n');print('COSYVOICE_SAMPLING_ORACLE_PASS',cases)
