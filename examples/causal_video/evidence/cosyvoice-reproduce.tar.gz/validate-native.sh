#!/usr/bin/env bash
set -euo pipefail
ulimit -c 0
cosyvoice_selected=$1
cosyvoice_selected_controls=$2
cosyvoice_selected_arrays=$3
export LD_LIBRARY_PATH=/workspace/causal/f5-tts/deps/ffmpeg/lib:/workspace/causal/sglang/cuda13_libs:/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cudnn/lib
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONHASHSEED=0 TOKENIZERS_PARALLELISM=false HF_HUB_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1
export HF_HUB_DISABLE_PROGRESS_BARS=1 TQDM_DISABLE=1
export HF_HOME=/workspace/causal/hf-cache LOCAL_FILES_ONLY=true
export FLASHINFER_DISABLE_VERSION_CHECK=1 VLLM_USE_V1=1 VLLM_WORKER_MULTIPROC_METHOD=spawn VLLM_ATTENTION_BACKEND=FLASH_ATTN
export TORCHINDUCTOR_CACHE_DIR=/workspace/causal/cosyvoice/cache-native/inductor
export TRITON_CACHE_DIR=/workspace/causal/cosyvoice/cache-native/triton
export TORCHINDUCTOR_COMPILE_THREADS=2
unset LD_PRELOAD GX_PREDICT_DB GX_PROFILE_SO GX_PROFILE_START_FILE GX_PROFILE_STOP_FILE
cosyvoice_index=0
for cosyvoice_side in before after after before; do
 cosyvoice_index=$((cosyvoice_index+1))
 cosyvoice_source=source
 [[ $cosyvoice_side == before ]] || cosyvoice_source=$cosyvoice_selected
 export PYTHONPATH=/workspace/causal/cosyvoice/$cosyvoice_source:/workspace/causal/cosyvoice/deps:/workspace/causal/diffsynth/deps:/workspace/causal/zipvoice/deps:/workspace/causal/soprano/deps:/workspace/causal/f5-tts/deps:/workspace/causal/qwen-tts/deps:/workspace/causal/qwen-tts/source:/workspace/causal/fastgen/deps:/workspace/causal/fastgen/source:/workspace/causal/omni/source:/workspace/causal/omni/extras:/workspace/causal/omni/deps:/workspace/causal/wan2gp/deps:/workspace/causal/wanwrapper/deps:/workspace/causal/sglang/cutlass:/workspace/causal/sglang/cutlass/nvidia_cutlass_dsl/dsl_packages:/workspace/causal/sglang/deps:/workspace/causal/sglang/kernel:/workspace/causal/sglang/source/python:/workspace/causal/deps:/workspace/causal/scope-deps:/workspace/causal/flashdreams-deps:/workspace/deps
 cosyvoice_runner=runner.py
 cosyvoice_out=/workspace/causal/runs/cosyvoice-plain-$cosyvoice_index-$cosyvoice_side
 [[ ! -e $cosyvoice_out ]]
 timeout -k 20 900 python3 -u /workspace/causal/cosyvoice/$cosyvoice_runner --model /workspace/causal/models/CosyVoice2 --speaker /workspace/causal/cosyvoice/speaker.pt --output "$cosyvoice_out" --role native --plain --warmup 3 --repetitions 5 > "$cosyvoice_out.log" 2>&1
 printf 'COSYVOICE_NATIVE_PROCESS_PASS %s %s\n' "$cosyvoice_index" "$cosyvoice_side"
done
for cosyvoice_side in before after; do
 cosyvoice_source=source
 cosyvoice_controls=controls.json
 cosyvoice_arrays=controls.npz
 if [[ $cosyvoice_side == after ]]; then
  cosyvoice_source=$cosyvoice_selected
  cosyvoice_controls=$cosyvoice_selected_controls
  cosyvoice_arrays=$cosyvoice_selected_arrays
 fi
 export PYTHONPATH=/workspace/causal/cosyvoice/$cosyvoice_source:/workspace/causal/cosyvoice/deps:/workspace/causal/diffsynth/deps:/workspace/causal/zipvoice/deps:/workspace/causal/soprano/deps:/workspace/causal/f5-tts/deps:/workspace/causal/qwen-tts/deps:/workspace/causal/qwen-tts/source:/workspace/causal/fastgen/deps:/workspace/causal/fastgen/source:/workspace/causal/omni/source:/workspace/causal/omni/extras:/workspace/causal/omni/deps:/workspace/causal/wan2gp/deps:/workspace/causal/wanwrapper/deps:/workspace/causal/sglang/cutlass:/workspace/causal/sglang/cutlass/nvidia_cutlass_dsl/dsl_packages:/workspace/causal/sglang/deps:/workspace/causal/sglang/kernel:/workspace/causal/sglang/source/python:/workspace/causal/deps:/workspace/causal/scope-deps:/workspace/causal/flashdreams-deps:/workspace/deps
 cosyvoice_runner=runner.py
 cosyvoice_out=/workspace/causal/runs/cosyvoice-control-$cosyvoice_side
 [[ ! -e $cosyvoice_out ]]
 timeout -k 20 900 python3 -u /workspace/causal/cosyvoice/$cosyvoice_runner --model /workspace/causal/models/CosyVoice2 --speaker /workspace/causal/cosyvoice/speaker.pt --output "$cosyvoice_out" --role native --controls /workspace/causal/cosyvoice/"$cosyvoice_controls" --control-arrays /workspace/causal/cosyvoice/"$cosyvoice_arrays" --warmup 1 --repetitions 1 > "$cosyvoice_out.log" 2>&1
 printf 'COSYVOICE_NATIVE_CONTROL_PASS %s\n' "$cosyvoice_side"
done
