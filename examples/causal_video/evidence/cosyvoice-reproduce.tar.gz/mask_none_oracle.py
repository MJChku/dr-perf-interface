"""Exact CPU forward/cache checks for known-unpadded mask omission."""
import ast,hashlib,json
from pathlib import Path
import torch,transformers
from transformers import Qwen2Config,Qwen2ForCausalLM,DynamicCache
P=Path(__file__).resolve().parent
def definitions(path):
    tree=ast.parse(path.read_text());nodes=[x for x in tree.body if isinstance(x,(ast.ClassDef,ast.FunctionDef))and x.name in ('Qwen2Encoder','_inference_mask')]
    env={'torch':torch,'Qwen2ForCausalLM':Qwen2ForCausalLM}
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),env);return env
base=definitions(P/'source/cosyvoice/llm/llm.py');candidate=definitions(P/'source-mask-none/cosyvoice/llm/llm.py')
torch.set_num_threads(1);torch.manual_seed(42)
before=base['Qwen2Encoder'].__new__(base['Qwen2Encoder']);torch.nn.Module.__init__(before)
after=candidate['Qwen2Encoder'].__new__(candidate['Qwen2Encoder']);torch.nn.Module.__init__(after)
helper=candidate['_inference_mask'];assert helper(after,17,'cpu')is None
checks=0
with torch.inference_mode():
    for backend in ('eager','sdpa'):
        for dtype in (torch.float32,torch.bfloat16):
            cfg=Qwen2Config(vocab_size=32,hidden_size=32,intermediate_size=64,num_hidden_layers=2,num_attention_heads=4,num_key_value_heads=2,max_position_embeddings=256)
            cfg._attn_implementation=backend
            model=Qwen2ForCausalLM(cfg).eval().to(dtype);before.model=model;after.model=model
            for full_mask in (True,):
                cache_a=DynamicCache(config=cfg);cache_b=DynamicCache(config=cfg);seen=0
                for count in (7,1,1,4,1):
                    x=torch.randn(1,count,32,dtype=dtype);seen+=count;n=seen if full_mask else count
                    old=torch.tril(torch.ones((1,n,n))).bool()
                    a,cache_a=before.forward_one_step(x,old,cache_a)
                    b,cache_b=after.forward_one_step(x,helper(after,n,'cpu'),cache_b)
                    assert torch.equal(a,b),(backend,str(dtype),full_mask,count,(a-b).abs().max())
                    checks+=1
class Custom(candidate['Qwen2Encoder']):pass
for obj in (object(),Custom.__new__(Custom)):
    for n in (1,3,32):assert torch.equal(helper(obj,n,'cpu'),torch.tril(torch.ones((1,n,n))).bool())
out={'passed':True,'torch':torch.__version__,'transformers':transformers.__version__,'exact_forward_checks':checks,'custom_encoder_fallback_checks':6,'patch_sha256':hashlib.sha256((P/'mask-none.patch').read_bytes()).hexdigest(),'scope':'CPU random tiny actual Qwen2Encoder, eager/SDPA,FP32/BF16,prefill/cached decode,multiple-token appends,full-history masks. Only bistream callers change. Current-length-only masks can differ on cached eager decode; the initial oracle caught this and the nonstreaming caller remains unchanged. Pretrained correctness requires independent native validation.'}
(P/'mask-none-oracle.json').write_text(json.dumps(out,indent=2)+'\n');print('MASK_NONE_ORACLE_PASS',json.dumps(out),flush=True)
