#!/usr/bin/env bash
set -euo pipefail
ulimit -c 0
export PYTHONPATH=/workspace/causal/sglang/cutlass:/workspace/causal/sglang/cutlass/nvidia_cutlass_dsl/dsl_packages:/workspace/causal/sglang/deps:/workspace/causal/sglang/kernel:/workspace/causal/videoxfun/accelerate-baseline:/workspace/causal/videoxfun/source:/workspace/causal/deps:/workspace/causal/scope-deps:/workspace/causal/flashdreams-deps:/workspace/deps
export LD_LIBRARY_PATH=/workspace/causal/sglang/cuda13_libs:/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cudnn/lib
export LD_PRELOAD=/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cublas/lib/libcublas.so.12:/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cublas/lib/libcublasLt.so.12
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONHASHSEED=0 TOKENIZERS_PARALLELISM=false HF_HUB_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1
export FLASHINFER_DISABLE_VERSION_CHECK=1

base_path="$PYTHONPATH"
idx=0
for variant in before after after before; do
 idx=$((idx+1))
 out="/workspace/causal/runs/videoxfun-bound50-${idx}-${variant}"
 [[ ! -e "$out" ]]
 export PYTHONPATH="${base_path/accelerate-baseline/accelerate-async}"
 extra=()
 if [[ "$variant" == after ]]; then extra+=(--async-offload); fi
 timeout -k 20 1200 python3 -u /workspace/causal/videoxfun/runner_async_bounded.py --model /workspace/checkpoint --source /workspace/causal/videoxfun/source --output "$out" --role native --repetitions 3 --warmup 1 --frames 17 --steps 50 --height 256 --width 448 --allocator-gib 2.25 "${extra[@]}" > "${out}.log" 2>&1
done
