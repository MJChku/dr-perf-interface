"""Final numerical and uninstrumented A100 confirmation; retain matched reports."""
import hashlib,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[2];remote='/home/jcm/drperf-wan-a100-20260916/causal/videoxfun'
a,b=[json.loads((P/f'bound-{s}-audit.json').read_text()) for s in ['before','after']]
assert a['summary']['copies']==b['summary']['copies']
assert sum(x['count']for x in a['launches'])==sum(x['count']for x in b['launches'])
checks={remote+'/runner_async_bounded.py':hashlib.sha256((P/'runner_async_bounded.py').read_bytes()).hexdigest(),remote+'/validate-bound-native.sh':hashlib.sha256((P/'validate-bound-native.sh').read_bytes()).hexdigest()}
for side in ['async']:
 for f in (P/f'accelerate-{side}').rglob('*.py'):checks[remote+'/'+str(f.relative_to(P))]=hashlib.sha256(f.read_bytes()).hexdigest()
script='import hashlib,json;checks=json.loads(%r);assert all(hashlib.sha256(open(p,"rb").read()).hexdigest()==h for p,h in checks.items());print("NATIVE_BOUND_IDENTITIES_PASS",len(checks))' % json.dumps(checks)
subprocess.run(['ssh','-o','ConnectTimeout=10','-o','ConnectionAttempts=3','jcm@A100','python3 -'],input=script,text=True,check=True)
active=subprocess.check_output(['ssh','jcm@A100','nvidia-smi --query-compute-apps=gpu_uuid,pid --format=csv,noheader'],text=True);assert 'GPU-521def15-8599-2c15-65ee-6dac40f31a64' not in active,active
(P/'native-bound-identities.json').write_text(json.dumps(checks,indent=2)+'\n')
helper=R/'examples/wan_gx/native_container.py'
try:
 subprocess.run(['python3',str(helper),'resume'],check=True)
 subprocess.run(['python3',str(helper),'command','bash /workspace/causal/videoxfun/validate-bound-native.sh'],check=True)
 for i,side in enumerate(['before','after','after','before'],1):
  subprocess.run(['rsync','-a',f'jcm@A100:/home/jcm/drperf-wan-a100-20260916/causal/runs/videoxfun-bound-{i}-{side}/report.json',str(P/f'native-bound-{i}-{side}.json')],check=True)
 print('VIDEOXFUN_NATIVE_BOUND_PASS',flush=True)
finally:subprocess.run(['python3',str(helper),'stop'],check=True)
