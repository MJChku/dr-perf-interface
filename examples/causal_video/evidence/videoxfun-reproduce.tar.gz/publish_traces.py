"""Keep Chrome overview and250ms detailed CPU/GPU slices, without event arrows."""
import gzip,hashlib,json,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[2];E=R/'examples/causal_video';sys.path.insert(0,str(E))
from compact_gx_trace import compact,events
index={}
for side in ['before','after']:
 a=json.loads((P/f'bound-{side}-audit.json').read_text());src=Path(a['run'])/'timeline-report/trace.json.gz';dst=E/f'evidence/videoxfun-mode2-{side}.chrome.json.gz'
 overview=compact(src,dst,bin_ms=10)
 lo=a['iterations'][0]['start_ns']/1000;hi=lo+250000;selected=[]
 for e in events(src):
  if e['ph']=='M':selected.append(e)
  elif e['ph']=='X' and e['ts']<hi and e['ts']+e['dur']>lo:
   end=min(hi,e['ts']+e['dur']);start=max(lo,e['ts']);e['ts']=start-lo;e['dur']=end-start;selected.append(e)
 desc={'source':str(src),'source_sha256':overview['source_sha256'],'source_window_us':[lo,hi],'view':'First250ms of first measured request, all positive-duration CPU/GPU spans clipped; event markers/arrows omitted; metadata retained. Timestamps rebased to0. CPU spans represent modeled instruction time, not measured native CPU utilization.'}
 slice_path=E/f'evidence/videoxfun-mode2-{side}-250ms.chrome.json.gz';raw=json.dumps({'traceEvents':selected,'displayTimeUnit':'ms','otherData':desc},separators=(',',':')).encode();slice_path.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(slice_path.read_bytes())==raw
 index[side]={'overview':{'file':dst.name,**overview},'detail':{'file':slice_path.name,'compressed_bytes':slice_path.stat().st_size,'json_bytes':len(raw),'events':len(selected),'sha256':hashlib.sha256(slice_path.read_bytes()).hexdigest(),**desc},'full_trace':str(src),'cpu_seconds_per_request':[i['cpu_seconds'] for i in a['iterations']],'outside_gpu_seconds_per_request':[i['outside_gpu_spans_seconds'] for i in a['iterations']]}
(P/'published-traces.json').write_text(json.dumps(index,indent=2)+'\n')
f=E/'evidence/videoxfun-cpu.json';d=json.loads(f.read_text());d['traces']=index;f.write_text(json.dumps(d,indent=2)+'\n')
print('PUBLISH_TRACES_PASS',json.dumps({s:{k:v for k,v in x.items() if k not in ['overview','detail']} for s,x in index.items()}))
