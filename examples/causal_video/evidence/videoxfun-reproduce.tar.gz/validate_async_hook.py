"""Check opt-in forwarding, retained meta offload, and blocking output copies."""
import ast,json
from pathlib import Path
from types import SimpleNamespace
import torch
P=Path(__file__).resolve().parent
source=ast.parse((P/'accelerate-async/accelerate/hooks.py').read_text());cls=next(n for n in source.body if isinstance(n,ast.ClassDef)and n.name=='AlignDevicesHook');nodes=[]
for n in cls.body:
 if isinstance(n,ast.FunctionDef)and n.name in ['pre_forward','post_forward']:n.decorator_list=[];nodes.append(n)
checks=[]
for nonblocking in [False,True]:
 values={'weight':torch.ones(2,2),'bias':torch.ones(2)};calls=[]
 def put(m,n,device,**kwargs):calls.append({'op':'put','name':n,'device':device,'non_blocking':kwargs.get('non_blocking',False),'clear_cache':kwargs.get('clear_cache',True)})
 def send(x,device,**kwargs):calls.append({'op':'send','device':device,'non_blocking':kwargs.get('non_blocking',False)});return x
 ns={'torch':torch,'named_module_tensors':lambda *a,**k:values.items(),'set_module_tensor_to_device':put,'send_to_device':send,'find_device':lambda x:'cpu'}
 exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),'hook','exec'),ns)
 h=SimpleNamespace(io_same_device=True,offload=True,non_blocking=nonblocking,clear_cache=not nonblocking,execution_device='cuda:0',offload_buffers=False,place_submodules=False,weights_map=values,tied_params_names=set(),tied_params_map={},skip_keys=None,_maybe_get_fp16_statistics=lambda *a:None)
 ns['pre_forward'](h,None,torch.ones(1));ns['post_forward'](h,None,torch.ones(1))
 puts=[x for x in calls if x['op']=='put'];assert [x['device']for x in puts]==['cuda:0','cuda:0','meta','meta'];assert all(x['non_blocking']==nonblocking and x['clear_cache']==(not nonblocking) for x in puts[:2]);assert calls[-1]=={'op':'send','device':'cpu','non_blocking':False}
 checks.append({'nonblocking':nonblocking,'calls':calls})
(P/'async-hook-check.json').write_text(json.dumps({'passed':True,'checks':checks,'scope':'CPU call-order oracle; source lifetime and CUDA stream behavior require full-model native validation.'},indent=2)+'\n');print('ASYNC_HOOK_CHECK_PASS')
