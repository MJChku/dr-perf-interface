"""Isolate fused GELU and inference-only CPU watermark changes."""
from pathlib import Path
import difflib,json,shutil
P=Path(__file__).resolve().parent;src=P/'source';dst=P/'source-optimized';assert not dst.exists();shutil.copytree(src,dst,ignore=shutil.ignore_patterns('.git','__pycache__','build','*.egg-info'))
patch=[]
for rel in ('src/chatterbox/models/t3/llama_configs.py','src/chatterbox/tts_turbo.py'):
 f=dst/rel;old=f.read_text()
 if rel.endswith('llama_configs.py'):
  assert old.count('"activation_function": "gelu_new"')==2
  new=old.replace('"activation_function": "gelu_new"','"activation_function": "gelu_pytorch_tanh"')
 else:
  assert old.count('    def generate(\n')==1
  new=old.replace('    def generate(\n','    @torch.inference_mode()\n    def generate(\n')
 f.write_text(new);patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(P/'fused-inference.patch').write_text(''.join(patch))
d=json.loads((P/'partial.json').read_text());d['name']='chatterbox-optimized';d['files']['source']=str(dst);(P/'optimized.json').write_text(json.dumps(d,indent=2)+'\n')
print('CHATTERBOX_CANDIDATE_PREPARED',flush=True)
