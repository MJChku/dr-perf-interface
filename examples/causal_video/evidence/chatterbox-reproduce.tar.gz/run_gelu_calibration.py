"""Finish initial GPU calibration with a fused primitive, checking GPU1 idle."""
import json,subprocess,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[2];ssh=['ssh','-o','ConnectTimeout=10','-o','ConnectionAttempts=3','jcm@A100'];remote='/home/jcm/drperf-wan-a100-20260916/causal';rsync=['rsync','-az','-e','ssh -o ConnectTimeout=10 -o ConnectionAttempts=3']
for name in ('profile_gelu.py','profile-gelu.sh'):subprocess.run(rsync+[str(P/name),'jcm@A100:'+remote+'/chatterbox/'+name],check=True)
active=subprocess.check_output(ssh+['nvidia-smi --query-compute-apps=gpu_uuid,pid --format=csv,noheader'],text=True);assert 'GPU-521def15-8599-2c15-65ee-6dac40f31a64'not in active,active
assert json.loads(subprocess.check_output(ssh+['docker inspect --format "{{json .HostConfig.DeviceRequests}}" drperf-wan-native-0'],text=True))[0]['DeviceIDs']==['1']
helper=R/'examples/wan_gx/native_container.py'
try:
 subprocess.run(['python3',str(helper),'resume'],check=True)
 subprocess.run(ssh+['docker exec -u jma drperf-wan-native-0 bash /workspace/causal/chatterbox/profile-gelu.sh'],check=True)
 dbs=subprocess.check_output(ssh+['find '+remote+"/runs -maxdepth 1 -name 'chatterbox-gelu.rank*.sqlite' -print"],text=True).splitlines();assert len(dbs)==1
 subprocess.run(rsync+['jcm@A100:'+dbs[0],str(P/'gelu.sqlite')],check=True)
 subprocess.run(rsync+['jcm@A100:'+remote+'/runs/chatterbox-gelu.report.json',str(P/'gelu-calibration.json')],check=True)
 print('CHATTERBOX_INITIAL_GELU_PROFILE_PASS',flush=True)
finally:subprocess.run(['python3',str(helper),'stop'],check=True)
