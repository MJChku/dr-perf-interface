import json,resource,time
from importlib.metadata import version
import torch
from chatterbox.tts_turbo import ChatterboxTurboTTS
print('CHATTERBOX_IMPORT_PASS',json.dumps({n:version(n)for n in ('torch','torchaudio','transformers','numpy','librosa','chatterbox-tts','resemble-perth')}),flush=True)
torch.set_num_threads(1);torch.set_num_interop_threads(1)
t=time.perf_counter();model=ChatterboxTurboTTS.from_local('/workspace/causal/models/ChatterboxTurbo',device='cuda')
print('CHATTERBOX_LOAD_PASS',json.dumps({'seconds':time.perf_counter()-t,'parameters':sum(p.numel()for m in (model.t3,model.s3gen,model.ve)for p in m.parameters()),'sample_rate':model.sr,'peak_gpu_bytes':torch.cuda.max_memory_allocated(),'peak_host_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'watermarker':type(model.watermarker).__name__}),flush=True)
