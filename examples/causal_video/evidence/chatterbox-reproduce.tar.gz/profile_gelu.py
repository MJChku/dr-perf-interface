"""Initial primitive calibration for two FP32 GELU-tanh workload shapes."""
import hashlib,json,math,os
from pathlib import Path
import torch
import torch.nn.functional as F
torch.set_num_threads(1);torch.manual_seed(42)
shapes=[(1,1,4096),(1,387,4096)];inputs=[torch.randn(s,device='cuda',dtype=torch.float32)for s in shapes]
references=[.5*x*(1+torch.tanh(math.sqrt(2/math.pi)*(x+.044715*torch.pow(x,3))))for x in inputs]
for _ in range(2):outputs=[F.gelu(x,approximate='tanh')for x in inputs]
torch.cuda.synchronize();Path(os.environ['GX_PROFILE_START_FILE']).touch(exist_ok=False)
outputs=[F.gelu(x,approximate='tanh')for x in inputs];torch.cuda.synchronize();Path(os.environ['GX_PROFILE_STOP_FILE']).touch(exist_ok=False)
rows=[]
for shape,ref,y in zip(shapes,references,outputs):
 torch.testing.assert_close(y,ref,atol=2e-6,rtol=2e-5)
 rows.append({'shape':shape,'max_absolute_difference':float((y-ref).abs().max()),'finite':bool(y.isfinite().all())})
p=Path(os.environ['GX_PROFILE_DB']).with_suffix('.report.json');p.write_text(json.dumps({'torch':torch.__version__,'dtype':'float32','operation':'torch.nn.functional.gelu approximate=tanh','rows':rows,'scope':'Initial operator calibration only, no application optimization or latency validation. Two input shapes derived from original GPT2 workload; same A100 and Torch stack as model calibration. Equivalent mathematical approximation, not bitwise identical activation.'},indent=2)+'\n');print('CHATTERBOX_GELU_CALIBRATION_PASS',rows,flush=True)
