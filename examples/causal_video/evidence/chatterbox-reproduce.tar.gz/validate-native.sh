#!/usr/bin/env bash
set -euo pipefail
ulimit -c 0
export LD_LIBRARY_PATH=/workspace/causal/sglang/cuda13_libs:/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cudnn/lib
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONHASHSEED=0 TOKENIZERS_PARALLELISM=false HF_HUB_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1
export HF_HOME=/workspace/causal/hf-cache LOCAL_FILES_ONLY=true
export FLASHINFER_DISABLE_VERSION_CHECK=1
unset LD_PRELOAD GX_PREDICT_DB GX_PROFILE_SO GX_PROFILE_START_FILE GX_PROFILE_STOP_FILE
chatter_index=0
for chatter_side in before after after before; do
 chatter_index=$((chatter_index+1))
 chatter_source=source
 [[ $chatter_side == before ]] || chatter_source=source-optimized
 export PYTHONPATH=/workspace/causal/chatterbox/$chatter_source/src:/workspace/causal/chatterbox/deps:/workspace/causal/qwen-tts/deps:/workspace/causal/fastgen/deps:/workspace/causal/omni/extras:/workspace/causal/omni/deps:/workspace/causal/wan2gp/deps:/workspace/causal/wanwrapper/deps:/workspace/causal/sglang/deps:/workspace/causal/deps:/workspace/causal/scope-deps:/workspace/causal/flashdreams-deps:/workspace/deps
 chatter_out=/workspace/causal/runs/chatterbox-plain-$chatter_index-$chatter_side
 [[ ! -e $chatter_out ]]
 timeout -k 20 900 python3 -u /workspace/causal/chatterbox/runner.py --model /workspace/causal/models/ChatterboxTurbo --output "$chatter_out" --role native --plain --warmup 2 --repetitions 5 > "$chatter_out.log" 2>&1
 printf 'CHATTERBOX_NATIVE_PROCESS_PASS %s %s\n' "$chatter_index" "$chatter_side"
done
# One additional pair checks original native scalar/CPU-array controls and
# STFT shape formulas. These guarded runs do not enter latency statistics.
for chatter_side in before after; do
 chatter_source=source
 [[ $chatter_side == before ]] || chatter_source=source-optimized
 export PYTHONPATH=/workspace/causal/chatterbox/$chatter_source/src:${PYTHONPATH#*:}
 chatter_out=/workspace/causal/runs/chatterbox-control-$chatter_side
 [[ ! -e $chatter_out ]]
 timeout -k 20 900 python3 -u /workspace/causal/chatterbox/runner.py --model /workspace/causal/models/ChatterboxTurbo --output "$chatter_out" --role native --controls /workspace/causal/chatterbox/controls.json --control-arrays /workspace/causal/chatterbox/controls.npz --warmup 1 --repetitions 1 > "$chatter_out.log" 2>&1
 printf 'CHATTERBOX_NATIVE_CONTROL_PASS %s\n' "$chatter_side"
done
