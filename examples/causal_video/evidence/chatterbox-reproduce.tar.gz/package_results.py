"""Publish separate GX predictions and complete native ABBA evidence."""
import gzip,hashlib,json,shutil,statistics,subprocess,sys,tarfile
from pathlib import Path
P=Path(__file__).resolve().parent;E=P.parents[2]/'examples/causal_video';sys.path.insert(0,str(E))
from compact_gx_trace import compact
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source={'remote':'https://github.com/resemble-ai/chatterbox.git','commit':subprocess.check_output(['git','-C',str(P/'source'),'rev-parse','HEAD'],text=True).strip()}
pins={'source':source,'model':read(P/'model-manifest.json'),'dependencies':read(P/'kernel-profile.json')['versions'],'workload':read(P/'kernel-profile.json')['request'],'scope':read(P/'kernel-profile.json')['scope']};(P/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
limitations=[
 'One fixed English request/seed with the built-in voice, resident FP32 Turbo model, sampling and original CPU Perth watermark. No prompt encoding or file encoding. Not a throughput, multi-request or all-prompt study.',
 'GX skips GPU arithmetic and replays200GPU scalar/shape/CPU-array controls perrequest. Original scalar reads and final waveform D2H copy remain; prerecorded real CPU waveform feeds the original CPU watermark. GX cannot independently validate generated audio.',
 'Real cuFFT fails with CUFFT_INTERNAL_ERROR under this GX runtime. GX-only HiFT16point/hop4STFT/ISTFT shape adapters omit FFT, associated window/pointwise/overlap work and host dispatch. Native executes original methods; separate native guarded runs check actual shapes and control values.',
 'Baseline native-only launches also include unsupported FP32 GEMM and cuDNN plan differences. Their isolated medians sum to15.702677ms/request, not an end-to-end correction. Exact launch audits and misses are retained; no exact native replay claim.',
 'Initial GPU calibration comprises original model kernels plus two FP32 GELU-tanh primitive shapes. Both were obtained before any mode2 candidate evaluation. The merged predictor preserves480measured signatures; candidate generation was not benchmarked onGPU during discovery.',
 'Fused tanhGELU uses the same mathematical approximation with different FP32 rounding. Initial primitive checks had maximum absolute error2.3841858e-7. Identical measured native audio hashes apply to this request, not a bitwise equivalence guarantee for every input.',
 'CPU profile461unresolved out6197instruction samples(7.44%),23unresolved task samples. GX and A100 use different CPU hosts. Native primary samples omit tape and FFT hooks; absolute timings are not a matched-instrumentation accuracy study.',
 'Mode3 uses10us epochs; CPU/GPU spans include synchronization/granularity effects and are not hardware utilization. Compact counters are unions within bins, not additive resource utilization.',
 'Watermark oracle saved-tensor bytes count references, including parameter tensors;21.237MB is not a claim of that much additional unique allocated host memory.',
]
out={'system':'Chatterbox Turbo','pins':pins,'change':'Use PyTorch fused tanhGELU for GPT2 and torch.inference_mode on the public generation method, avoiding autograd recording in the CPU watermark stage. Sampling, parameters, offload and transfer ranges unchanged.','gx':{},'traces':{},'limitations':limitations,'native_kernel_calibration':read(P/'kernel-profile.json'),'primitive_calibration':read(P/'gelu-calibration.json'),'predictor_provenance':read(P/'predictor-provenance.json'),'cpu_calibration':read(P/'cpu-calibration.json'),'cpu_diagnostic':read(P/'cpu-diagnostic.json'),'omissions':read(P/'omissions.json')}
for mode,names in [('mode2',('partial','optimized')),('mode3',('sync-before','sync-after'))]:
 pair={}
 for side,name in zip(('before','after'),names):
  a=read(P/(name+'-audit.json'));assert a['result']['passed']and not a['result']['cleanup_errors']
  assert a['model']['runner_sha256']==sha(P/'runner.py');assert a['gpu_db_sha256']==sha(P/'gpu-predictor.sqlite')and a['cpu_db_sha256']==sha(P/'cpu.db')
  pair[side]=a|{'runtime':read(Path(a['run'])/'runtime.json'),'controller_wall_seconds':read(P/(name+'-run.json'))['controller_wall_seconds']}
  pair[side]['means']={k:statistics.mean(x[k]for x in a['iterations'])for k in ('virtual_seconds','cpu_seconds','gpu_span_seconds','outside_gpu_spans_seconds')}
  dst=E/f'evidence/chatterbox-{mode}-{side}.chrome.json.gz';src=Path(a['run'])/'timeline-report/trace.json.gz';out['traces'][mode+'_'+side]={'file':dst.name,'full_trace':str(src),**compact(src,dst,bin_ms=1)}
 assert pair['before']['runtime']['dynamorio']==pair['after']['runtime']['dynamorio']
 for k in ('copy_bytes','copy_counts'):assert pair['before']['iterations'][0][k]==pair['after']['iterations'][0][k]
 pair['request_reduction_percent']=100*(1-pair['after']['means']['virtual_seconds']/pair['before']['means']['virtual_seconds']);out['gx'][mode]=pair
n=read(P/'native-summary.json');assert n['measured_output_checks']==20
for block in n['reports']:
 report=block['report'];g=out['gx']['mode2'][block['side']]['model'];assert report['versions']==g['versions']and report['source_sha256']==g['source_sha256'];assert report['plain']and report['runner_sha256']==sha(P/'runner.py')
 assert {x['output_sha256']for x in report['iterations']}=={n['output_sha256']}
for x in n['control_reports']:
 d=x['report'];assert all(e['native_shape_checked']for e in d['fft_adapters']);assert {r['output_sha256']for r in d['warmups']+d['iterations']}=={n['output_sha256']}
out['native_A100']=n|{'hardware':read(P/'native-validation-hardware.json')}
shutil.copyfile(P/'runner.py',E/'chatterbox_runner.py');shutil.copyfile(P/'fused-inference.patch',E/'cpu_patches/chatterbox_fused_inference.patch')
files=['pins.json','runner.py','runner-calibration.py','diagnose.py','cpu-diagnostic.json','fused-inference.patch','prepare_candidate.py','model-manifest.json','download_model.py','controls.json','controls.npz','load.json','load_probe.py','emu.json','emu-fft.json','cpu.json','partial.json','optimized.json','sync-before.json','sync-after.json','diagnostic.json','audit.py','run_timing.py','run_cpu.py','profile.sh','run_native_profile.py','stage_native.py','profile_gelu.py','profile-gelu.sh','run_gelu_calibration.py','gelu-calibration.json','predictor-provenance.json','kernel-calibration.json','cpu-calibration.json','omissions.json','native-calibration-identities.json','native-validation-identities.json','native-profile-hardware.json','native-validation-hardware.json','run_native_validation.py','validate-native.sh','package_results.py']
bundle=E/'evidence/chatterbox-reproduce.tar.gz'
with tarfile.open(bundle,'w:gz')as t:
 for name in files:t.add(P/name,arcname=name)
with tarfile.open(bundle,'r:gz')as t:
 assert sorted(t.getnames())==sorted(files)
 for name in files:assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==sha(P/name)
out['reproduction']={'file':bundle.name,'sha256':sha(bundle),'files':files,'note':'Install pinned source/dependencies, adjust host/file paths in managed configs. Native plain validation needs no recorded tape. Initial model and primitive calibrations are separate shards; merge with GXtools/gx_profile_db.py. Shared launch/audit helpers are in this repository.'}
dbdir=E/'evidence/kernel-databases';manifest=read(dbdir/'manifest.json');artifacts={}
for key,name,target in [('predictor','gpu-predictor.sqlite','chatterbox.predictor.sqlite.gz'),('model_database','gpu.sqlite','chatterbox.model.sqlite.gz'),('primitive_database','gelu.sqlite','chatterbox.gelu.sqlite.gz'),('native_report','kernel-profile.json','chatterbox.report.json.gz'),('cpu_instruction_calibration','cpu.db','chatterbox.cpu.db.gz')]:
 raw=(P/name).read_bytes();dst=dbdir/target;dst.write_bytes(gzip.compress(raw,compresslevel=9,mtime=0));assert gzip.decompress(dst.read_bytes())==raw;artifacts[key]={'file':target,'uncompressed_bytes':len(raw),'uncompressed_sha256':sha(P/name),'gzip_sha256':sha(dst)}
manifest['artifacts']['chatterbox']=artifacts;(dbdir/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');out['calibration']=artifacts
allpins=read(E/'pins.json');allpins['Chatterbox Turbo']=pins;(E/'pins.json').write_text(json.dumps(allpins,indent=2)+'\n');(E/'evidence/chatterbox-cpu.json').write_text(json.dumps(out,indent=2)+'\n')
print('CHATTERBOX_PACKAGE_PASS',json.dumps({'gx':{m:x['request_reduction_percent']for m,x in out['gx'].items()},'native_median':n['median_reduction_percent'],'native_mean':n['mean_reduction_percent']}),flush=True)
