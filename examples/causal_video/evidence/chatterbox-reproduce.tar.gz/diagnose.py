"""GX-only narrow thread-CPU attribution and CPU watermark equivalence oracle."""
import atexit,functools,json,runpy,sys,time
from pathlib import Path
import numpy as np
import torch
import perth
from chatterbox.models.t3 import T3
from chatterbox.models.s3gen import S3Gen
from transformers.models.gpt2.modeling_gpt2 import GPT2Model,GPT2Block
from transformers.cache_utils import DynamicLayer
stats={};oracle=[]
def wrap(cls,name):
 old=getattr(cls,name);key=cls.__name__+'.'+name
 @functools.wraps(old)
 def call(*args,**kwargs):
  start=time.thread_time_ns()
  try:return old(*args,**kwargs)
  finally:
   d=stats.setdefault(key,{'calls':0,'cpu_ns':0});d['calls']+=1;d['cpu_ns']+=time.thread_time_ns()-start
 setattr(cls,name,call)
for cls,name in [(T3,'inference_turbo'),(S3Gen,'inference'),(GPT2Model,'forward'),(GPT2Block,'forward'),(DynamicLayer,'update'),(perth.PerthImplicitWatermarker,'apply_watermark')]:wrap(cls,name)
args=sys.argv[1:];runner=args.pop(0);output=Path(args[args.index('--output')+1]);controls=Path(args[args.index('--control-arrays')+1]);sys.argv=[runner]+args
runpy.run_path(runner,run_name='__main__')
# Outside the model request and timing/profile window.
wm=perth.PerthImplicitWatermarker()
for name,signal in dict(np.load(controls)).items():
 saved=[]
 def pack(t):saved.append(t.numel()*t.element_size());return t
 with torch.autograd.graph.saved_tensors_hooks(pack,lambda x:x):before=wm.apply_watermark(signal,sample_rate=24000)
 with torch.inference_mode():after=wm.apply_watermark(signal,sample_rate=24000)
 assert np.array_equal(before,after),(name,float(np.abs(before-after).max()))
 oracle.append({'array':name,'samples':len(signal),'exact':True,'saved_tensor_count':len(saved),'saved_tensor_bytes':sum(saved)})
result={'narrow_inclusive_thread_cpu':stats,'watermark_oracle':oracle,'scope':'GX mode0 CPU diagnostics only; wrappers add overhead and values are not request timing. Oracle compares actual CPU watermark arithmetic on recorded native input.'}
(output/'diagnostic.json').write_text(json.dumps(result,indent=2)+'\n');print('CHATTERBOX_CPU_DIAG_PASS',json.dumps(result),flush=True)
