"""Native request latency without GX/control-tape instrumentation."""
import argparse,hashlib,json,os,resource,time
from importlib.metadata import version
from pathlib import Path
import numpy as np
import torch
from qwen_tts import Qwen3TTSModel
p=argparse.ArgumentParser();p.add_argument('--model',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--warmup',type=int,default=2);p.add_argument('--repetitions',type=int,default=5);a=p.parse_args()
a.output.mkdir(parents=True,exist_ok=False)
torch.set_num_threads(1);torch.set_num_interop_threads(1)
spec={'text':'Hello. This is a test of speech generation.','language':'English','speaker':'Ryan','non_streaming_mode':True,'max_new_tokens':256,'do_sample':True,'subtalker_dosample':True}
import qwen_tts,transformers.modeling_flash_attention_utils as fa
root=Path(qwen_tts.__file__).parent
report={'scope':'Native public generate_custom_voice; no control tape or tensor monkeypatches, no profiler; resident BF16 FA2, tokenization through CPU waveform return.','runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':{str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest()for f in root.rglob('*.py')},'flash_attention_source_sha256':hashlib.sha256(Path(fa.__file__).read_bytes()).hexdigest(),'versions':{n:version(n)for n in ('torch','torchaudio','transformers','tokenizers','accelerate','numpy','librosa','onnxruntime')},'request':spec,'seed':42,'warmups':[],'iterations':[]}
start=time.perf_counter();model=Qwen3TTSModel.from_pretrained(str(a.model),device_map='cuda:0',dtype=torch.bfloat16,attn_implementation='flash_attention_2',local_files_only=True);report['load_host_seconds']=time.perf_counter()-start
def generate():
 start=time.perf_counter();torch.manual_seed(42);torch.cuda.manual_seed_all(42);wavs,rate=model.generate_custom_voice(**spec);torch.cuda.synchronize();elapsed=time.perf_counter()-start
 assert len(wavs)==1;w=np.asarray(wavs[0]);assert w.ndim==1 and np.isfinite(w).all()
 return {'application_clock_seconds':elapsed,'sample_rate':rate,'samples':len(w),'dtype':str(w.dtype),'finite':True,'output_sha256':hashlib.sha256(w.tobytes()).hexdigest(),'minimum':float(w.min()),'maximum':float(w.max())}
for i in range(a.warmup):report['warmups'].append(generate())
for i in range(a.repetitions):report['iterations'].append(generate()|{'iteration':i+1})
report.update(phase='completed',peak_gpu_bytes=torch.cuda.max_memory_allocated(),peak_reserved_gpu_bytes=torch.cuda.max_memory_reserved(),peak_host_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024)
(a.output/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('QWEN_TTS_NATIVE_PLAIN_PASS',json.dumps(report['iterations']),flush=True)
