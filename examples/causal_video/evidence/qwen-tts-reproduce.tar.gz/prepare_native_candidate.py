"""Stage candidate assets without using a GPU; keep initial calibration manifest."""
import hashlib,json,shlex,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;base='/home/jcm/drperf-wan-a100-20260916/causal/qwen-tts'
ssh=['ssh','-o','ConnectTimeout=10','-o','ConnectionAttempts=3','jcm@A100']
checks=json.loads((P/'native-identities.json').read_text())
for name in ('source-position','deps-packed'):
 folder=P/name;dest=base+'/'+name
 subprocess.run(ssh+['mkdir -p '+shlex.quote(dest)],check=True)
 sender=subprocess.Popen(['tar','--exclude=__pycache__','-C',str(folder),'-cf','-','.'],stdout=subprocess.PIPE)
 try:subprocess.run(ssh+['tar --no-same-owner -C '+shlex.quote(dest)+' -xf -'],stdin=sender.stdout,check=True)
 finally:sender.stdout.close()
 assert sender.wait()==0
 for f in folder.rglob('*'):
  if f.is_file() and '__pycache__' not in f.parts:checks[dest+'/'+str(f.relative_to(folder))]=hashlib.sha256(f.read_bytes()).hexdigest()
for name in ('runner_candidates.py','controls.json','validate-native.sh'):
 subprocess.run(['rsync','-az','-e','ssh -o ConnectTimeout=10 -o ConnectionAttempts=3',str(P/name),'jcm@A100:'+base+'/'+name],check=True)
 checks[base+'/'+name]=hashlib.sha256((P/name).read_bytes()).hexdigest()
script='''import hashlib,json
checks=json.loads(%r)
for name,expected in checks.items():
 with open(name,'rb')as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==expected,name
print('QWEN_TTS_NATIVE_CANDIDATE_IDENTITIES_PASS',len(checks))
'''%json.dumps(checks)
subprocess.run(ssh+['python3 -'],input=script,text=True,check=True)
(P/'native-candidate-identities.json').write_text(json.dumps(checks,indent=2)+'\n')
