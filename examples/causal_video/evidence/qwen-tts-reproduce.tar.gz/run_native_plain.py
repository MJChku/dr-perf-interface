"""Validate selected candidate without control-tape overhead, on idle GPU1."""
import hashlib,json,statistics,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[2];base='/home/jcm/drperf-wan-a100-20260916/causal/qwen-tts'
control=json.loads((P/'native-position-summary.json').read_text());assert control['all_output_checks']==28
ssh=['ssh','-o','ConnectTimeout=10','-o','ConnectionAttempts=3','jcm@A100']
checks=json.loads((P/'native-candidate-identities.json').read_text())
for name in ('runner_native_plain.py','validate-plain.sh'):
 subprocess.run(['rsync','-az','-e','ssh -o ConnectTimeout=10 -o ConnectionAttempts=3',str(P/name),'jcm@A100:'+base+'/'+name],check=True)
 checks[base+'/'+name]=hashlib.sha256((P/name).read_bytes()).hexdigest()
script='''import hashlib,json
checks=json.loads(%r)
for name,expected in checks.items():
 with open(name,'rb')as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==expected,name
print('QWEN_TTS_NATIVE_PLAIN_IDENTITIES_PASS',len(checks))
'''%json.dumps(checks)
subprocess.run(ssh+['python3 -'],input=script,text=True,check=True)
(P/'native-plain-identities.json').write_text(json.dumps(checks,indent=2)+'\n')
active=subprocess.check_output(ssh+['nvidia-smi --query-compute-apps=gpu_uuid,pid --format=csv,noheader'],text=True)
assert 'GPU-521def15-8599-2c15-65ee-6dac40f31a64' not in active,active
hardware={'gpu_inventory':subprocess.check_output(ssh+['nvidia-smi --query-gpu=index,name,uuid,driver_version,memory.total --format=csv'],text=True),'active_compute_processes':active,'device_requests':json.loads(subprocess.check_output(ssh+['docker inspect --format "{{json .HostConfig.DeviceRequests}}" drperf-wan-native-0'],text=True))}
assert hardware['device_requests'][0]['DeviceIDs']==['1'];(P/'native-plain-hardware.json').write_text(json.dumps(hardware,indent=2)+'\n')
helper=R/'examples/wan_gx/native_container.py';reports=[]
collect_only='--collect-only' in sys.argv
try:
 if not collect_only:
  subprocess.run(['python3',str(helper),'resume'],check=True)
  subprocess.run(ssh+['docker exec -u jma drperf-wan-native-0 bash /workspace/causal/qwen-tts/validate-plain.sh'],check=True)
 for i,side in enumerate(('before','after','after','before'),1):
  dest=P/f'native-plain-{i}-{side}.json'
  subprocess.run(['rsync','-az','-e','ssh -o ConnectTimeout=10 -o ConnectionAttempts=3',f'jcm@A100:/home/jcm/drperf-wan-a100-20260916/causal/runs/qwtts-plain-{i}-{side}/report.json',str(dest)],check=True)
  report=json.loads(dest.read_text());assert report['phase']=='completed';reports.append({'side':side,'report':report})
 rows=[r for b in reports for r in b['report']['iterations']];hashes={r['output_sha256']for r in rows}
 warmups=[{'side':b['side'],'process_index':i,'warmup_index':j,**r}for i,b in enumerate(reports,1)for j,r in enumerate(b['report']['warmups'],1)]
 assert all(r['finite']for r in warmups)
 assert hashes=={control['output_sha256']} and all(r['finite']for r in rows),hashes
 summary={}
 for side in ('before','after'):
  vals=[r['application_clock_seconds']for b in reports if b['side']==side for r in b['report']['iterations']]
  assert len(vals)==10;summary[side]={'samples':vals,'median':statistics.median(vals),'mean':statistics.mean(vals),'min':min(vals),'max':max(vals)}
 summary.update(reports=reports,output_sha256=next(iter(hashes)),all_output_checks=len(rows),warmup_output_checks=warmups,warmup_hash_differences=[r for r in warmups if r['output_sha256']!=control['output_sha256']],scope='Unprofiled native public API with original tensor methods. No GX adapters or control-tape validation hooks. ABBA, 2 warmups + 5 measurements per process, all samples retained.')
 for stat in ('median','mean'):summary[stat+'_reduction_percent']=(1-summary['after'][stat]/summary['before'][stat])*100
 (P/'native-plain-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('QWEN_TTS_NATIVE_PLAIN_PASS',summary['median_reduction_percent'],flush=True)
finally:
 if not collect_only:subprocess.run(['python3',str(helper),'stop'],check=True)
