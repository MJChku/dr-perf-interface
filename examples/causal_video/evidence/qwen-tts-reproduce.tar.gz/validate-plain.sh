#!/usr/bin/env bash
set -euo pipefail
ulimit -c 0
export PYTHONPATH=/workspace/causal/qwen-tts/deps:/workspace/causal/qwen-tts/source:/workspace/causal/fastgen/deps:/workspace/causal/fastgen/source:/workspace/causal/omni/source:/workspace/causal/omni/extras:/workspace/causal/omni/deps:/workspace/causal/wan2gp/deps:/workspace/causal/wanwrapper/deps:/workspace/causal/sglang/cutlass:/workspace/causal/sglang/cutlass/nvidia_cutlass_dsl/dsl_packages:/workspace/causal/sglang/deps:/workspace/causal/sglang/kernel:/workspace/causal/sglang/source/python:/workspace/causal/deps:/workspace/causal/scope-deps:/workspace/causal/flashdreams-deps:/workspace/deps
export LD_LIBRARY_PATH=/workspace/causal/sglang/cuda13_libs:/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cudnn/lib
export LD_PRELOAD=/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cublas/lib/libcublas.so.12:/home/jma/bridge-venv2/lib/python3.12/site-packages/nvidia/cublas/lib/libcublasLt.so.12
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONHASHSEED=0 TOKENIZERS_PARALLELISM=false HF_HUB_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1
export HF_HOME=/workspace/causal/hf-cache LOCAL_FILES_ONLY=true
export FLASHINFER_DISABLE_VERSION_CHECK=1 VLLM_USE_V1=1 VLLM_WORKER_MULTIPROC_METHOD=spawn VLLM_ATTENTION_BACKEND=FLASH_ATTN

original_path="$PYTHONPATH"
index=0
for side in before after after before; do
 index=$((index+1))
 base=/workspace/causal/runs/qwtts-plain-${index}-${side}
 [[ ! -e "$base" ]]
 export QWEN_PACKED_SINGLE_TOKEN=0
 export PYTHONPATH="$original_path"
 if [[ "$side" == after ]]; then
  export QWEN_PACKED_SINGLE_TOKEN=1
  export PYTHONPATH=/workspace/causal/qwen-tts/deps-packed:/workspace/causal/qwen-tts/source-position:$original_path
 fi
 timeout -k 20 1800 python3 -u /workspace/causal/qwen-tts/runner_native_plain.py \
 --model /workspace/causal/models/Qwen3-TTS-12Hz-0.6B-CustomVoice \
 --output "$base" --warmup 2 --repetitions 5 > "$base.log" 2>&1
done
