"""A100 ABBA validation of the GX-selected candidate, retaining every sample."""
import hashlib,json,statistics,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[2]
before=json.loads((P/'packed-before-audit.json').read_text());after=json.loads((P/'position-audit.json').read_text())
for audit in (before,after):assert audit['result']['passed'] and not audit['result']['cleanup_errors']
assert after['iterations'][0]['virtual_seconds']<before['iterations'][0]['virtual_seconds']
assert after['model']['packed_single_token'] and after['model']['removed_packed_checks']>before['model']['removed_packed_checks']
ssh=['ssh','-o','ConnectTimeout=10','-o','ConnectionAttempts=3','jcm@A100']
checks=json.loads((P/'native-candidate-identities.json').read_text())
script='''import hashlib,json
checks=json.loads(%r)
for name,expected in checks.items():
 with open(name,'rb')as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==expected,name
print('QWEN_TTS_NATIVE_IDENTITIES_PASS',len(checks))
'''%json.dumps(checks)
subprocess.run(ssh+['python3 -'],input=script,text=True,check=True)
active=subprocess.check_output(ssh+['nvidia-smi --query-compute-apps=gpu_uuid,pid --format=csv,noheader'],text=True)
assert 'GPU-521def15-8599-2c15-65ee-6dac40f31a64' not in active,active
hardware={'gpu_inventory':subprocess.check_output(ssh+['nvidia-smi --query-gpu=index,name,uuid,driver_version,memory.total --format=csv'],text=True),'active_compute_processes':active,'device_requests':json.loads(subprocess.check_output(ssh+['docker inspect --format "{{json .HostConfig.DeviceRequests}}" drperf-wan-native-0'],text=True))}
assert hardware['device_requests'][0]['DeviceIDs']==['1'];(P/'native-candidate-hardware.json').write_text(json.dumps(hardware,indent=2)+'\n')
helper=R/'examples/wan_gx/native_container.py'
reports=[]
try:
 subprocess.run(['python3',str(helper),'resume'],check=True)
 subprocess.run(ssh+['docker exec -u jma drperf-wan-native-0 bash /workspace/causal/qwen-tts/validate-native.sh'],check=True)
 for i,side in enumerate(('before','after','after','before'),1):
  dest=P/f'native-position-{i}-{side}.json'
  subprocess.run(['rsync','-az','-e','ssh -o ConnectTimeout=10 -o ConnectionAttempts=3',f'jcm@A100:/home/jcm/drperf-wan-a100-20260916/causal/runs/qwtts-position-{i}-{side}/report.json',str(dest)],check=True)
  report=json.loads(dest.read_text());assert report['phase']=='completed';reports.append({'side':side,'report':report})
 rows=[r for block in reports for r in block['report']['warmups']+block['report']['iterations']]
 hashes={r['output_sha256']for r in rows};assert len(hashes)==1 and all(r['finite']for r in rows),hashes
 assert hashes=={'56d3ce6c19931459febce896be975b36ddd99bb7f67887e2e1cfaa336a3a443a'},hashes
 samples={side:[r['application_clock_seconds']for block in reports if block['side']==side for r in block['report']['iterations']]for side in ('before','after')}
 summary={side:{'samples':v,'median':statistics.median(v),'mean':statistics.mean(v),'min':min(v),'max':max(v)}for side,v in samples.items()}
 summary.update(reports=reports,output_sha256=next(iter(hashes)),all_output_checks=len(rows),scope='Unprofiled GPU execution; matched Python control-tape validation hooks remain present in both variants, as in GX. Separate bare-application validation is needed to quantify hook overhead.')
 summary['median_reduction_percent']=(1-summary['after']['median']/summary['before']['median'])*100
 summary['mean_reduction_percent']=(1-summary['after']['mean']/summary['before']['mean'])*100
 (P/'native-position-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print('QWEN_TTS_NATIVE_CANDIDATE_PASS',summary['median_reduction_percent'],flush=True)
finally:subprocess.run(['python3',str(helper),'stop'],check=True)
