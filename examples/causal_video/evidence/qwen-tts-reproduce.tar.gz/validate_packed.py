"""Source-level oracle for single-position packed-sequence fast path."""
import ast,json
from pathlib import Path
import torch
P=Path(__file__).resolve().parent
def load(path):
 tree=ast.parse(path.read_text());nodes=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='_is_packed_sequence'];assert len(nodes)==1
 ns={'torch':torch};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),ns);return ns['_is_packed_sequence']
before=load(P/'deps/transformers/modeling_flash_attention_utils.py');after=load(P/'modeling_flash_attention_utils.patched.py')
cases=[(None,1)]
for dtype in (torch.int32,torch.int64):
 limit=torch.iinfo(dtype)
 for x in (limit.min,-100,-1,0,1,100,limit.max):cases.append((torch.tensor([[x]],dtype=dtype,device='cpu'),1))
 for data in ([[0,1,2]],[[7,8,9]],[[0,1,0,1]],[[2,1,0]],[[0,0,0]],[[]],[[0,1],[7,8]],[[0],[7]]):
  value=torch.tensor(data,dtype=dtype,device='cpu');cases.append((value,len(data)))
cases.extend([(torch.tensor([[float('nan')]],device='cpu'),1),(torch.tensor([[1.5]],device='cpu'),1)])
for value,batch in cases:
 answers=[]
 for fn in (before,after):
  try:answers.append(('value',bool(fn(value,batch))))
  except (RuntimeError,IndexError)as e:answers.append(('error',type(e).__name__))
 assert answers[0]==answers[1],(value,batch,answers)
result={'passed':True,'comparisons':len(cases),'torch':torch.__version__,'device':'CPU','coverage':'Int32/int64 extrema; sequential, repeated and reset positions; multibatch; empty and floating-point fallback; original error behavior. Single integer position algebraically cannot be packed. Native waveform/control validation still required.'}
(P/'packed-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
