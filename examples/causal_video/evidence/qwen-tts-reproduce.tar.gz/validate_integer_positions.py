"""Check integer position bookkeeping over binary attention-mask inputs."""
import ast,json
from pathlib import Path
import torch
P=Path(__file__).resolve().parent
torch.set_num_threads(1)
def load(path):
 tree=ast.parse(path.read_text())
 cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Qwen3TTSTalkerForConditionalGeneration')
 fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='get_rope_index')
 ns={'torch':torch};exec('from __future__ import annotations\n'+ast.unparse(fn),ns);return ns[fn.name]
before=load(P.parent/'Qwen3-TTS/qwen_tts/core/models/modeling_qwen3_tts.py')
after=load(P/'source-position/qwen_tts/core/models/modeling_qwen3_tts.py')
count=0
for dtype in (torch.bool,torch.int64,torch.float32):
 for length in (1,2,16,128,2048,32768):
  for batch in (1,2,4):
   mask=torch.ones((batch,length),dtype=dtype)
   for row in range(batch):mask[row,:min(row*3,length//2)]=0
   old=before(None,mask);new=after(None,mask)
   for a,b in zip(old,new):assert torch.equal(a.float(),b.float()) and b.dtype==torch.int64
   count+=1
result={'passed':True,'comparisons':count,'torch':torch.__version__,'device':'CPU','scope':'Binary attention masks, bool/int64/float32, batch1/2/4, left padding, sequence lengths1..32768. Compare coordinates/deltas after FP32 conversion used by rotary embedding. Candidate retains integer positions. Native waveform validation still required.'}
(P/'integer-position-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
