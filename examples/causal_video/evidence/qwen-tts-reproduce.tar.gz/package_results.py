"""Publish audited Qwen3-TTS GX predictions and separate native validation."""
import gzip,hashlib,json,shutil,sys,tarfile
from pathlib import Path
P=Path(__file__).resolve().parent;E=P.parents[2]/'examples/causal_video';sys.path.insert(0,str(E))
from compact_gx_trace import compact

def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
pins=read(P/'pins.json');pins['stage']='GX modes2/3 and A100 control and uninstrumented ABBA validation completed.'
pins['workload']='One fixed English request, speaker Ryan, seed42, CustomVoice0.6B, non_streaming_mode=True, max_new_tokens256, sampling enabled; original public generate_custom_voice including tokenization, talker/code-predictor autoregression, speech decoder and CPU waveform return. Resident BF16 parameters and FA2; no encoding.'
pins['dependencies']=read(P/'kernel-profile.json')['versions'];(P/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
out={'system':'Qwen3-TTS','pins':pins,'change':'Skip FlashAttention packed-sequence detection for a batch of one integer position; retain Qwen talker position indices as int64 for binary masks, with the existing FP32 conversion inside rotary embedding. No change to model parameters, sampling, attention algorithm, offload or audio decoding.','gx':{},'traces':{},'correctness_oracles':{'packed':read(P/'packed-validation.json'),'integer_positions':read(P/'integer-position-validation.json')},'omissions':read(P/'omissions.json'),'control_validation':read(P/'control-validation.json'),'control_summary':read(P/'control-summary.json'),'cpu_calibration':read(P/'cpu-calibration.json'),'native_kernel_calibration':read(P/'kernel-profile.json'),'limitations':[
 'GX replays the scalar control tape of one calibrated real request. Original GPU scalar read operations remain except those explicitly removed by the optimization. This is not a predictor of numerical outputs, new prompts or arbitrary generated lengths.',
 'GX-only known-unique token-suppression and empty-padding adapters omit native uniqueness/nonzero work; native validation uses the original operations. Baseline omissions are quantified separately; sums of isolated kernel durations are not end-to-end corrections.',
 'Native calibration includes 1378 FP32 GEMM launches absent from GX timing (11.205365ms summed isolated medians), plus cuDNN plan/grid discrepancies. The integer-position candidate introduces 117 additional uncovered operation launches in mode2; exact coverage and misses are stored per run. Missing predictions are not measured zero-cost work.',
 'Mode3 uses10us epochs. Numerous tiny operations make epoch granularity relevant; mode3 absolute latency is not demonstrated to be a more accurate hardware estimate. Both predictions substantially exceed the native request time.',
 'CPU instruction calibration has 2822 unresolved out of63818 samples (4.42%); GX host EPYC7702P differs from native A100 host EPYC9554. Simulation uses one measured request per variant/mode, after a warmup.',
 'GX and matched native control validation include Python control-tape hooks. The primary native latency validation uses the public API without those hooks; its absolute timing is therefore not a matched-instrumentation calibration of GX.',
 'The uninstrumented native first baseline warmup had a different hash; all20 measured outputs and the other7 warmups match. The differing cold baseline output was finite with the same length and extrema, but waveform error was not retained. Control-checked native all28 outputs match. No all-cold-start determinism claim.',
 'Integer positions are validated for binary attention masks and supported context lengths. Float/nonfinite inputs to the generic packed check retain the original path. Numerical native checks cover one prompt, seed, shape and single GPU, not all generation modes or concurrent requests.',
 'Compact traces contain per-bin unions of CPU/GPU/copy intervals; overlapping categories are not additive hardware utilization. Full archived traces remain available by recorded paths.'
 ]}
for mode,names in [('mode2',('packed-before','position')),('mode3',('sync-before','sync-after'))]:
 records={}
 for side,name in zip(('before','after'),names):
  a=read(P/(name+'-audit.json'));assert a['result']['passed'] and not a['result']['cleanup_errors']
  assert a['model']['runner_sha256']==sha(P/'runner_candidates.py')
  assert a['model']['packed_single_token']==(side=='after')
  assert len(a['iterations'])==1
  records[side]={k:a[k]for k in ('run','result','summary','iterations','model','misses','kernel_inventory','gpu_db_sha256','cpu_db_sha256','cpu_profile_header')}
  records[side]['runtime']=read(Path(a['run'])/'runtime.json');records[side]['controller_wall_seconds']=read(P/(name+'-run.json'))['controller_wall_seconds']
  src=Path(a['run'])/'timeline-report/trace.json.gz';dst=E/f'evidence/qwen-tts-{mode}-{side}.chrome.json.gz'
  out['traces'][mode+'_'+side]={'file':dst.name,'full_trace':str(src),**compact(src,dst,bin_ms=10)}
 assert records['before']['runtime']['dynamorio']==records['after']['runtime']['dynamorio']
 records['request_reduction_percent']=100*(1-records['after']['iterations'][0]['virtual_seconds']/records['before']['iterations'][0]['virtual_seconds'])
 out['gx'][mode]=records
native=read(P/'native-plain-summary.json');control=read(P/'native-position-summary.json')
for n in (native,control):
 assert n['all_output_checks']==(20 if n is native else 28) and len(n['before']['samples'])==10 and len(n['after']['samples'])==10
 for block in n['reports']:
  side=block['side'];report=block['report'];gx=out['gx']['mode2'][side]['model']
  assert report['versions']==gx['versions'] and report['source_sha256']==gx['source_sha256']
  assert report['flash_attention_source_sha256']==gx['flash_attention_source_sha256']
  assert {r['output_sha256']for r in report['iterations']}=={n['output_sha256']}
  assert all(r['finite']for r in report['warmups'])
assert native['output_sha256']==control['output_sha256']
out['native_A100']=native|{'hardware':read(P/'native-plain-hardware.json')};out['native_control_validation']=control|{'hardware':read(P/'native-candidate-hardware.json')}
out['ablation_single_integer_guard_only']={'audit':read(P/'packed-after-audit.json'),'comparison':read(P/'packed-comparison.json'),'native_validation':'Not separately run.'}
for src,dest in [('packed-single-token.patch','qwen_tts_single_position.patch'),('integer-position.patch','qwen_tts_integer_positions.patch')]:shutil.copyfile(P/src,E/'cpu_patches'/dest)
shutil.copyfile(P/'runner_candidates.py',E/'qwen_tts_runner.py')
names=['pins.json','runner_calibration.py','runner.py','runner_candidates.py','runner_native_plain.py','packed-single-token.patch','integer-position.patch','validate_packed.py','packed-validation.json','validate_integer_positions.py','integer-position-validation.json','controls.json','control-summary.json','control-validation.json','cpu-calibration.json','omissions.json','cpu.json','packed-before.json','packed-after.json','position.json','sync-before.json','sync-after.json','run_timing.py','audit.py','profile.sh','run_native_profile.py','prepare_native_candidate.py','run_native_candidate.py','validate-native.sh','run_native_plain.py','validate-plain.sh','native-candidate-identities.json','native-plain-identities.json','native-candidate-hardware.json','native-plain-hardware.json','model-manifest.json','package_results.py']
bundle=E/'evidence/qwen-tts-reproduce.tar.gz'
with tarfile.open(bundle,'w:gz')as t:
 for name in names:t.add(P/name,arcname=name)
with tarfile.open(bundle,'r:gz')as t:
 assert sorted(t.getnames())==sorted(names)
 for name in names:assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==sha(P/name)
out['reproduction']={'file':bundle.name,'sha256':sha(bundle),'files':names,'note':'Install pinned source/dependencies and apply each patch in its own source root; adjust host and asset paths in configs. Recorded controls apply only to the fixed request. Native plain runner does not need the tape. Shared launcher/audit/trace tools live in this repository.'}
dbdir=E/'evidence/kernel-databases';manifest=read(dbdir/'manifest.json');calibration={}
for key,src,name in [('database','gpu.sqlite','qwen-tts.sqlite.gz'),('native_report','kernel-profile.json','qwen-tts.report.json.gz'),('cpu_instruction_calibration','cpu.db','qwen-tts.cpu.db.gz')]:
 raw=(P/src).read_bytes();dst=dbdir/name;dst.write_bytes(gzip.compress(raw,compresslevel=9,mtime=0));assert gzip.decompress(dst.read_bytes())==raw
 calibration[key]={'file':name,'source':str(P/src),'uncompressed_bytes':len(raw),'uncompressed_sha256':sha(P/src),'gzip_sha256':sha(dst)}
calibration['scope']=pins['workload'];out['calibration']=calibration;manifest['artifacts']['qwen-tts']=calibration;(dbdir/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
allpins=read(E/'pins.json');allpins['Qwen3-TTS']=pins;(E/'pins.json').write_text(json.dumps(allpins,indent=2)+'\n')
(E/'evidence/qwen-tts-cpu.json').write_text(json.dumps(out,indent=2)+'\n')
print('QWEN_TTS_PACKAGE_PASS',{m:r['request_reduction_percent']for m,r in out['gx'].items()},native['median_reduction_percent'],native['mean_reduction_percent'],flush=True)
